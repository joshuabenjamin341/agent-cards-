const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {dom}=require('../test-support/desk-dom');
const root=path.resolve(__dirname,'..'),flush=()=>new Promise(r=>setImmediate(r));
function notesFixture() {
 const d=dom(),context=vm.createContext({...d,URL,Blob,setTimeout,clearTimeout});
 for(const file of ['notes.js','notes-ui.js','desk-template.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context);
 d.document.documentElement.innerHTML=context.AC_DESK_TEMPLATE.html;
 let notes=[],seq=0,listener;const sent=[];
 const api={storage:{onChanged:{addListener:fn=>listener=fn,removeListener(){}}},runtime:{sendMessage:async msg=>{
  sent.push(msg);if(msg.type==='AC_NOTES_LIST')return {ok:true,notes};
  notes=context.AGENT_CARDS_NOTES.mutate(notes,msg,()=>`note${++seq}`,Date.now());listener({agentCardsNotesV1:{newValue:notes}},'local');return {ok:true,notes};
 }}};
 context.AC_NOTES_UI.mount(d.document,api);
 return {...d,sent,get notes(){return notes;},$:id=>d.document.getElementById(id)};
}
test('notes UI saves every input immediately and preserves focus and line breaks',async()=>{
 const f=notesFixture();await flush();await f.$('noteAdd').click();await flush();
 const field=f.$('notesList').querySelector('textarea');field.focus();field.value='Ring driver\nCheck booking';await field.emit('input');
 assert.equal(f.sent.at(-1).patch.text,field.value);await flush();assert.equal(f.notes[0].text,field.value);assert.equal(f.document.activeElement,field);
});
test('marking a note for handover and copying does not send it externally',async()=>{
 const f=notesFixture();await flush();await f.$('noteAdd').click();await flush();
 const card=f.$('notesList').children[0],field=card.querySelector('textarea');field.value='Customer to call back';await field.emit('input');await flush();
 const mark=card.querySelector('.note-handover').querySelector('input');mark.checked=true;await mark.emit('change');await flush();
 assert.equal(f.$('copyHandover').disabled,false);await f.$('copyHandover').click();assert.match(f.$('handoverCopy').value,/Customer to call back/);
 assert.ok(f.sent.every(m=>m.type==='AC_NOTES_LIST'||m.type==='AC_NOTES_MUTATE'));
});
test('completed notes leave Outstanding but are retained in All notes',async()=>{
 const f=notesFixture();await flush();await f.$('noteAdd').click();await flush();
 const card=f.$('notesList').children[0],check=card.querySelector('input');check.checked=true;await check.emit('change');await flush();assert.equal(card.hidden,true);
 const all=f.document.querySelectorAll('[data-note-filter]').find(b=>b.dataset.noteFilter==='all');await all.click();assert.equal(card.hidden,false);assert.equal(f.notes.length,1);
});
function drawerFixture({allowed=true,subframe=false}={}) {
 const d=dom();let storageListeners=new Set(),intervals=new Map(),seq=0,contactMounts=0,noteMounts=0,destroys=0;const sent=[];
 const window={};window.top=subframe?{}:window;
 const chrome={runtime:{getManifest:()=>({version:'1.2.0'}),sendMessage:async msg=>{sent.push(msg);return msg.type==='AC_DRAWER_ACCESS'?{ok:allowed}:{ok:true,dialers:1};}},storage:{local:{async get(){return {deskTab:'notes'};},async set(){}},sync:{async get(defaults){return {...defaults};}},onChanged:{addListener:fn=>storageListeners.add(fn),removeListener:fn=>storageListeners.delete(fn)}}};
 const context=vm.createContext({...d,window,location:{protocol:'https:'},chrome,setInterval:fn=>{intervals.set(++seq,fn);return seq;},clearInterval:id=>intervals.delete(id),AC_CONTACTS_UI:{mount(){contactMounts++;return()=>destroys++;}},AC_NOTES_UI:{mount(){noteMounts++;return()=>destroys++;}}});
 for(const file of ['defaults.js','desk-template.js','edge-drawer.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context);
 const host=()=>d.document.querySelector('[data-agent-cards-desk-host]');
 return {...d,host,context,sent,intervals,mounts:()=>[contactMounts,noteMounts],destroys:()=>destroys,reinject:()=>vm.runInContext(fs.readFileSync(path.join(root,'edge-drawer.js'),'utf8'),context)};
}
test('drawer starts collapsed, opens on a trusted click and keeps notes mounted on close',async()=>{
 const f=drawerFixture();await flush();const r=f.host().shadow,launcher=r.getElementById('deskLauncher');
 assert.equal(r.getElementById('deskShell').inert,true);assert.equal(launcher.getAttribute('aria-expanded'),'false');
 assert.equal(f.sent.filter(m=>m.type==='AC_DESK_STATE').length,0);
 await launcher.click();assert.equal(r.getElementById('deskShell').inert,false);assert.equal(launcher.getAttribute('aria-expanded'),'true');
 await r.getElementById('deskClose').click();assert.equal(r.getElementById('deskShell').inert,true);assert.deepEqual(f.mounts(),[1,1]);
 assert.equal(f.destroys(),0);
});
test('drawer does not open from generated clicks and Escape closes it',async()=>{
 const f=drawerFixture();await flush();const r=f.host().shadow,b=r.getElementById('deskLauncher');await b.emit('click',{isTrusted:false});assert.equal(b.getAttribute('aria-expanded'),'false');
 await b.click();await r.emit('keydown',{key:'Escape'});assert.equal(b.getAttribute('aria-expanded'),'false');
});
test('drawer does not mount in subframes or without permission',async()=>{
 for(const options of [{subframe:true},{allowed:false}]){const f=drawerFixture(options);await flush();assert.equal(f.host(),null);assert.deepEqual(f.mounts(),[0,0]);}
});
test('reinjecting drawer scripts retains one tab and one set of UI listeners',async()=>{
 const f=drawerFixture();await flush();f.reinject();await flush();assert.equal(f.document.querySelectorAll('[data-agent-cards-desk-host]').length,1);assert.deepEqual(f.mounts(),[1,1]);
});
test('removing a stale drawer tears down its controllers and liveness timer',async()=>{
 const f=drawerFixture();await flush();f.host().remove();await flush();assert.equal(f.destroys(),2);assert.equal(f.intervals.size,0);
});
