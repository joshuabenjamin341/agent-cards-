/* Local shift notes. Each mutation merges into the latest stored collection. */
(() => {
  const KEY='agentCardsNotesV1', LIMIT=200, TEXT_LIMIT=4000;
  function read(raw) {
    if(!Array.isArray(raw))return [];
    const seen=new Set();
    return raw.filter(n=>n && typeof n.id==='string' && n.id.length<=100 && !seen.has(n.id) && seen.add(n.id) && typeof n.text==='string')
      .slice(0,LIMIT).map(n=>({id:n.id,text:n.text.slice(0,TEXT_LIMIT),done:n.done===true,handover:n.handover===true,
        createdAt:Number.isFinite(n.createdAt)?n.createdAt:0,updatedAt:Number.isFinite(n.updatedAt)?n.updatedAt:0}));
  }
  function mutate(notes,msg,makeId,now) {
    if(msg.action==='add') {
      if(notes.length>=LIMIT)throw new Error('You have 200 notes. Export or delete old notes before adding more.');
      return [...notes,{id:makeId(),text:'',done:false,handover:false,createdAt:now,updatedAt:now}];
    }
    if(!notes.some(n=>n.id===msg.id))throw new Error('This note was removed in another window. Copy your text before closing it.');
    if(msg.action==='delete')return notes.filter(n=>n.id!==msg.id);
    if(msg.action!=='patch'||!msg.patch||typeof msg.patch!=='object')throw new Error('Unknown note action.');
    const patch={};
    if(Object.hasOwn(msg.patch,'text')) {
      if(typeof msg.patch.text!=='string'||msg.patch.text.length>TEXT_LIMIT)throw new Error('Keep each note to 4,000 characters.');
      patch.text=msg.patch.text;
    }
    for(const key of ['done','handover'])if(Object.hasOwn(msg.patch,key)) {
      if(typeof msg.patch[key]!=='boolean')throw new Error('Invalid note option.');
      patch[key]=msg.patch[key];
    }
    return notes.map(n=>n.id===msg.id?{...n,...patch,updatedAt:now}:n);
  }
  function handover(notes) {
    const selected=notes.filter(n=>n.handover&&!n.done&&n.text.trim());
    return selected.length ? 'SHIFT HANDOVER\n\n'+selected.map(n=>`[${new Date(n.createdAt).toLocaleString('en-GB')}]\n${n.text.trim()}`).join('\n\n') : '';
  }
  globalThis.AGENT_CARDS_NOTES={KEY,LIMIT,TEXT_LIMIT,read,mutate,handover};
  if(typeof module!=='undefined'&&module.exports)module.exports=globalThis.AGENT_CARDS_NOTES;
})();
