/* Drawer permissions, note writes and browser-owned selection call actions. */
let noteWrites=Promise.resolve(), edgeSync=Promise.resolve();
const SELECTION_MENU='agent-cards-call-selection';
async function listNotes(){await noteWrites;return {ok:true,notes:AGENT_CARDS_NOTES.read((await chrome.storage.local.get(AGENT_CARDS_NOTES.KEY))[AGENT_CARDS_NOTES.KEY])};}
function mutateNotes(msg) {
  const task=noteWrites.then(async()=>{
    const N=AGENT_CARDS_NOTES,notes=N.read((await chrome.storage.local.get(N.KEY))[N.KEY]);
    let next;try{next=N.mutate(notes,msg,()=>crypto.randomUUID(),Date.now());}catch(e){return {ok:false,error:e.message};}
    await chrome.storage.local.set({[N.KEY]:next});return {ok:true,notes:next};
  });noteWrites=task.catch(()=>{});return task;
}
async function senderIsTrustedDrawer(sender) {
  if(sender.id!==chrome.runtime.id||sender.tab?.id==null||sender.frameId!==0)return false;
  let url;try{url=new URL(sender.url);}catch{return false;}
  if(!['http:','https:'].includes(url.protocol))return false;
  const prefs=await chrome.storage.local.get(['edgeHidden','edgeEverywhere']);
  if(prefs.edgeHidden===true)return false;
  if(!prefs.edgeEverywhere && !GOOGLE_EDGE_HOSTS.includes(url.hostname) && !(await getSites()).includes(url.hostname))return false;
  return chrome.permissions.contains({origins:[`${url.protocol}//${url.hostname}/*`]});
}
function syncEdgeRegistration() {
  const task=edgeSync.then(async()=>{
    const id='agent-cards-edge-everywhere';
    const {edgeEverywhere}=await chrome.storage.local.get('edgeEverywhere');
    const allowed=edgeEverywhere===true&&await chrome.permissions.contains({origins:['https://*/*','http://*/*']});
    const existing=await chrome.scripting.getRegisteredContentScripts({ids:[id]});
    if(existing.length)await chrome.scripting.unregisterContentScripts({ids:[id]});
    if(allowed)await chrome.scripting.registerContentScripts([{id,matches:['https://*/*','http://*/*'],js:EDGE_CONTENT_JS,runAt:'document_idle',allFrames:false,persistAcrossSessions:true}]);
  });edgeSync=task.catch(()=>{});return task;
}
chrome.permissions.onAdded?.addListener(()=>syncEdgeRegistration().catch(()=>{}));
chrome.storage.onChanged?.addListener((changes,area)=>{
  if(area!=='local'||!changes.edgeEverywhere)return;
  syncEdgeRegistration().then(async()=>{
    if(changes.edgeEverywhere.newValue!==true)return;
    for(const tab of await chrome.tabs.query({url:['https://*/*','http://*/*']})) {
      if(tab.id!=null)chrome.scripting.executeScript({target:{tabId:tab.id},files:EDGE_CONTENT_JS}).catch(()=>{});
    }
  }).catch(()=>{});
});
function createSelectionMenu() {
  chrome.contextMenus.removeAll(()=>{
    void chrome.runtime.lastError;
    chrome.contextMenus.create({id:SELECTION_MENU,title:'Call through Genesys',contexts:['selection']},()=>{void chrome.runtime.lastError;});
  });
}
function selectedPhone(raw) {
  if(typeof raw!=='string'||raw.length>100)return null;
  const input=raw.trim();
  if(!input||/[\r\n]/.test(input)||!/^\+?[\d\s().-]+$/.test(input))return null;
  const number=normaliseNumber(input.replace(/^(\+44|0044)\s*\(0\)/,'$1'));
  return /^\+44[1-8]\d{8,9}$/.test(number)&&validNumber(number)?number:null;
}
async function callSelection(raw) {
  const number=selectedPhone(raw);
  if(!number)return {ok:false,reason:'selection-invalid'};
  // Share the direct-call lock with saved contacts, including across windows.
  if(contactCalling||Date.now()-(lastRequest.get('contacts')||0)<3000)return {ok:false,reason:'busy'};
  contactCalling=true;lastRequest.set('contacts',Date.now());
  try {
    return await new Promise(resolve=>{
      let settled=false;const finish=status=>{if(!settled){settled=true;resolve({...status,number});}};
      relayDial(number,undefined,finish).catch(()=>finish({ok:false,reason:'unavailable'}));
    });
  }finally{contactCalling=false;}
}
const SELECTION_ERRORS={
  'selection-invalid':'Highlight one complete UK phone number, without names or extra text. Premium and blocked service numbers cannot be called.',
  'no-tab':'Open Genesys Agent Workspace and enable its site in the extension.',
  'no-dialer':'Open the Genesys dialler and refresh its tab, then try again.',
  'no-line':'Choose your outbound line or queue in Genesys, then try again.',
  'no-input':'The Genesys number box was not available. Open Agent Workspace.',
  busy:'Another call request is in progress. Check Genesys before trying again.',
  timeout:'No response from Genesys. Check the dialler before trying again to avoid a duplicate call.',
  unavailable:'Call outcome unknown. Check Genesys before trying again.'
};
function selectionToast(text,error) {
  let ui=globalThis.__acSelectionToast;
  if(!ui||!ui.host.isConnected) {
    const host=document.createElement('div');host.style.cssText='all:initial!important;position:fixed!important;right:24px!important;bottom:24px!important;z-index:2147483647!important;';
    const root=host.attachShadow({mode:'closed'}),style=document.createElement('style');
    style.textContent=':host{color-scheme:dark}.toast{font:13px/1.5 system-ui;color:#edf3f6;background:#13232f;border:1px solid #69e0bd;border-radius:14px;padding:17px;box-shadow:0 12px 40px #0005;width:min(340px,calc(100vw - 80px));display:flex;gap:12px;align-items:start}.toast.error{border-color:#f4a1b8}button{background:none;border:0;color:#edf3f6;font-size:18px;cursor:pointer}p{margin:0}';
    const box=document.createElement('div');box.className='toast';box.setAttribute('role','status');const message=document.createElement('p');
    const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','Dismiss call status');close.addEventListener('click',()=>host.remove());
    box.append(message,close);root.append(style,box);document.documentElement.append(host);ui={host,box,message};globalThis.__acSelectionToast=ui;
  }
  clearTimeout(ui.timer);ui.message.textContent=text;ui.box.classList.toggle('error',error);ui.timer=setTimeout(()=>ui.host.remove(),20000);
}
async function selectionFeedback(tabId,text,error=false,documentId) {
  if(tabId==null)return;
  chrome.action.setTitle({tabId,title:`Agent Cards: ${text}`}).catch(()=>{});
  chrome.action.setBadgeText({tabId,text:error?'!':text.startsWith('Sending')?'…':'✓'}).catch(()=>{});
  chrome.action.setBadgeBackgroundColor({tabId,color:error?'#a02c47':'#256951'}).catch(()=>{});
  try {
    const target=documentId?{tabId,documentIds:[documentId]}:{tabId,frameIds:[0]};
    const result=await chrome.scripting.executeScript({target,func:selectionToast,args:[text,error]});
    return result[0]?.documentId;
  }catch{/* Restricted browser pages still show the toolbar badge and title. */}
}
chrome.contextMenus.onClicked.addListener((info,tab)=>{
  if(info.menuItemId!==SELECTION_MENU)return;
  // Only this browser event can initiate a selected-number call. No page message route.
  const number=selectedPhone(info.selectionText);
  const first=selectionFeedback(tab?.id,number?`Sending ${AGENT_CARDS_CONTACTS.displayNumber(number)} to Genesys…`:SELECTION_ERRORS['selection-invalid'],!number);
  if(!number)return;
  const request=callSelection(info.selectionText);
  Promise.all([first,request]).then(([documentId,result])=>{
    const text=result.ok?`Call request sent to Genesys: ${AGENT_CARDS_CONTACTS.displayNumber(number)}.`:SELECTION_ERRORS[result.reason]||SELECTION_ERRORS.unavailable;
    selectionFeedback(tab?.id,text,!result.ok,documentId);
    setTimeout(()=>{chrome.action.setBadgeText({tabId:tab?.id,text:''}).catch(()=>{});chrome.action.setTitle({tabId:tab?.id,title:'Agent Cards Plus'}).catch(()=>{});},20000);
  }).catch(()=>selectionFeedback(tab?.id,SELECTION_ERRORS.unavailable,true));
});
