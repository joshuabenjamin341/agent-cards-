/* Shared contact validation. Storage and dialling stay in the service worker. */
(() => {
  const KEY = 'agentCardsContactsV1';
  const LIMIT = 500;
  const security = globalThis.AGENT_CARDS_SECURITY;
  function validate(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Choose a contact to save.');
    const name = typeof raw.name === 'string' ? raw.name.trim().replace(/\s+/g, ' ') : '';
    const label = typeof raw.label === 'string' ? raw.label.trim().replace(/\s+/g, ' ') : '';
    if (!name || name.length > 80) throw new Error('Enter a name of up to 80 characters.');
    if (label.length > 60) throw new Error('Keep the label to 60 characters or fewer.');
    if (typeof raw.number !== 'string' || !raw.number.trim()) throw new Error('Enter a number in the UK phone number box.');
    if (raw.number.length > 80 || !/^[+\d\s().-]+$/.test(raw.number)) {
      throw new Error('Enter a phone number without letters or extension codes.');
    }
    const number = security.normaliseNumber(raw.number);
    if (!security.validNumber(number)) throw new Error('Enter a supported UK number. Premium and blocked service numbers cannot be saved.');
    return { name, number, label, favourite: raw.favourite === true };
  }
  function read(value) {
    if (!Array.isArray(value)) return [];
    const ids = new Set(), numbers = new Set(), contacts = [];
    for (const raw of value.slice(0, LIMIT)) {
      try {
        if (typeof raw.id !== 'string' || !raw.id || raw.id.length > 100 || ids.has(raw.id)) continue;
        const contact = { id: raw.id, ...validate(raw) };
        if (numbers.has(contact.number)) continue;
        ids.add(contact.id); numbers.add(contact.number); contacts.push(contact);
      } catch { /* Ignore malformed stored entries without rendering their content as HTML. */ }
    }
    return contacts;
  }
  function upsert(contacts, raw, makeId) {
    const contact = validate(raw);
    const id = raw.id;
    const index = id ? contacts.findIndex(c => c.id === id) : -1;
    if (id && index < 0) throw new Error('This contact was removed. Add it again to save it.');
    if (contacts.some(c => c.number === contact.number && c.id !== id)) throw new Error('That number is already saved. Edit its existing contact instead.');
    if (index < 0 && contacts.length >= LIMIT) throw new Error(`You can save up to ${LIMIT} contacts.`);
    const next = contacts.slice();
    if (index < 0) next.push({ id: makeId(), ...contact });
    else next[index] = { id, ...contact };
    return next;
  }
  function merge(contacts, backup, makeId) {
    if (backup?.format !== 'agent-cards-contacts' || backup.version !== 1 || !Array.isArray(backup.contacts) || backup.contacts.length > LIMIT) {
      throw new Error('Choose an Agent Cards contacts backup with up to 500 entries.');
    }
    // Validate the complete backup before changing anything. Existing numbers win.
    const incoming = backup.contacts.map(validate), next = contacts.slice();
    const numbers = new Set(next.map(c => c.number));
    for (const contact of incoming) {
      if (numbers.has(contact.number)) continue;
      numbers.add(contact.number); next.push({ id: makeId(), ...contact });
    }
    if (next.length > LIMIT) throw new Error('This backup would exceed the 500-contact limit.');
    return { contacts: next, added: next.length - contacts.length, skipped: incoming.length - (next.length - contacts.length) };
  }
  function displayNumber(number) {
    const national = number.startsWith('+44') ? '0' + number.slice(3) : number;
    return /^\d{11}$/.test(national) ? national.slice(0, 5) + ' ' + national.slice(5) : national;
  }
  globalThis.AGENT_CARDS_CONTACTS = { KEY, LIMIT, validate, read, upsert, merge, displayNumber };
  if (typeof module !== 'undefined' && module.exports) module.exports = globalThis.AGENT_CARDS_CONTACTS;
})();
