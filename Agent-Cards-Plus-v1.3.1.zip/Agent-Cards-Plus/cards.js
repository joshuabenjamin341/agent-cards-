/* Reads loaded Genesys rows, adds reversible presentation and local controls.
   Never replaces, moves, or edits the underlying agent data or timers. */
(() => {
  if (globalThis.__agentCardsLoaded) return;
  globalThis.__agentCardsLoaded = true;
  const isDemo = location.protocol === 'chrome-extension:' && location.pathname.endsWith('/demo.html');
  const hasStorage = !!globalThis.chrome?.storage?.sync;
  let settings = {...AC.defaults}, pins = new Set(), paused = false;
  let boards = new Map(), containers = [], last = performance.now(), raf = 0;
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const pinKey = `agentCardsPins:${location.hostname}`;
  const filters = ['All agents','Ready','Interacting','Available','On break','Away / meeting','Busy','After-call work','Offline','Other'];
  const kinds = ['all','ready','call','available','break','away','busy','wrap','offline','other'];
  const labels = {ready:'Ready',call:'Interacting',available:'Available',break:'On break',away:'Away',busy:'Busy',wrap:'After-call work',offline:'Offline',other:'Other'};
  const scrollState = new WeakMap();
  let fitTimer = 0;
  const fitter = AC_FIT.create(scheduleFit);
  function scheduleFit() {
    if (fitTimer || document.hidden) return;
    fitTimer = setTimeout(() => {fitTimer=0;fitBoards();discoverScroll();},100);
  }
  function fitBoards() {
    if (document.hidden) return;
    fitter.update(boards.values(),settings);
    for (const board of boards.values()) {
      board.fitButton.classList.toggle('ac-selected',settings.autoFit);
      board.fitButton.setAttribute('aria-pressed',String(settings.autoFit));
      board.fitInfo.hidden=!settings.autoFit;
      const fit=board.fit;
      setText(board.fitInfo,fit?`Auto · ${fit.columns} ${fit.columns===1?'column':'columns'} · ${Math.round(fit.scale*100)}%${fit.overflow?' · scroll to see more':''}`:'Auto fit · waiting for space / rows');
    }
  }
  function el(tag, cls, text) { const n=document.createElement(tag); if(cls)n.className=cls; if(text!=null)n.textContent=text; return n; }
  function button(text, title, fn) {const b=el('button','ac-button',text);b.type='button';b.title=title;b.addEventListener('click',fn);return b;}
  function setText(node, text) {if(node.textContent!==String(text))node.textContent=text;}
  function apply() {
    const root=document.documentElement;
    for(const [name,on] of Object.entries({large:settings.style==='large',compact:settings.style==='compact','auto-fit':settings.autoFit,'text-fit':settings.autoFit||settings.textScale!==1,'no-glow':!settings.callGlow,'no-pulse':!settings.glowPulse||settings.reduceMotion||motion.matches,'keep-timer':!settings.callTimerReplaces,wallboard:settings.wallboard,'reduce-motion':settings.reduceMotion||motion.matches})) root.classList.toggle(`agent-cards-${name}`,on);
    root.dataset.acTheme=settings.theme;
    root.style.setProperty('--ac-accent',AC.accents[settings.accent]);
    root.style.setProperty('--agent-cards-wallboard-h',settings.wallboardHeight+'vh');
    root.style.setProperty('--agent-cards-cols',settings.columns);
    root.style.setProperty('--agent-cards-scale',settings.fontScale);
    root.style.setProperty('--agent-cards-text-scale',settings.textScale);
    for(const board of boards.values()) {board.sort.value=settings.sort;board.host.hidden=!settings.toolbar;}
    refresh();
    startScroll();
  }
  if(hasStorage) {
    chrome.storage.sync.get(AC.defaults).then(s=>{settings=AC.sanitize(s);apply();}).catch(()=>apply());
    chrome.storage.local.get(pinKey).then(s=>{pins=new Set(Array.isArray(s[pinKey])?s[pinKey].filter(v=>typeof v==='string').slice(0,500):[]);refresh();});
    chrome.storage.onChanged.addListener((changes,area)=>{
      if(area==='sync') {const next={...settings};for(const [k,v] of Object.entries(changes))if(k in AC.defaults)next[k]=v.newValue;settings=AC.sanitize(next);apply();}
      if(area==='local'&&changes[pinKey]) {pins=new Set(changes[pinKey].newValue||[]);refresh();}
    });
  }
  function savePatch(patch) {settings=AC.sanitize({...settings,...patch});apply();if(hasStorage)chrome.storage.sync.set(patch).catch(()=>{});}
  function makeBoard(widget,table) {
    const host=el('div','ac-tools');
    host.setAttribute('role','region');host.setAttribute('aria-label','Agent Cards wallboard controls');
    const top=el('div','ac-tool-top');
    const brand=el('div','ac-tool-brand');brand.append(el('span','ac-live-dot'),el('strong','','AGENT CARDS'),el('span','ac-source',isDemo?'DEMO':'LOADED ROWS'));
    const clock=el('time','ac-clock');const actions=el('div','ac-tool-actions');
    const pause=button('Ⅱ','Pause automatic scrolling',()=>{paused=!paused;updatePause();});
    const full=button('','Enter full screen for this widget',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await widget.requestFullscreen();}catch{setText(note,'Full screen is unavailable here.');}});
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d','M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5');svg.append(path);full.append(svg);full.setAttribute('aria-label',full.title);
    const fitButton=button('Auto fit','Automatically size cards to fit each widget',()=>savePatch({autoFit:!settings.autoFit}));fitButton.setAttribute('aria-pressed',String(settings.autoFit));
    const collapse=button('−','Collapse wallboard controls',()=>{const collapsed=host.classList.toggle('ac-collapsed');setText(collapse,collapsed?'+':'−');collapse.setAttribute('aria-expanded',String(!collapsed));collapse.title=collapsed?'Expand wallboard controls':'Collapse wallboard controls';collapse.setAttribute('aria-label',collapse.title);scheduleFit();});collapse.setAttribute('aria-expanded','true');collapse.setAttribute('aria-label',collapse.title);
    actions.append(clock,fitButton,pause,full,collapse);top.append(brand,actions);
    const summary=el('div','ac-summary');const metrics={};
    for(const [key,label] of [['all','Loaded'],['ready','Ready'],['call','Interacting'],['attention','Attention']]) {
      const b=button('',`Filter by ${label.toLowerCase()}`,()=>{board.attention=key==='attention';board.filter=key==='attention'?'all':key;board.select.value=board.filter;refresh();});
      b.classList.add('ac-metric');b.dataset.metric=key;
      const value=el('b','','0');b.append(value,el('span','',label));summary.append(b);metrics[key]={button:b,value};
    }
    const controls=el('div','ac-filters');
    const search=el('input','ac-search');search.type='search';search.placeholder='Find an agent…';search.setAttribute('aria-label','Search agent names');search.addEventListener('input',()=>{board.search=search.value;refresh();});
    const select=el('select','ac-select');select.setAttribute('aria-label','Filter agent status');kinds.forEach((k,i)=>{const o=el('option','',filters[i]);o.value=k;select.append(o);});select.addEventListener('change',()=>{board.filter=select.value;board.attention=false;refresh();});
    const sort=el('select','ac-select');sort.setAttribute('aria-label','Sort agents');for(const [v,t] of [['original','Original order'],['name','Name A–Z'],['status','Status'],['duration','Longest first']]) {const o=el('option','',t);o.value=v;sort.append(o);}sort.value=settings.sort;sort.addEventListener('change',()=>savePatch({sort:sort.value}));
    const pinned=button('☆','Show pinned agents only',()=>{board.onlyPins=!board.onlyPins;refresh();});pinned.setAttribute('aria-label','Show pinned agents only');
    const clear=button('Reset','Clear search and filters',()=>{search.value='';board.search='';board.filter='all';select.value='all';board.onlyPins=false;board.attention=false;refresh();});
    controls.append(search,select,sort,pinned,clear);
    const foot=el('div','ac-tool-foot');const note=el('span','ac-note');const fitInfo=el('span','ac-fit-info');fitInfo.hidden=true;const help=el('span','ac-scope','Current loaded rows only');help.title='Counts and alerts use only the rows Genesys has loaded in this widget. They are not organisation-wide totals.';foot.append(note,fitInfo,help);
    const empty=el('p','ac-empty','No agents match these filters.');empty.hidden=true;
    host.append(top,summary,controls,foot,empty);
    table.before(host);
    const board={widget,table,host,clock,pause,fitButton,fitInfo,metrics,search:'',filter:'all',attention:false,onlyPins:false,select,sort,pinned,note,empty,visibleRows:[]};
    return board;
  }
  function rowData(row,index) {
    const cell=row.querySelector('.column-agent');
    const anchor=cell?.querySelector('.hyperlink-cell a')||cell?.querySelector('a');
    const name=(anchor?.textContent||cell?.textContent||'').replace(/[☆★]/g,'').trim();
    if(!cell||!name)return null;
    const label=row.querySelector('.additional-label')?.textContent||row.querySelector('.column-statusAndPresence')?.textContent||'';
    const dot=row.querySelector('.entity-v3-presence-indicator-dot');
    const kind=AC.status(label,dot?.className||'');
    const timer=kind==='call'&&settings.callTimerReplaces?(row.querySelector('.time-duration')||row.querySelector('.time-in-status')):row.querySelector('.time-in-status');
    const seconds=AC.duration(timer?.textContent);
    const id=anchor?.getAttribute('href');const key=id&&id!=='#'&&!id.startsWith('javascript:')?`id:${id}`:`name:${name.toLowerCase()}`;
    return {row,cell,name,key,kind,seconds,index,pinned:pins.has(key),alert:settings.alerts&&seconds!==null&&seconds>=AC.threshold(kind,settings)};
  }
  function decorate(d) {
    const {row,cell}=d;
    row.dataset.acStatus=d.kind;
    row.classList.toggle('ac-overdue',d.alert);
    row.classList.toggle('ac-is-pinned',d.pinned);
    let pin=cell.querySelector(':scope > .ac-pin');
    if(!pin&&settings.showPins) {pin=button('☆','Pin agent',e=>{e.preventDefault();e.stopPropagation();const key=pin.dataset.key;if(pins.has(key))pins.delete(key);else if(pins.size<500)pins.add(key);if(hasStorage)chrome.storage.local.set({[pinKey]:[...pins]}).catch(()=>{});refresh();});pin.classList.add('ac-pin');cell.append(pin);}
    if(pin){pin.hidden=!settings.showPins;pin.dataset.key=d.key;setText(pin,d.pinned?'★':'☆');pin.title=`${d.pinned?'Unpin':'Pin'} ${d.name}`;pin.setAttribute('aria-label',pin.title);pin.setAttribute('aria-pressed',String(d.pinned));}
  }
  function refresh() {
    if(document.hidden)return;
    const widgets=[...document.querySelectorAll('.widget-type-AGENT_STATUS')];
    for(const [widget,b] of boards)if(!widget.isConnected||!b.table.isConnected){b.host.remove();boards.delete(widget);}
    for(const widget of widgets) {
      const table=widget.querySelector('gux-table');if(!table)continue;
      let board=boards.get(widget);
      if(!board||!board.host.isConnected){if(board)board.host.remove();board=makeBoard(widget,table);boards.set(widget,board);}
      board.host.hidden=!settings.toolbar;
      const rows=[...table.querySelectorAll('tbody tr')].map(rowData).filter(Boolean);
      const counts={all:rows.length,ready:0,call:0,attention:0};
      board.visibleRows=[];
      let visible=0;
      const ranked=rows.slice().sort((a,b)=>{
        if(a.pinned!==b.pinned)return a.pinned?-1:1;
        if(settings.sort==='name')return a.name.localeCompare(b.name,undefined,{numeric:true});
        if(settings.sort==='status')return labels[a.kind].localeCompare(labels[b.kind])||a.name.localeCompare(b.name);
        if(settings.sort==='duration')return (b.seconds??-1)-(a.seconds??-1)||a.index-b.index;
        return a.index-b.index;
      });
      const ranks=new Map(ranked.map((r,i)=>[r.row,i]));
      for(const d of rows) {
        if(d.kind==='ready'||d.kind==='call')counts[d.kind]++;
        if(d.alert)counts.attention++;
        decorate(d);
        const match=(!settings.hideOffline||d.kind!=='offline')&&(!settings.toolbar||((board.filter==='all'||d.kind===board.filter)&&(!board.attention||d.alert)&&(!board.onlyPins||d.pinned)&&d.name.toLowerCase().includes(board.search.toLowerCase().trim())));
        d.row.classList.toggle('ac-filtered',!match);d.row.style.order=String(ranks.get(d.row));if(match){visible++;board.visibleRows.push(d.row);}
      }
      for(const [key,m] of Object.entries(board.metrics)){setText(m.value,counts[key]);m.button.classList.toggle('ac-selected',key==='attention'?board.attention:!board.attention&&board.filter===key);m.button.setAttribute('aria-pressed',String(m.button.classList.contains('ac-selected')));}
      board.pinned.setAttribute('aria-pressed',String(board.onlyPins));board.pinned.classList.toggle('ac-selected',board.onlyPins);
      setText(board.note,`${visible} of ${rows.length} shown${settings.hideOffline?' · offline hidden':''}`);
      board.empty.hidden=visible>0||rows.length===0;
      board.clock.hidden=!settings.showClock;
      setText(board.clock,new Date().toLocaleTimeString('en-GB',{hour12:!settings.clock24,hour:'2-digit',minute:'2-digit',second:'2-digit'}));
      if(!rows.length)setText(board.note,'Waiting for Genesys agent rows…');
    }
    fitBoards();discoverScroll();updatePause();
  }
  function updatePause() {for(const b of boards.values()){setText(b.pause,paused?'▶':'Ⅱ');b.pause.title=paused?'Resume automatic scrolling':'Pause automatic scrolling';b.pause.setAttribute('aria-label',b.pause.title);b.pause.setAttribute('aria-pressed',String(paused));b.pause.disabled=!settings.autoScroll;}}
  function discoverScroll() {
    const found=new Set();
    for(const b of boards.values())for(let node=b.table;node&&node!==document.body;node=node.parentElement) {
      if(node.scrollHeight-node.clientHeight>4&&/auto|scroll/.test(getComputedStyle(node).overflowY)){found.add(node);break;}
    }
    containers=[...found];
    for(const node of containers)if(!scrollState.has(node)) {
      const s={pos:node.scrollTop,dir:1,until:performance.now()+settings.edgePause*1000};scrollState.set(node,s);
      const pause=()=>{s.until=performance.now()+12000;s.pos=node.scrollTop;};
      node.addEventListener('wheel',pause,{passive:true});node.addEventListener('touchstart',pause,{passive:true});node.addEventListener('pointerdown',pause,{passive:true});node.addEventListener('keydown',pause);
    }
  }
  function frame(now) {
    raf=0;const dt=Math.min((now-last)/1000,.1);last=now;
    if(!document.hidden&&!paused&&!settings.reduceMotion&&!motion.matches)for(const node of containers) {
      if(!node.isConnected)continue;
      const s=scrollState.get(node);const max=node.scrollHeight-node.clientHeight;
      if(max<=0)continue;
      if((settings.pauseOnHover&&node.matches(':hover'))||node.contains(document.activeElement)||now<s.until){s.pos=node.scrollTop;continue;}
      if(Math.abs(node.scrollTop-s.pos)>3){s.pos=node.scrollTop;s.until=now+12000;continue;}
      s.pos=Math.max(0,Math.min(max,s.pos+s.dir*settings.scrollSpeed*dt));node.scrollTop=s.pos;
      if(s.pos>=max){s.dir=-1;s.until=now+settings.edgePause*1000;}else if(s.pos<=0){s.dir=1;s.until=now+settings.edgePause*1000;}
    }
    if(settings.autoScroll&&!document.hidden&&!settings.reduceMotion&&!motion.matches)raf=requestAnimationFrame(frame);
  }
  function startScroll(){if(raf)cancelAnimationFrame(raf);raf=0;last=performance.now();if(settings.autoScroll&&!document.hidden&&!settings.reduceMotion&&!motion.matches)raf=requestAnimationFrame(frame);}
  document.addEventListener('visibilitychange',()=>{refresh();startScroll();});
  globalThis.addEventListener('resize',scheduleFit,{passive:true});
  document.addEventListener('fullscreenchange',scheduleFit);
  motion.addEventListener('change',apply);
  if(globalThis.chrome?.runtime?.onMessage)chrome.runtime.onMessage.addListener((msg,sender,reply)=>{if(msg?.type==='AC_DIAGNOSTICS')reply({widgets:boards.size,rows:[...boards.values()].reduce((n,b)=>n+b.table.querySelectorAll('tbody tr').length,0)});});
  setInterval(refresh,1000);apply();
})();
