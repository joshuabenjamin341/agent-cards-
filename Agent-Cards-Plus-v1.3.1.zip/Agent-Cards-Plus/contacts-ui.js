/* Contacts UI shared by the toolbar popup and full control centre. */
(() => {
  function mount(root=globalThis.document,chrome=globalThis.chrome) {
  const document=root.ownerDocument||root;
  const C=AGENT_CARDS_CONTACTS, $=id=>root.getElementById(id);
  let contacts=[], editingId=null, busy=false, saving=false, ready=false, alive=true, pollTimer, cooldownTimer;
  let callingId=null, cooldownUntil=0, refreshVersion=0;
  const icons={
    phone:'M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8 10a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2z',
    star:'m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3l-5.6 2.9 1.1-6.2L3 9.6l6.2-.9z',
    edit:'m16 3 5 5M4 20l5-1L21 7a2.1 2.1 0 0 0-5-3L4 16z'
  };
  function icon(name) {
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');
    const path=document.createElementNS(svg.namespaceURI,'path');path.setAttribute('d',icons[name]);svg.append(path);return svg;
  }
  function status(text,error=false) {
    $('contactsStatus').textContent=text;
    $('contactsStatus').classList.toggle('error',error);
  }
  function button(text,className) {
    const b=document.createElement('button');b.type='button';b.className=className;
    if(text)b.textContent=text;return b;
  }
  function render() {
    if(!alive)return;
    const focused=(root.activeElement||document.activeElement)?.closest('[data-contact-action]');
    const focusKey=focused ? [focused.dataset.contactId,focused.dataset.contactAction] : null;
    const query=$('contactSearch').value.trim().toLocaleLowerCase('en-GB');
    const digits=query.replace(/\D/g,'');
    const visible=contacts.filter(c=>!query || `${c.name} ${c.label} ${c.number}`.toLocaleLowerCase('en-GB').includes(query) ||
      (digits.length>0 && /^[+\d\s().-]+$/.test(query) && [C.displayNumber(c.number),c.number].some(n=>n.replace(/\D/g,'').includes(digits))))
      .sort((a,b)=>Number(b.favourite)-Number(a.favourite)||a.name.localeCompare(b.name,'en-GB'));
    $('contactCount').textContent=String(contacts.length);
    $('contactList').replaceChildren();
    $('contactEmpty').hidden=visible.length>0;
    $('contactEmptyTitle').textContent=!ready?'Loading your contacts…':contacts.length?'No matching contacts':'Your regular calls, one click away';
    $('contactEmptyText').textContent=contacts.length?'Try another name, label or number.':'Save a colleague, driver or useful office number to get started.';
    $('contactEmptyAdd').hidden=!ready||contacts.length>0;
    $('contactExport').disabled=!ready||contacts.length===0;
    $('contactAdd').disabled=!ready;
    $('contactImport').disabled=!ready||saving;
    for(const c of visible) {
      const item=document.createElement('li');item.className='contact-card';
      const call=button('', 'contact-call');call.dataset.contactAction='call';call.dataset.contactId=c.id;
      call.setAttribute('aria-label',`Call ${c.name} on ${C.displayNumber(c.number)}`);
      call.title=`Call ${c.name} through Genesys now`;
      call.disabled=busy||Date.now()<cooldownUntil;
      const avatar=document.createElement('span');avatar.className='contact-avatar';avatar.setAttribute('aria-hidden','true');
      avatar.textContent=c.name.split(/\s+/).slice(0,2).map(part=>Array.from(part)[0]).join('').toLocaleUpperCase('en-GB');
      const detail=document.createElement('span');detail.className='contact-detail';
      const name=document.createElement('strong');name.textContent=c.name;
      const number=document.createElement('span');number.className='contact-number';number.textContent=C.displayNumber(c.number);
      detail.append(name,number);
      if(c.label){const label=document.createElement('small');label.textContent=c.label;detail.append(label);}
      const action=document.createElement('span');action.className='contact-dial';action.append(icon('phone'));
      const actionText=document.createElement('span');actionText.textContent=busy&&callingId===c.id?'Sending…':'Call';action.append(actionText);
      call.append(avatar,detail,action);
      call.addEventListener('click',e=>{if(e.isTrusted)dial(c);});
      const controls=document.createElement('div');controls.className='contact-controls';
      const star=button('','contact-icon');star.append(icon('star'));star.dataset.contactAction='favourite';star.dataset.contactId=c.id;
      star.setAttribute('aria-pressed',String(c.favourite));star.title=c.favourite?'Remove favourite':'Pin to favourites';
      star.setAttribute('aria-label',`${star.title}: ${c.name}`);star.disabled=saving;
      star.addEventListener('click',()=>mutate({action:'favourite',id:c.id,value:!c.favourite},c.favourite?'Removed from favourites.':'Pinned to favourites.'));
      const edit=button('','contact-icon');edit.append(icon('edit'));edit.title=`Edit ${c.name}`;edit.setAttribute('aria-label',edit.title);
      edit.dataset.contactAction='edit';edit.dataset.contactId=c.id;edit.disabled=saving;
      edit.addEventListener('click',()=>openEditor(c));controls.append(star,edit);item.append(call,controls);$('contactList').append(item);
    }
    if(focusKey)for(const b of $('contactList').querySelectorAll('[data-contact-action]'))if(b.dataset.contactId===focusKey[0]&&b.dataset.contactAction===focusKey[1])b.focus({preventScroll:true});
  }
  function openEditor(contact) {
    if(saving||!ready)return;
    editingId=contact?.id||null;$('contactForm').reset();
    $('contactName').value=contact?.name||'';$('contactNumber').value=contact?.number?C.displayNumber(contact.number):'';
    $('contactLabel').value=contact?.label||'';$('contactFavourite').checked=contact?.favourite===true;
    $('contactFormTitle').textContent=contact?'Edit contact':'New contact';$('contactDelete').hidden=!contact;
    $('contactDeletePrompt').hidden=true;$('contactFormError').textContent='';
    $('contactEditor').hidden=false;$('contactName').focus();
  }
  function closeEditor() {if(saving)return;$('contactEditor').hidden=true;editingId=null;$('contactAdd').focus();}
  function lockForm(on) {for(const control of $('contactForm').elements)control.disabled=on;}
  async function mutate(message,success) {
    if(saving)return false;
    saving=true;lockForm(true);render();
    try {
      const result=await chrome.runtime.sendMessage({type:'AC_CONTACTS_MUTATE',...message});
      if(!result?.ok)throw new Error(result?.error||'Could not save. Try again.');
      contacts=C.read(result.contacts);refreshVersion++;
      status(typeof success==='function'?success(result):success);
      return true;
    } catch(e) {
      if(!$('contactEditor').hidden)$('contactFormError').textContent=e.message;
      status(e.message,true);return false;
    } finally {saving=false;lockForm(false);render();}
  }
  const errors={
    'no-tab':'Open Genesys Agent Workspace and enable its site in Sites.',
    'no-dialer':'Open the Genesys dialler, refresh its tab, then try again.',
    'no-input':'Genesys did not show its number box. Open Agent Workspace and try again.',
    'no-line':'Choose an outbound line or queue in Genesys, then try again.',
    busy:'A call request is already in progress. Check Genesys before trying again.',
    invalid:'This number cannot be called under the existing UK number rules.',
    'missing-contact':'This contact was removed or is no longer valid. Refresh Contacts.',
    timeout:'No confirmation from Genesys. Check the dialler before trying again to avoid a duplicate call.',
    unavailable:'The call outcome is unknown. Check Genesys before trying again.'
  };
  function showCallState(state) {
    if(!state)return;
    const contact=contacts.find(c=>c.id===state.id), name=contact?.name||'your contact';
    if(state.state==='pending')status(`Sending call request for ${name}…`);
    else if(state.state==='sent')status(`Call request sent to Genesys for ${name}.`);
    else status(errors[state.reason]||errors.unavailable,true);
  }
  async function dial(contact) {
    if(busy||Date.now()<cooldownUntil)return;
    busy=true;callingId=contact.id;clearTimeout(pollTimer);render();
    status(`Sending call request for ${contact.name}…`);
    try {
      const result=await chrome.runtime.sendMessage({type:'AC_CONTACT_DIAL',id:contact.id});
      showCallState({id:contact.id,state:result?.ok?'sent':'failed',reason:result?.reason});
    } catch {status(errors.unavailable,true);}
    finally {
      busy=false;callingId=null;cooldownUntil=Date.now()+3000;render();
      clearTimeout(cooldownTimer);cooldownTimer=setTimeout(render,3050);
    }
  }
  async function refresh() {
    if(!alive)return;
    const version=refreshVersion;
    try {
      const result=await chrome.runtime.sendMessage({type:'AC_CONTACTS_LIST'});
      if(!result?.ok)throw new Error(result?.error||'Could not load contacts. Reload the extension.');
      if(version===refreshVersion)contacts=C.read(result.contacts);
      ready=true;
      const state=result.callState;
      busy=state?.state==='pending';callingId=busy?state.id:null;
      if(state&&(busy||Date.now()-state.at<30000))showCallState(state);
      render();if(busy&&alive)pollTimer=setTimeout(refresh,600);
    }catch(e){status(e.message,true);$('contactEmptyTitle').textContent='Contacts could not load';$('contactEmptyText').textContent='Close and reopen the extension to try again.';}
  }
  $('contactAdd').addEventListener('click',()=>openEditor());
  $('contactEmptyAdd').addEventListener('click',()=>openEditor());
  $('contactCancel').addEventListener('click',closeEditor);
  $('contactForm').addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();closeEditor();}});
  $('contactForm').addEventListener('submit',async e=>{
    e.preventDefault();if(saving)return;
    const contact={id:editingId,name:$('contactName').value,number:$('contactNumber').value,label:$('contactLabel').value,favourite:$('contactFavourite').checked};
    try {C.validate(contact);}catch(error){$('contactFormError').textContent=error.message;return;}
    if(await mutate({action:'save',contact},'Contact saved.'))closeEditor();
  });
  $('contactDelete').addEventListener('click',()=>{$('contactDeletePrompt').hidden=false;$('contactDeleteConfirm').focus();});
  $('contactDeleteKeep').addEventListener('click',()=>{$('contactDeletePrompt').hidden=true;$('contactDelete').focus();});
  $('contactDeleteConfirm').addEventListener('click',async()=>{if(await mutate({action:'delete',id:editingId},'Contact deleted.'))closeEditor();});
  $('contactSearch').addEventListener('input',render);
  $('contactExport').addEventListener('click',()=>{
    const data={format:'agent-cards-contacts',version:1,contacts:contacts.map(({id,...c})=>c)};
    const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
    const link=document.createElement('a');link.href=url;link.download='Agent-Cards-Contacts.json';link.click();
    setTimeout(()=>URL.revokeObjectURL(url),30000);status('Contacts backup downloaded.');
  });
  $('contactImport').addEventListener('click',()=>$('contactImportFile').click());
  $('contactImportFile').addEventListener('change',async()=>{
    const file=$('contactImportFile').files[0];if(!file)return;
    try {
      if(file.size>500000)throw new Error('Choose a contacts backup smaller than 500 KB.');
      const backup=JSON.parse(await file.text());C.merge(contacts,backup,()=>crypto.randomUUID());
      await mutate({action:'import',backup},r=>`${r.added} contact(s) added. ${r.skipped} existing number(s) skipped.`);
    }catch(e){status(e instanceof SyntaxError?'This file is not a valid contacts backup.':e.message,true);}
    $('contactImportFile').value='';
  });
  const changed=(changes,area)=>{
    if(area==='local'&&changes[C.KEY]){contacts=C.read(changes[C.KEY].newValue);refreshVersion++;render();}
  };
  chrome.storage.onChanged.addListener(changed);
  render();refresh();
  return ()=>{alive=false;clearTimeout(pollTimer);clearTimeout(cooldownTimer);chrome.storage.onChanged.removeListener?.(changed);};
  }
  globalThis.AC_CONTACTS_UI={mount};
})();
