/* Exact-site permissions and a single-document, confirmed call relay. */
importScripts('sites.js', 'security.js', 'contacts.js', 'notes.js');
const {normaliseNumber,validNumber}=globalThis.AGENT_CARDS_SECURITY;
const pendingDials=new Map(), starting=new Set(), lastRequest=new Map();
const DIAL_TIMEOUT_MS=14000;
let contactWrites=Promise.resolve(), contactCalling=false, contactCallState=null;
for(const event of [chrome.runtime.onInstalled,chrome.runtime.onStartup,chrome.permissions.onRemoved])event.addListener(()=>{
  syncRegistrations().catch(()=>{});syncEdgeRegistration().catch(()=>{});createSelectionMenu();
});
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if (['AC_CONTACTS_LIST','AC_CONTACTS_MUTATE','AC_CONTACT_DIAL','AC_NOTES_LIST','AC_NOTES_MUTATE','AC_DESK_STATE','AC_DESK_SETTINGS','AC_DRAWER_ACCESS'].includes(msg?.type)) {
    (async()=>{
      if(!senderIsContactsUI(sender)&&!(msg.fromDrawer===true&&await senderIsTrustedDrawer(sender)))return {ok:false,error:'Open the extension or its side tab.'};
      if(msg.type==='AC_CONTACTS_LIST')return listContacts();
      if(msg.type==='AC_CONTACTS_MUTATE')return mutateContacts(msg);
      if(msg.type==='AC_CONTACT_DIAL')return callContact(msg);
      if(msg.type==='AC_NOTES_LIST')return listNotes();
      if(msg.type==='AC_NOTES_MUTATE')return mutateNotes(msg);
      if(msg.type==='AC_DRAWER_ACCESS')return {ok:true};
      if(msg.type==='AC_DESK_SETTINGS'){await chrome.runtime.openOptionsPage();return {ok:true};}
      return {ok:true,...await checkConnection()};
    })().then(reply).catch(()=>reply?.({ok:false,error:'Could not save or load your data. Copy any unsaved text before reloading.'}));
    return true;
  }
  if(msg?.type==='AC_CHECK_DISPATCH') {
    senderIsTrustedDispatch(sender).then(allowed=>reply?.({allowed})).catch(()=>reply?.({allowed:false}));
    return true;
  }
  if(msg?.type==='DIAL') {handleDial(msg,sender).then(()=>reply?.({received:true})).catch(()=>{notifyDispatch(sender.tab?.id,{ok:false,reason:'unavailable'});reply?.({received:false});});return true;}
  if(msg?.type==='DIAL_RESULT'&&msg.reqId){
    const entry=pendingDials.get(msg.reqId);
    if(!entry||sender.tab?.id!==entry.targetTabId||sender.frameId!==entry.frameId||sender.documentId!==entry.documentId)return;
    clearTimeout(entry.timer);pendingDials.delete(msg.reqId);
    const reasons=['no-input','no-line','busy','invalid','unavailable'];
    entry.notify({ok:msg.ok===true,reason:reasons.includes(msg.reason)?msg.reason:undefined});
  }
  if(msg?.type==='AC_CHECK_CONNECTION'&&senderIsContactsUI(sender)){
    checkConnection().then(reply).catch(()=>reply({sites:0,tabs:0,dialers:0}));return true;
  }
});
async function senderIsTrustedDispatch(sender){
  if(sender.tab?.id==null||sender.frameId!==0)return false;
  let url;try{url=new URL(sender.url||'');}catch{return false;}
  if(url.protocol!=='https:'||!(await getSites()).includes(url.hostname))return false;
  return hasSitePermission(url.hostname);
}
importScripts('edge-worker.js');
async function permittedTabs(exclude){
  const sites=await getSites();
  const permitted=[];for(const host of sites)if(await hasSitePermission(host))permitted.push(host);
  if(!permitted.length)return [];
  const tabs=await chrome.tabs.query({url:permitted.flatMap(sitePatterns)});
  return tabs.filter(t=>t.id!=null&&t.id!==exclude).sort((a,b)=>Number(!!b.active)-Number(!!a.active)||(b.lastAccessed||0)-(a.lastAccessed||0));
}
async function findDialers(tab){
  try{
    const frames=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:()=>{
      const opener=document.querySelector('#interaction-new-call-outbound-target');
      return !!globalThis.__agentDialGenesysLoaded&&!!opener&&opener.getClientRects().length>0&&getComputedStyle(opener).visibility!=='hidden';
    }});
    return frames.filter(f=>f.result===true&&typeof f.documentId==='string').sort((a,b)=>a.frameId-b.frameId);
  }catch{return [];}
}
async function checkConnection(){
  const sites=await getSites();const tabs=await permittedTabs();let dialers=0;
  for(const tab of tabs)dialers+=(await findDialers(tab)).length;
  return {sites:sites.length,tabs:tabs.length,dialers};
}
async function handleDial(msg,sender){
  if(!(await senderIsTrustedDispatch(sender)))return;
  const id=sender.tab.id;const number=normaliseNumber(msg.number);
  if(!validNumber(number)){notifyDispatch(id,{ok:false,reason:'invalid'});return;}
  if(starting.has(id)||[...pendingDials.values()].some(p=>p.dispatchTabId===id)||(Date.now()-(lastRequest.get(id)||0)<3000)){notifyDispatch(id,{ok:false,reason:'busy'});return;}
  starting.add(id);lastRequest.set(id,Date.now());
  if(lastRequest.size>200)lastRequest.delete(lastRequest.keys().next().value);
  try{await relayDial(number,id);}finally{starting.delete(id);}
}
async function relayDial(number,dispatchTabId,report){
  const notify=typeof report==='function'?report:((status)=>notifyDispatch(dispatchTabId,status));
  if(!validNumber(number)){notify({ok:false,reason:'invalid'});return;}
  const tabs=await permittedTabs(dispatchTabId);
  if(!tabs.length){notify({ok:false,reason:'no-tab'});return;}
  let target,frame;
  // Inspect tabs in preference order. Probing never opens a dialler or places a call.
  for(const tab of tabs){const frames=await findDialers(tab);if(frames.length){target=tab;frame=frames[0];break;}}
  if(!target){notify({ok:false,reason:'no-dialer'});return;}
  if([...pendingDials.values()].some(p=>p.targetTabId===target.id)){notify({ok:false,reason:'busy'});return;}
  const reqId=crypto.randomUUID();
  const timer=setTimeout(()=>{pendingDials.delete(reqId);notify({ok:false,reason:'timeout'});},DIAL_TIMEOUT_MS);
  pendingDials.set(reqId,{dispatchTabId,targetTabId:target.id,frameId:frame.frameId,documentId:frame.documentId,timer,notify});
  try{await chrome.tabs.sendMessage(target.id,{type:'DIAL',number,reqId},{documentId:frame.documentId});}
  catch{if(pendingDials.has(reqId)){clearTimeout(timer);pendingDials.delete(reqId);notify({ok:false,reason:'no-dialer'});}}
}
function notifyDispatch(tabId,status){if(tabId!=null)chrome.tabs.sendMessage(tabId,{type:'DIAL_STATUS',...status},{frameId:0}).catch(()=>{});}

function senderIsContactsUI(sender) {
  // An options page has a tab too. Match the exact extension page, not just a missing tab.
  return sender.id===chrome.runtime.id && (sender.frameId==null || sender.frameId===0) &&
    ['popup.html','options.html'].some(page=>sender.url===chrome.runtime.getURL(page));
}
async function getContacts() {
  const {KEY,read}=AGENT_CARDS_CONTACTS;
  return read((await chrome.storage.local.get(KEY))[KEY]);
}
async function listContacts() {
  await contactWrites;
  return {ok:true,contacts:await getContacts(),callState:contactCallState};
}
function mutateContacts(msg) {
  // One writer across popup and control centre, including bulk imports.
  const task=contactWrites.then(async()=>{
    const C=AGENT_CARDS_CONTACTS, current=await getContacts();
    let next, added, skipped;
    try {
      if(msg.action==='save') next=C.upsert(current,msg.contact,()=>crypto.randomUUID());
      else if(msg.action==='delete') next=current.filter(c=>c.id!==msg.id);
      else if(msg.action==='favourite') {
        if(!current.some(c=>c.id===msg.id)) throw new Error('This contact was removed.');
        next=current.map(c=>c.id===msg.id?{...c,favourite:msg.value===true}:c);
      } else if(msg.action==='import') ({contacts:next,added,skipped}=C.merge(current,msg.backup,()=>crypto.randomUUID()));
      else throw new Error('Unknown contact action.');
    } catch(e) { return {ok:false,error:e.message}; }
    await chrome.storage.local.set({[C.KEY]:next});
    return {ok:true,contacts:next,added,skipped};
  });
  contactWrites=task.catch(()=>{});
  return task;
}
async function callContact(msg) {
  if(contactCalling || Date.now()-(lastRequest.get('contacts')||0)<3000) return {ok:false,reason:'busy'};
  contactCalling=true;
  try {
    await contactWrites;
    const contact=(await getContacts()).find(c=>c.id===msg.id);
    if(!contact || !validNumber(contact.number)) return {ok:false,reason:'missing-contact'};
    // Resolve the saved number here. Never accept a caller-supplied number.
    lastRequest.set('contacts',Date.now());
    contactCallState={id:contact.id,state:'pending',at:Date.now()};
    return await new Promise(resolve=>{
      let settled=false;
      const finish=status=>{
        if(settled)return; settled=true;
        contactCallState={id:contact.id,state:status.ok?'sent':'failed',at:Date.now(),...status};
        resolve(status);
      };
      relayDial(contact.number,undefined,finish).catch(()=>finish({ok:false,reason:'unavailable'}));
    });
  } finally { contactCalling=false; }
}
