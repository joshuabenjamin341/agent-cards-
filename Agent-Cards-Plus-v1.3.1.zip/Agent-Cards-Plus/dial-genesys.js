/* Receives a call request addressed to this exact document by the worker. */
(() => {
  if(globalThis.__agentDialGenesysLoaded)return;
  globalThis.__agentDialGenesysLoaded=true;
  const {normaliseNumber,validNumber}=AGENT_CARDS_SECURITY;
  const seen=new Set();let busy=false;
  const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const visible=node=>!!node&&node.getClientRects().length>0&&getComputedStyle(node).visibility!=='hidden';
  async function waitFor(selector,ms){const until=Date.now()+ms;while(Date.now()<until){const node=document.querySelector(selector);if(visible(node))return node;await sleep(100);}return null;}
  chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
    if(msg?.type!=='DIAL'||typeof msg.reqId!=='string'||sender.id!==chrome.runtime.id)return;
    reply({received:true});
    if(seen.has(msg.reqId))return;
    if(busy){report(msg.reqId,{ok:false,reason:'busy'});return;}
    const number=normaliseNumber(msg.number);
    if(!validNumber(number)){report(msg.reqId,{ok:false,reason:'invalid'});return;}
    seen.add(msg.reqId);if(seen.size>100)seen.delete(seen.values().next().value);
    busy=true;dial(number,msg.reqId).catch(()=>report(msg.reqId,{ok:false,reason:'unavailable'})).finally(()=>{busy=false;});
  });
  async function dial(number,reqId){
    const opener=document.querySelector('#interaction-new-call-outbound-target');
    if(!visible(opener))return report(reqId,{ok:false,reason:'unavailable'});
    let input=document.querySelector('input.phone-number-input');
    if(!visible(input)){opener.click();input=await waitFor('input.phone-number-input',3000);}
    if(!input)return report(reqId,{ok:false,reason:'no-input'});
    input.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,number);
    input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
    input.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:number.slice(-1)}));
    const until=Date.now()+3500;
    while(Date.now()<until){
      const b=document.querySelector('button.make-call');
      if(visible(b)&&!b.disabled&&b.getAttribute('aria-disabled')!=='true'&&!b.classList.contains('disabled')){
        if(!input.isConnected||normaliseNumber(input.value)!==number)return report(reqId,{ok:false,reason:'invalid'});
        b.click();report(reqId,{ok:true});return;
      }
      await sleep(100);
    }
    // A disabled button is a failed precondition, never permission to press Enter.
    report(reqId,{ok:false,reason:'no-line'});
  }
  function report(reqId,result){chrome.runtime.sendMessage({type:'DIAL_RESULT',reqId,...result}).catch(()=>{});}
})();
