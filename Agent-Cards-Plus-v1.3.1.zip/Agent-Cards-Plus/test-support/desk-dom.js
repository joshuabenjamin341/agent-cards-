/* Minimal simulated DOM for lifecycle/interaction checks, not a rendering engine. */
function dom() {
 const observers=new Set();let document;
 const changed=()=>{for(const o of observers)queueMicrotask(()=>observers.has(o)&&o.callback());};
 class Element {
  constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.dataset={};this.events={};this.value='';this.checked=false;this.hidden=false;this.disabled=false;this.inert=false;this._text='';this.className='';this.style={setProperty(k,v){this[k]=v;}};this.classList={contains:c=>this.className.split(' ').includes(c),toggle:(c,on)=>{on=on??!this.classList.contains(c);this.className=this.className.split(' ').filter(x=>x&&x!==c).concat(on?[c]:[]).join(' ');return on;}};}
  get isConnected(){return this===document.documentElement||!!this.parentNode?.isConnected||!!this.host?.isConnected;}
  set textContent(v){this._text=String(v);this.children=[];}get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
  setAttribute(k,v){this.attributes[k]=String(v);if(k==='class')this.className=String(v);if(k==='id')this.id=String(v);if(k==='type')this.type=v;if(k==='hidden')this.hidden=true;if(k==='disabled')this.disabled=true;if(k.startsWith('data-'))this.dataset[k.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=String(v);}
  getAttribute(k){return this.attributes[k]??null;}
  append(...items){for(const e of items){e.parentNode=this;this.children.push(e);}changed();}
  appendChild(e){this.append(e);return e;}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(e=>e!==this);this.parentNode=null;changed();}
  replaceChildren(...items){for(const c of this.children)c.parentNode=null;this.children=[];this.append(...items);}
  addEventListener(k,fn){(this.events[k]||=[]).push(fn);}removeEventListener(k,fn){this.events[k]=(this.events[k]||[]).filter(f=>f!==fn);}
  async emit(k,props={}){for(const fn of this.events[k]||[])await fn({isTrusted:true,preventDefault(){},stopPropagation(){},...props});}
  click(){if(!this.disabled)return this.emit('click');}
  matches(s){if(s.startsWith('.'))return this.classList.contains(s.slice(1));if(s.startsWith('#'))return this.id===s.slice(1);if(s.startsWith('['))return this.getAttribute(s.slice(1,-1))!==null;return this.tagName===s;}
  closest(s){return this.matches(s)?this:this.parentNode?.closest(s);}
  querySelectorAll(s){return this.children.flatMap(c=>[...(c.matches(s)?[c]:[]),...c.querySelectorAll(s)]);}
  querySelector(s){return this.querySelectorAll(s)[0]||null;}
  getElementById(id){return this.querySelector('#'+id);}
  attachShadow(){const r=new Element('#shadow');r.host=this;this.shadow=r;return r;}
  focus(){document.activeElement=this;let n=this;while(n?.parentNode)n=n.parentNode;if(n?.host)n.activeElement=this;}
  select(){}reset(){for(const e of this.elements){e.value='';e.checked=false;}}
  get elements(){return this.querySelectorAll('input').concat(this.querySelectorAll('button'),this.querySelectorAll('textarea'));}
  set innerHTML(html){this.children=[];const stack=[this],voids=new Set(['input','br','hr','img','meta','link']);for(const token of html.match(/<[^>]+>|[^<]+/g)||[]){if(token.startsWith('</')){stack.pop();continue;}if(token.startsWith('<')){if(token.startsWith('<!'))continue;const tag=token.match(/^<([\w-]+)/)?.[1];if(!tag)continue;const e=new Element(tag);for(const a of token.matchAll(/([\w-]+)(?:="([^"]*)")?/g)){if(a.index===1)continue;e.setAttribute(a[1],a[2]??'');}stack.at(-1).append(e);if(!voids.has(tag)&&!token.endsWith('/>'))stack.push(e);}else{const e=new Element('#text');e.textContent=token;stack.at(-1)?.append(e);}}}
 }
 document=new Element('#document');document.documentElement=new Element('html');document.append(document.documentElement);document.activeElement=null;document.createElement=t=>new Element(t);document.createElementNS=(ns,t)=>{const e=new Element(t);e.namespaceURI=ns;return e;};document.execCommand=()=>true;
 class MutationObserver{constructor(callback){this.callback=callback;}observe(){observers.add(this);}disconnect(){observers.delete(this);}}
 return {document,Element,MutationObserver};
}
module.exports={dom};
