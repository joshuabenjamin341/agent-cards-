/* Dispatch-side hook for click-to-dial. Hardened build.
   - Reads the number from a driver `.init-call` click OR the "Connecting to …"
     popup (customer / "y" / CALL CUSTOMER).
   - Validates against an allow-list AND a premium-rate deny-list.
   - Requires a genuine human click (event.isTrusted) both to start the flow
     from a number click and to confirm the dial — page scripts cannot forge
     isTrusted, so injected code cannot click "Call" for the agent.
   - Renders its confirm dialog and toast inside a CLOSED shadow root, so page
     CSS/JS cannot restyle them or alter the number the agent is shown.
   - Dedupes so the same number can't fire twice.
   Residual risk (documented): a compromised dispatch page can still DISPLAY a
   deceptive prompt or fake popup; it cannot complete a call without a real
   human click on this extension's own dialog, cannot change the number that
   dialog dials, and cannot pass a number outside the allow-list — which the
   background worker independently re-checks. */
(() => {
  if (globalThis.__agentDialDispatchLoaded) return;
  globalThis.__agentDialDispatchLoaded = true;

  // The call popup renders in the top frame; ignoring subframes shrinks the
  // attack surface. (If your dispatch app runs inside an iframe, remove this.)
  if (window !== window.top) return;

  // ── Number validation ───────────────────────────────────────────────────
  // Shared rules from security.js (loaded before this file — see CONTENT_JS
  // in sites.js). The service worker independently re-checks with the SAME
  // functions, so this page-side check is UX, not the security boundary.
  const { normaliseNumber, validNumber } = globalThis.AGENT_CARDS_SECURITY;

  // ── Extension-owned UI root (closed shadow DOM) ─────────────────────────
  // Page styles/scripts can't reach inside a closed shadow root, so what the
  // agent sees in our dialog is what actually gets dialled.
  let shadow = null;
  let toastEl, toastTimer, popupObserver, cancelConfirmation;
  const guard = AGENT_CARDS_DIAL_LIFECYCLE.claim({ onStop: stopDispatchUI });
  if (!guard.isActive()) return;
  function stopDispatchUI() {
    cancelConfirmation?.();
    popupObserver?.disconnect();
    document.removeEventListener('click', onDispatchClick, true);
    try { chrome.storage.onChanged.removeListener(onSettingsChange); } catch {}
    try { chrome.runtime.onMessage.removeListener(onDialStatus); } catch {}
    clearTimeout(toastTimer);
    shadow?.host.remove();
  }
  function uiRoot() {
    if (shadow && shadow.host.isConnected) return shadow;
    const host = document.createElement('div');
    host.style.setProperty('display', 'block', 'important');
    host.style.setProperty('position', 'fixed', 'important');
    host.style.setProperty('z-index', '2147483647', 'important');
    shadow = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = `
      :host { color-scheme: dark; }
      * { box-sizing: border-box; }
      .ac-overlay { position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(6,9,17,.7);backdrop-filter:blur(7px);padding:20px; }
      .ac-dialog { background:radial-gradient(at 100% 0%,#31223e88,transparent 65%),#121722;color:#edf0fa;border:1px solid #453552;max-width:380px;width:100%;border-radius:22px;padding:28px;font:400 14px/1.5 system-ui,sans-serif;box-shadow:0 24px 90px #0008;text-align:center; }
      .ac-icon { width:54px;height:54px;background:#a78ce918;border:1px solid #a78ce92a;border-radius:17px;display:grid;place-items:center;margin:0 auto 18px;color:#c8b5ff; }
      .ac-icon svg { width:25px;height:25px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round; }
      .ac-kicker { font-size:9px;font-weight:650;letter-spacing:2px;color:#a59ab8;margin:0 0 7px; }
      .ac-title { margin:0 0 13px;font-size:23px;line-height:1.3;font-weight:650;letter-spacing:-.5px; }
      .ac-number { margin:0 0 13px;padding:14px 10px;background:#0b101c;border:1px solid #2b3041;border-radius:11px;font:20px/1.4 ui-monospace,Consolas,monospace;color:#dfd2ff;overflow-wrap:anywhere; }
      .ac-caption { color:#9aa6bd;font-size:12px;margin:0 0 23px; }
      .ac-actions { display:flex;gap:10px; }
      .ac-button { flex:1;padding:11px 8px;border:1px solid #363f50;border-radius:10px;font:600 12px/1.5 system-ui,sans-serif;cursor:pointer;background:#222937;color:#c6cfdf;transition:background .18s,transform .18s; }
      .ac-button:hover { background:#2c3446; }
      .ac-button.primary { background:linear-gradient(120deg,#9c7aed,#8060d8);color:white;border-color:#b995ef44;box-shadow:0 4px 20px #9b7aeb19; }
      .ac-button.primary:hover { background:linear-gradient(120deg,#ae8af7,#8e6ee8);transform:translateY(-1px); }
      .ac-button:focus-visible { outline:2px solid #d0b8ff;outline-offset:3px; }
      .ac-shortcuts { color:#78859b;font-size:10px;margin:16px 0 0; }
      .ac-shortcuts kbd { font:9px/1.5 system-ui,sans-serif;background:#ffffff08;border:1px solid #ffffff12;border-radius:4px;padding:1px 4px;margin-right:3px; }
      .ac-toast { position:fixed;z-index:2147483646;bottom:24px;right:24px;display:flex;align-items:center;gap:10px;background:#151b29;color:#e5eaf5;padding:14px 17px;border:1px solid #3a3150;border-radius:13px;font:500 12px/1.5 system-ui,sans-serif;box-shadow:0 10px 35px #0004;max-width:330px;transition:opacity .2s;pointer-events:none; }
      .ac-toast:before { content:'';width:7px;height:7px;border-radius:50%;background:#b59ae9;flex-shrink:0;box-shadow:0 0 12px #b59ae933; }
      .ac-toast[data-kind=ok] { border-color:#366354; }.ac-toast[data-kind=ok]:before { background:#7ce2bd; }
      .ac-toast[data-kind=err] { border-color:#794552; }.ac-toast[data-kind=err]:before { background:#ffa6b2; }
      @media(prefers-reduced-motion:reduce) { * { transition:none!important; }.ac-overlay { backdrop-filter:none; } }
    `;
    shadow.appendChild(style);
    document.documentElement.appendChild(host);
    return shadow;
  }

  // ── Dedupe + confirm gate ───────────────────────────────────────────────
  let lastDial = { number: null, at: 0 };
  let confirming = false;
  let confirmSeconds = 20;
  chrome.storage.sync.get(AGENT_CARDS_DEFAULTS).then(s => { confirmSeconds = AC.sanitize(s).confirmSeconds; }).catch(() => {});
  function onSettingsChange(changes, area) {
    if (area === 'sync' && changes.confirmSeconds) confirmSeconds = AC.sanitize({confirmSeconds: changes.confirmSeconds.newValue}).confirmSeconds;
  }
  chrome.storage.onChanged.addListener(onSettingsChange);

  async function offerDial(raw) {
    if (!guard.isActive()) return;
    const number = normaliseNumber(raw);
    if (!validNumber(number)) { toast('Ignored a number not allowed by policy', 'err'); return; }

    const now = Date.now();
    if (number === lastDial.number && now - lastDial.at < 3000) return; // just dialled this
    if (confirming) return;                                             // a dialog is already open

    confirming = true;
    let ok = false;
    try {
      // A stale content script can remain in an open tab after an update.
      // Verify the live worker and current site before showing any prompt.
      const status = await chrome.runtime.sendMessage({ type: 'AC_CHECK_DISPATCH' });
      if (!status?.allowed || !guard.isActive()) return;
      ok = await confirmCall(number);
    } catch {
      guard.stop();
      return;
    } finally { confirming = false; }
    if (!ok || !guard.isActive()) return;

    lastDial = { number, at: Date.now() };
    toast(`Dialing ${number}…`, 'pending');
    try {
      await chrome.runtime.sendMessage({ type: 'DIAL', number });
    } catch {
      guard.stop();
    }
  }

  // ── Hook 1: driver number click (no popup) ──────────────────────────────
  function onDispatchClick(e) {
    if (!e.isTrusted) return;                 // synthetic clicks can't start a dial
    const el = e.target.closest('.init-call');
    if (!el) return;
    const raw = (el.textContent || '').trim();
    if (raw) offerDial(raw);
  }
  document.addEventListener('click', onDispatchClick, true);

  // ── Hook 2: "Connecting to …" popup ─────────────────────────────────────
  const handled = new WeakSet();

  function extractRawNumber(popup) {
    const body = popup.querySelector('.popup_inner_inner');
    if (!body || !/connecting to/i.test(body.textContent)) return null; // ignore driver-info card
    for (const span of body.querySelectorAll('span')) {
      const t = (span.textContent || '').trim();
      if (!t || t.includes('@')) continue;   // skip the extension/email span
      if (/\d/.test(t)) return t;            // the number span
    }
    return null;
  }

  function handlePopup(popup) {
    if (!popup || handled.has(popup)) return;
    const raw = extractRawNumber(popup);
    if (!raw) return;
    handled.add(popup);
    offerDial(raw);
  }

  for (const p of document.querySelectorAll('.info_popup')) handlePopup(p);

  popupObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.matches?.('.info_popup')) handlePopup(node);
        node.querySelectorAll?.('.info_popup').forEach(handlePopup);
      }
    }
  });
  popupObserver.observe(document.documentElement, { childList: true, subtree: true });

  // ── Confirm dialog (inside the closed shadow root) ──────────────────────
  function confirmCall(number) {
    return new Promise((resolve) => {
      const root = uiRoot();
      const previouslyFocused = document.activeElement;
      const wrap = document.createElement('div');
      wrap.className = 'ac-overlay';
      const box = document.createElement('div');
      box.className = 'ac-dialog';
      box.setAttribute('role', 'dialog');
      box.setAttribute('aria-modal', 'true');
      box.setAttribute('aria-labelledby', 'ac-call-title');
      box.setAttribute('aria-describedby', 'ac-call-number');
      const symbol = document.createElement('div');
      symbol.className = 'ac-icon';
      symbol.setAttribute('aria-hidden', 'true');
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('viewBox', '0 0 24 24');
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', 'M22 16.9v3a2 2 0 0 1-2.2 2A20 20 0 0 1 3.1 5.2 2 2 0 0 1 5.1 3h3a2 2 0 0 1 2 1.7l.5 3.2a2 2 0 0 1-.6 1.8l-1.3 1.3a16 16 0 0 0 4.4 4.4l1.3-1.3a2 2 0 0 1 1.8-.6l3.2.5a2 2 0 0 1 1.6 1.9');
      svg.appendChild(path);
      symbol.appendChild(svg);
      const kicker = document.createElement('p');
      kicker.className = 'ac-kicker';
      kicker.textContent = 'OUTBOUND CALL';
      const title = document.createElement('h2');
      title.className = 'ac-title';
      title.id = 'ac-call-title';
      title.textContent = 'Ready to call?';
      const numberDisplay = document.createElement('div');
      numberDisplay.className = 'ac-number';
      numberDisplay.id = 'ac-call-number';
      numberDisplay.textContent = number;
      const caption = document.createElement('p');
      caption.className = 'ac-caption';
      caption.textContent = `Place this call from Genesys Agent Workspace. Closes after ${confirmSeconds} seconds.`;
      const row = document.createElement('div');
      row.className = 'ac-actions';
      let timer, watchdog, settled = false;
      const buttons = [];
      const cleanup = () => {
        clearTimeout(timer);
        clearInterval(watchdog);
        cancelConfirmation = null;
        // Detach the complete confirmation surface, including its backdrop.
        // A later status notification gets a fresh, non-blocking UI root.
        for (const button of buttons) button.disabled = true;
        wrap.style.setProperty('display', 'none', 'important');
        wrap.remove();
        document.removeEventListener('keydown', onKey, true);
        root.host.remove();
        if (shadow === root) {
          shadow = null;
          toastEl = null;
          clearTimeout(toastTimer);
        }
      };
      const finish = (confirmed) => {
        if (settled) return;
        settled = true;
        try { cleanup(); } finally { resolve(confirmed); }
        // Site focus handlers must not block resolution or reopen the dialog
        // before offerDial has recorded the confirmed request.
        Promise.resolve().then(() => {
          if (previouslyFocused?.isConnected) previouslyFocused.focus({ preventScroll: true });
        }).catch(() => {});
      };
      cancelConfirmation = () => finish(false);
      const onKey = (e) => {
        if (!e.isTrusted) return;
        if (!guard.isActive()) { finish(false); return; }
        if (e.key === 'Escape' || e.key === 'Enter') {
          e.preventDefault();
          e.stopPropagation();
          const confirmed = e.key === 'Enter' && root.activeElement !== buttons[0];
          finish(confirmed);
        }
        if (e.key === 'Tab') {
          e.preventDefault();
          e.stopPropagation();
          const index = buttons.indexOf(root.activeElement);
          buttons[(index + (e.shiftKey ? buttons.length - 1 : 1)) % buttons.length].focus();
        }
      };
      const mkBtn = (label, primary, val) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'ac-button' + (primary ? ' primary' : '');
        b.textContent = label;
        b.addEventListener('click', (e) => {
          if (!e.isTrusted) return;
          e.preventDefault();
          e.stopImmediatePropagation();
          // Dismiss immediately. offerDial rechecks ownership before sending.
          finish(val);
        });
        buttons.push(b);
        return b;
      };
      row.append(mkBtn('Cancel', false, false), mkBtn('Call on Genesys', true, true));
      const shortcuts = document.createElement('p');
      shortcuts.className = 'ac-shortcuts';
      const enter = document.createElement('kbd');
      enter.textContent = 'Enter';
      const escape = document.createElement('kbd');
      escape.textContent = 'Esc';
      shortcuts.append(enter, 'to confirm', ' · ', escape, 'to cancel');
      box.append(symbol, kicker, title, numberDisplay, caption, row, shortcuts);
      wrap.append(box);
      wrap.addEventListener('click', (e) => {
        if (!e.isTrusted) return;
        if (e.target === wrap) finish(false);
      });
      document.addEventListener('keydown', onKey, true);
      root.appendChild(wrap);
      buttons[1].focus();
      timer = setTimeout(() => finish(false), confirmSeconds * 1000);
      watchdog = setInterval(() => { if (!guard.isActive()) finish(false); }, 500);
    });
  }

  // ── Outcome toast (inside the closed shadow root) ───────────────────────
  function onDialStatus(msg) {
    if (!guard.isActive()) return;
    if (msg?.type !== 'DIAL_STATUS') return;
    if (msg.ok)                          toast('Call request sent to Genesys', 'ok');
    else if (msg.reason === 'no-tab')    toast('Genesys isn\u2019t open in this browser', 'err');
    else if (msg.reason === 'no-line')   toast('Pick your outbound queue in Genesys, then click again', 'err');
    else if (msg.reason === 'busy')      toast('A call request is already in progress. Wait a moment.', 'err');
    else if (msg.reason === 'timeout')   toast('No confirmation received. Check Genesys before trying again.', 'err');
    else if (msg.reason === 'invalid')   toast('Blocked: number not allowed by policy', 'err');
    else                                 toast('Open Genesys Agent Workspace, then click again', 'err');
  }
  chrome.runtime.onMessage.addListener(onDialStatus);

  function toast(text, kind) {
    if (!guard.isActive()) return;
    const root = uiRoot();
    if (!toastEl || !toastEl.isConnected) {
      toastEl = document.createElement('div');
      toastEl.className = 'ac-toast';
      toastEl.setAttribute('role', 'status');
      toastEl.setAttribute('aria-live', 'polite');
      root.appendChild(toastEl);
    }
    toastEl.dataset.kind = kind;
    toastEl.textContent = text;
    toastEl.style.opacity = '1';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { if (toastEl) toastEl.style.opacity = '0'; }, kind === 'pending' ? 15000 : 4000);
  }
})();
