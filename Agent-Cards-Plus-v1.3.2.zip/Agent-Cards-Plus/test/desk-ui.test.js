const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {dom}=require('../test-support/desk-dom');
const root=path.resolve(__dirname,'..'),flush=()=>new Promise(r=>setImmediate(r));
function notesFixture({initial=[],deferWrites=false}={}) {
 const d=dom(),exports=[],context=vm.createContext({...d,URL:{createObjectURL(blob){exports.push(blob);return 'blob:notes-test';},revokeObjectURL(){}},Blob,setTimeout:()=>0,clearTimeout});
 for(const file of ['notes.js','notes-ui.js','desk-template.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context);
 d.document.documentElement.innerHTML=context.AC_DESK_TEMPLATE.html;
 let notes=initial,seq=0,version=0,listener;const sent=[],requests=[];
 const api={storage:{onChanged:{addListener:fn=>listener=fn,removeListener(){}}},runtime:{sendMessage:async msg=>{
  sent.push(msg);if(msg.type==='AC_NOTES_LIST')return {ok:true,notes,revision:version};
  const commit=()=>{
   notes=context.AGENT_CARDS_NOTES.mutate(notes,msg,()=>`note${++seq}`,Date.now());version++;
   listener({agentCardsNotesV1:{newValue:notes},agentCardsNotesRevisionV1:{newValue:version}},'local');return {ok:true,notes,revision:version};
  };
  if(deferWrites)return new Promise((resolve,reject)=>requests.push({commit,resolve,reject}));
  return commit();
 }}};
 context.AC_NOTES_UI.mount(d.document,api);
 return {...d,sent,requests,exports,get notes(){return notes;},$:id=>d.document.getElementById(id)};
}
test('notes UI saves every input immediately and preserves focus and line breaks',async()=>{
 const f=notesFixture();await flush();await f.$('noteAdd').click();await flush();
 const field=f.$('notesList').querySelector('textarea');field.focus();field.value='Ring driver\nCheck booking';await field.emit('input');
 assert.equal(f.sent.at(-1).patch.text,field.value);await flush();assert.equal(f.notes[0].text,field.value);assert.equal(f.document.activeElement,field);
});
test('marking a note for handover and copying does not send it externally',async()=>{
 const f=notesFixture();await flush();await f.$('noteAdd').click();await flush();
 const card=f.$('notesList').children[0],field=card.querySelector('textarea');field.value='Customer to call back';await field.emit('input');await flush();
 const mark=card.querySelector('.note-handover').querySelector('input');mark.checked=true;await mark.emit('change');await flush();
 assert.equal(f.$('copyHandover').disabled,false);await f.$('copyHandover').click();assert.match(f.$('handoverCopy').value,/Customer to call back/);
 assert.ok(f.sent.every(m=>m.type==='AC_NOTES_LIST'||m.type==='AC_NOTES_MUTATE'));
});
test('completed notes leave Outstanding but are retained in All notes',async()=>{
 const f=notesFixture();await flush();await f.$('noteAdd').click();await flush();
 const card=f.$('notesList').children[0],check=card.querySelector('input');check.checked=true;await check.emit('change');await flush();assert.equal(card.hidden,true);
 const all=f.document.querySelectorAll('[data-note-filter]').find(b=>b.dataset.noteFilter==='all');await all.click();assert.equal(card.hidden,false);assert.equal(f.notes.length,1);
});
const savedNote={id:'saved',text:'Old details',done:false,handover:true,createdAt:100,updatedAt:100};
test('handover copy and note export include the latest draft while its save is pending',async()=>{
 const f=notesFixture({initial:[savedNote],deferWrites:true});await flush();
 const field=f.$('notesList').querySelector('textarea');field.value='Ring driver\nNew pickup time';await field.emit('input');
 await f.$('copyHandover').click();assert.match(f.$('handoverCopy').value,/New pickup time/);
 await f.$('exportNotes').click();assert.match(await f.exports[0].text(),/New pickup time/);
 f.requests[0].resolve(f.requests[0].commit());await flush();
});
test('an older note acknowledgement cannot erase a newer committed snapshot',async()=>{
 const f=notesFixture({initial:[savedNote],deferWrites:true});await flush();
 const field=f.$('notesList').querySelector('textarea');field.value='First edit';await field.emit('input');
 const first=f.requests[0].commit();field.value='Latest edit';await field.emit('input');
 f.requests[1].resolve(f.requests[1].commit());await flush();
 f.requests[0].resolve(first);await flush();
 assert.equal(field.value,'Latest edit');await f.$('copyHandover').click();assert.match(f.$('handoverCopy').value,/Latest edit/);
});
test('repeating the same note text does not acknowledge a later edit too early',async()=>{
 const f=notesFixture({initial:[savedNote],deferWrites:true});await flush();
 const field=f.$('notesList').querySelector('textarea');
 field.value='A';await field.emit('input');const first=f.requests[0].commit();
 field.value='B';await field.emit('input');field.value='A';await field.emit('input');
 f.requests[0].resolve(first);await flush();
 f.requests[1].resolve(f.requests[1].commit());await flush();assert.equal(field.value,'A');
 f.requests[2].resolve(f.requests[2].commit());await flush();assert.equal(field.value,'A');
});
test('pending handover and completion choices survive an earlier text save',async()=>{
 const f=notesFixture({initial:[{...savedNote,handover:false}],deferWrites:true});await flush();
 const card=f.$('notesList').children[0],field=card.querySelector('textarea'),mark=card.querySelector('.note-handover').querySelector('input');
 field.value='Revised details';await field.emit('input');mark.checked=true;const marking=mark.emit('change');await flush();
 f.requests[0].resolve(f.requests[0].commit());await flush();assert.equal(mark.checked,true);
 await f.$('copyHandover').click();assert.match(f.$('handoverCopy').value,/Revised details/);
 const complete=card.querySelector('input');complete.checked=true;const completing=complete.emit('change');await flush();
 f.requests[1].resolve(f.requests[1].commit());await marking;assert.equal(complete.checked,true);assert.equal(f.$('copyHandover').disabled,true);
 f.requests[2].resolve(f.requests[2].commit());await completing;
});
function drawerFixture({allowed=true,subframe=false,deferLocal=false,deferSync=false}={}) {
 const d=dom();let storageListeners=new Set(),intervals=new Map(),seq=0,contactMounts=0,noteMounts=0,destroys=0,finishLocal,finishSync;const sent=[],writes=[];
 const window={};window.top=subframe?{}:window;
 const chrome={runtime:{getManifest:()=>({version:'1.3.1'}),sendMessage:async msg=>{sent.push(msg);return msg.type==='AC_DRAWER_ACCESS'?{ok:allowed}:{ok:true,dialers:1};}},storage:{local:{async get(){return deferLocal?new Promise(resolve=>finishLocal=()=>resolve({deskTab:'notes'})):{deskTab:'notes'};},async set(patch){writes.push(patch);}},sync:{async get(defaults){return deferSync?new Promise(resolve=>finishSync=()=>resolve({...defaults})):{...defaults};}},onChanged:{addListener:fn=>storageListeners.add(fn),removeListener:fn=>storageListeners.delete(fn)}}};
 const context=vm.createContext({...d,window,location:{protocol:'https:'},chrome,setInterval:fn=>{intervals.set(++seq,fn);return seq;},clearInterval:id=>intervals.delete(id),AC_CONTACTS_UI:{mount(){contactMounts++;return()=>destroys++;}},AC_NOTES_UI:{mount(){noteMounts++;return()=>destroys++;}}});
 for(const file of ['defaults.js','desk-template.js','edge-drawer.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),context);
 const host=()=>d.document.querySelector('[data-agent-cards-desk-host]');
 return {...d,host,context,sent,intervals,writes,storageListeners,finishLocal:()=>finishLocal(),finishSync:()=>finishSync(),change:(changes,area)=>{for(const fn of storageListeners)fn(changes,area);},mounts:()=>[contactMounts,noteMounts],destroys:()=>destroys,reinject:()=>vm.runInContext(fs.readFileSync(path.join(root,'edge-drawer.js'),'utf8'),context)};
}
test('drawer starts collapsed, opens on a trusted click and keeps notes mounted on close',async()=>{
 const f=drawerFixture();await flush();const r=f.host().shadow,launcher=r.getElementById('deskLauncher');
 assert.equal(r.getElementById('deskShell').inert,true);assert.equal(launcher.getAttribute('aria-expanded'),'false');
 assert.equal(f.sent.filter(m=>m.type==='AC_DESK_STATE').length,0);
 await launcher.click();assert.equal(r.getElementById('deskShell').inert,false);assert.equal(launcher.getAttribute('aria-expanded'),'true');
 await r.getElementById('deskClose').click();assert.equal(r.getElementById('deskShell').inert,true);assert.deepEqual(f.mounts(),[1,1]);
 assert.equal(f.destroys(),0);
});
test('drawer does not open from generated clicks and Escape closes it',async()=>{
 const f=drawerFixture();await flush();const r=f.host().shadow,b=r.getElementById('deskLauncher');await b.emit('click',{isTrusted:false});assert.equal(b.getAttribute('aria-expanded'),'false');
 await b.click();await r.emit('keydown',{key:'Escape'});assert.equal(b.getAttribute('aria-expanded'),'false');
});
test('drawer does not mount in subframes or without permission',async()=>{
 for(const options of [{subframe:true},{allowed:false}]){const f=drawerFixture(options);await flush();assert.equal(f.host(),null);assert.deepEqual(f.mounts(),[0,0]);}
});
test('reinjecting drawer scripts retains one tab and one set of UI listeners',async()=>{
 const f=drawerFixture();await flush();f.reinject();await flush();assert.equal(f.document.querySelectorAll('[data-agent-cards-desk-host]').length,1);assert.deepEqual(f.mounts(),[1,1]);
});
test('removing a stale drawer tears down its controllers and liveness timer',async()=>{
 const f=drawerFixture();await flush();f.host().remove();await flush();assert.equal(f.destroys(),2);assert.equal(f.intervals.size,0);
});
test('removing the drawer during startup cannot leave mounted controllers or timers behind',async()=>{
 const f=drawerFixture({deferLocal:true});await flush();f.host().remove();await flush();
 f.finishLocal();await flush();
 assert.deepEqual(f.mounts(),[0,0]);assert.equal(f.intervals.size,0);assert.equal(f.storageListeners.size,0);
});
test('hiding the side tab during a slow settings read cancels its startup',async()=>{
 const f=drawerFixture({deferSync:true});await flush();
 f.change({edgeHidden:{newValue:true}},'local');f.finishSync();await flush();
 assert.equal(f.host()===null,true);assert.deepEqual(f.mounts(),[0,0]);assert.equal(f.intervals.size,0);assert.equal(f.storageListeners.size,0);
});
test('a slow saved-tab read cannot undo a tab the user has just chosen',async()=>{
 const f=drawerFixture({deferLocal:true});await flush();const r=f.host().shadow;
 await r.getElementById('tab-contacts').click();f.finishLocal();await flush();
 assert.equal(r.getElementById('tab-contacts').getAttribute('aria-selected'),'true');
 assert.equal(f.writes.at(-1).deskTab,'contacts');
});
test('theme changes arriving during startup override an older preference snapshot',async()=>{
 const f=drawerFixture({deferSync:true});await flush();
 f.change({theme:{newValue:'paper'}},'sync');f.finishSync();await flush();
 assert.equal(f.host().dataset.theme,'paper');
});
