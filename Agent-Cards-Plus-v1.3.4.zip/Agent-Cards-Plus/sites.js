/* Site registration, shared by popup.js and background.js.
   Users enable exact HTTPS hosts from the popup. Each host requires a
   browser permission grant and is saved in chrome.storage.local.
   No managed-storage configuration or IT host approval is required. */

const SITES_KEY = 'sites';
const CONTENT_CSS = ['cards.css'];
const GOOGLE_EDGE_HOSTS = ['www.google.com', 'google.com', 'www.google.co.uk', 'google.co.uk'];
const EDGE_CONTENT_JS = ['defaults.js', 'security.js', 'contacts.js', 'notes.js', 'contacts-ui.js', 'notes-ui.js', 'desk-template.js', 'edge-drawer.js'];
const CONTENT_JS = ['defaults.js', 'security.js', 'dial-lifecycle.js', 'auto-fit.js', 'cards.js', 'dial-dispatch.js', 'dial-genesys.js', ...EDGE_CONTENT_JS];

function isValidSiteHost(host) {
  if (typeof host !== 'string' || !host || host.includes('*')) return false;
  try {
    const url = new URL(`https://${host}/`);
    return url.hostname === host && !url.port && !url.username && !url.password &&
      url.pathname === '/' && !url.search && !url.hash;
  } catch (e) {
    return false;
  }
}

function sitePatterns(host) {
  if (!isValidSiteHost(host)) throw new Error('Choose an exact HTTPS hostname.');
  return [`https://${host}/*`];
}

function siteScriptId(host) {
  return `agent-cards:${host}`;
}

async function getSites() {
  const stored = await chrome.storage.local.get(SITES_KEY);
  const sites = stored[SITES_KEY];
  return Array.isArray(sites) ? [...new Set(sites.filter(isValidSiteHost))] : [];
}

async function setSites(sites) {
  await chrome.storage.local.set({ [SITES_KEY]: [...new Set(sites.filter(isValidSiteHost))] });
}

async function isRegistered(host) {
  const scripts = await chrome.scripting.getRegisteredContentScripts({
    ids: [siteScriptId(host)],
  });
  return scripts.length > 0;
}

async function registerSite(host) {
  if (!(await hasSitePermission(host))) {
    throw new Error('Grant browser access to this site before enabling it.');
  }
  const id = siteScriptId(host);
  if (await isRegistered(host)) {
    await chrome.scripting.unregisterContentScripts({ ids: [id] });
  }
  await chrome.scripting.registerContentScripts([
    {
      id,
      matches: sitePatterns(host),
      allFrames: true,
      matchOriginAsFallback: true,
      css: CONTENT_CSS,
      js: CONTENT_JS,
      runAt: 'document_idle',
      persistAcrossSessions: true,
    },
  ]);
}

async function unregisterSite(host) {
  if (await isRegistered(host)) {
    await chrome.scripting.unregisterContentScripts({ ids: [siteScriptId(host)] });
  }
}

async function hasSitePermission(host) {
  return chrome.permissions.contains({ origins: sitePatterns(host) });
}

/* Restore enabled sites after an update or restart. Remove stale content
   registrations when a site is disabled or browser access is revoked. */
async function syncRegistrations() {
  const sites = await getSites();
  const enabledIds = new Set(sites.map(siteScriptId));
  const registered = await chrome.scripting.getRegisteredContentScripts();
  const staleIds = registered
    .filter((script) => script.id.startsWith('agent-cards:') && !enabledIds.has(script.id))
    .map((script) => script.id);
  if (staleIds.length) await chrome.scripting.unregisterContentScripts({ ids: staleIds });
  for (const host of sites) {
    if (await hasSitePermission(host)) {
      await registerSite(host);
    } else {
      await unregisterSite(host);
    }
  }
}
