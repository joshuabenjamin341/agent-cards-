(() => {
  if(window.top!==window||!/^https?:$/.test(location.protocol)||globalThis.__acDeskDrawer?.alive)return;
  const instance={alive:true};globalThis.__acDeskDrawer=instance;
  let host,root,stopContacts,stopNotes,observer,checkTimer;
  const bridge={
    runtime:{sendMessage:msg=>chrome.runtime.sendMessage({...msg,fromDrawer:true})},
    storage:{onChanged:chrome.storage.onChanged}
  };
  function destroy() {
    if(!instance.alive)return;instance.alive=false;
    stopContacts?.();stopNotes?.();observer?.disconnect();clearInterval(checkTimer);
    chrome.storage.onChanged.removeListener(changed);host?.remove();
  }
  instance.destroy=destroy;
  function theme(settings) {
    if(!host)return;
    const s=AC.sanitize(settings);host.dataset.theme=s.theme;
    host.style.setProperty('--accent',AC.accents[s.accent]);
    root.querySelector('.desk-frame').classList.toggle('reduce-motion',s.reduceMotion);
  }
  let prefs={};
  function changed(changes,area) {
    if(area==='sync'){for(const [key,value] of Object.entries(changes))prefs[key]=value.newValue;theme(prefs);}
    if(area==='local'&&changes.edgeHidden?.newValue===true)destroy();
  }
  async function boot() {
    const allowed=await bridge.runtime.sendMessage({type:'AC_DRAWER_ACCESS'});
    if(!allowed?.ok){destroy();return;}
    if(!instance.alive)return;
    // A replacement copy removes the previous drawer, which then tears itself down.
    for(const previous of document.querySelectorAll('[data-agent-cards-desk-host]'))previous.remove();
    host=document.createElement('div');host.setAttribute('data-agent-cards-desk-host','');
    host.style.cssText='all:initial!important;position:fixed!important;inset:0 0 0 auto!important;width:min(440px,calc(100vw - 38px))!important;height:100dvh!important;z-index:2147483645!important;pointer-events:none!important;display:block!important;';
    root=host.attachShadow({mode:'closed'});
    const style=document.createElement('style');style.textContent=AC_DESK_TEMPLATE.css;root.append(style);
    const content=document.createElement('div');content.innerHTML=AC_DESK_TEMPLATE.html;root.append(content);document.documentElement.append(host);
    observer=new MutationObserver(()=>{if(!host.isConnected)destroy();});observer.observe(document.documentElement,{childList:true});
    const $=id=>root.getElementById(id),frame=root.querySelector('.desk-frame'),shell=$('deskShell'),launcher=$('deskLauncher');
    shell.inert=true;
    function toggle(open) {
      if(!instance.alive)return;
      try{chrome.runtime.getManifest();}catch{destroy();return;}
      frame.classList.toggle('open',open);shell.inert=!open;
      launcher.setAttribute('aria-expanded',String(open));launcher.title=open?'Close Agent Cards':'Open contacts and shift notes';
      if(open){$('deskClose').focus();checkConnection();}
      else {launcher.focus();}
    }
    launcher.addEventListener('click',e=>{if(e.isTrusted)toggle(!frame.classList.contains('open'));});
    $('deskClose').addEventListener('click',()=>toggle(false));
    // A closed shadow root hides the textarea from page shortcut handlers:
    // outside this root, event.target is the host div instead of the editor.
    // Keep editing events local so page Backspace/clipboard shortcuts cannot
    // cancel them. Do not preventDefault: native editing, undo and caret keys
    // still belong to the focused control, whose own listeners run first.
    for(const type of ['keydown','keypress','keyup','beforeinput','input','copy','cut','paste','compositionstart','compositionupdate','compositionend']) {
      root.addEventListener(type,event=>event.stopPropagation());
    }
    root.addEventListener('keydown',e=>{if(e.defaultPrevented)return;if(e.key==='Escape'){e.preventDefault();e.stopPropagation();toggle(false);}});
    let tabChosen=false;
    function tab(name,persist=true) {
      for(const b of root.querySelectorAll('[data-desk-tab]')){
        const on=b.dataset.deskTab===name;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;$('panel-'+b.dataset.deskTab).hidden=!on;
      }
      if(persist){tabChosen=true;chrome.storage.local.set({deskTab:name}).catch(()=>{});}
    }
    for(const b of root.querySelectorAll('[data-desk-tab]')){
      b.addEventListener('click',()=>tab(b.dataset.deskTab));
      b.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const next=e.key==='Home'?'contacts':e.key==='End'?'notes':b.dataset.deskTab==='contacts'?'notes':'contacts';tab(next);$('tab-'+next).focus();});
    }
    $('deskSettings').addEventListener('click',()=>bridge.runtime.sendMessage({type:'AC_DESK_SETTINGS'}).catch(()=>{}));
    let checking=false;
    async function checkConnection() {
      if(checking)return;checking=true;$('deskConnection').textContent='Checking Genesys…';
      try {
        const result=await bridge.runtime.sendMessage({type:'AC_DESK_STATE'});
        $('deskConnection').textContent=result?.dialers?'● Genesys dialler found':'○ Open Genesys Workspace';
        $('deskConnection').title=result?.dialers?'A visible dialler was found. Your selected outbound line will be used.':'Enable the Genesys site and open Agent Workspace. Click to check again.';
      }catch{$('deskConnection').textContent='Refresh this page to reconnect';}finally{checking=false;}
    }
    $('deskConnection').addEventListener('click',checkConnection);
    const stored=await chrome.storage.local.get('deskTab');
    if(!instance.alive||!host.isConnected){destroy();return;}
    if(!tabChosen)tab(stored.deskTab==='contacts'?'contacts':'notes',false);
    const initialPrefs=await chrome.storage.sync.get(AC.defaults);
    if(!instance.alive||!host.isConnected){destroy();return;}
    prefs={...initialPrefs,...prefs};theme(prefs);
    stopContacts=AC_CONTACTS_UI.mount(root,bridge);stopNotes=AC_NOTES_UI.mount(root,bridge);
    checkTimer=setInterval(()=>{try{chrome.runtime.getManifest();}catch{destroy();}},5000);
  }
  // Observe changes before the first asynchronous read, including cancellation
  // while the drawer's saved tab and appearance are still loading.
  chrome.storage.onChanged.addListener(changed);
  boot().catch(()=>destroy());
})();
