/* Fictional fixture using the same selectors as the supplied Genesys extension. */
(() => {
  const examples=[['Alex Morgan','Ready','idle',161],['Jordan Lee','Interacting','on_queue',252],['Casey Taylor','Break','break',1290],['Sam Parker','Meeting','meeting',726],['Riley Bennett','Ready','idle',41],['Jamie Ellis','Interacting','on_queue',963],['Robin Carter','Available','available',85],['Taylor Brooks','Ready','idle',317],['Drew Harper','After-call work','busy',368],['Quinn Bailey','Away','away',720],['Charlie Reed','Ready','idle',129],['Avery Clarke','Offline','offline',601]];
  let since=Date.now();
  const format=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
  function add(tag,cls,text){const n=document.createElement(tag);n.className=cls;if(text)n.textContent=text;return n;}
  examples.forEach(([name,label,kind,secs],i)=>{
    const row=add('tr','');const agent=add('td','column-agent');const link=add('div','hyperlink-cell');const a=add('a','',name);a.href=`#demo-agent-${i}`;a.addEventListener('click',e=>e.preventDefault());link.append(a);agent.append(link);
    const status=add('td','column-statusAndPresence');const entity=add('div','entity-wrapper');entity.append(add('span',`entity-v3-presence-indicator-dot ${kind}`),add('span','additional-label',label));status.append(entity);
    const timing=add('td','column-unifiedDuration');const cell=add('div','conversation-duration-cell-v2');const timer=add('span','time-in-status',format(secs));timer.dataset.base=secs;cell.append(timer);
    if(kind==='on_queue'){const duration=add('div','duration');const c=add('span','time-duration',format(secs));c.dataset.base=secs;duration.append(c);cell.append(duration);}timing.append(cell);row.append(agent,status,timing);document.getElementById('demoRows').append(row);
  });
  setInterval(()=>{for(const timer of document.querySelectorAll('[data-base]'))timer.textContent=format(+timer.dataset.base+Math.floor((Date.now()-since)/1000));},1000);
  document.getElementById('demoReset').addEventListener('click',()=>{since=Date.now();});
  const layout=document.getElementById('demoLayout'),cols=document.getElementById('demoCols'),fit=document.getElementById('demoFit'),text=document.getElementById('demoText');
  let settings={...AC.defaults};
  function controls(){
    layout.value=settings.style;cols.value=settings.columns;cols.disabled=settings.autoFit;fit.value=settings.autoFit?'auto':'manual';
    if(![...text.options].some(o=>o.value===String(settings.textScale))){const option=document.createElement('option');option.value=settings.textScale;option.textContent=Math.round(settings.textScale*100)+'%';text.append(option);}
    text.value=settings.textScale;
  }
  if(globalThis.chrome?.storage?.sync){
    chrome.storage.sync.get(AC.defaults).then(s=>{settings=AC.sanitize(s);controls();});
    layout.addEventListener('change',()=>chrome.storage.sync.set({style:layout.value}));cols.addEventListener('change',()=>chrome.storage.sync.set({columns:Number(cols.value)}));
    fit.addEventListener('change',()=>chrome.storage.sync.set({autoFit:fit.value==='auto'}));text.addEventListener('change',()=>chrome.storage.sync.set({textScale:Number(text.value)}));
    chrome.storage.onChanged.addListener((c,area)=>{if(area!=='sync')return;for(const [key,value] of Object.entries(c))if(key in AC.defaults)settings[key]=value.newValue;settings=AC.sanitize(settings);controls();});
  } else {layout.disabled=true;cols.disabled=true;fit.disabled=true;text.disabled=true;}
})();
