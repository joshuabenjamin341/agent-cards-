/* Exact-site permissions and a single-document, confirmed call relay. */
importScripts('sites.js', 'security.js', 'contacts.js', 'notes.js');
const {normaliseNumber,validNumber}=globalThis.AGENT_CARDS_SECURITY;
const pendingDials=new Map(), starting=new Set(), lastRequest=new Map();
const targetCooldown=new Map();
const DIAL_TIMEOUT_MS=14000;
let contactWrites=Promise.resolve(), contactCalling=false, contactCallState=null;
for(const event of [chrome.runtime.onInstalled,chrome.runtime.onStartup,chrome.permissions.onRemoved])event.addListener(()=>{
  syncRegistrations().catch(()=>{});syncEdgeRegistration().catch(()=>{});createSelectionMenu();
});
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if (['AC_CONTACTS_LIST','AC_CONTACTS_MUTATE','AC_CONTACT_DIAL','AC_NOTES_LIST','AC_NOTES_MUTATE','AC_DESK_STATE','AC_DESK_SETTINGS','AC_DRAWER_ACCESS'].includes(msg?.type)) {
    (async()=>{
      if(!senderIsContactsUI(sender)&&!(msg.fromDrawer===true&&await senderIsTrustedDrawer(sender)))return {ok:false,error:'Open the extension or its side tab.'};
      if(msg.type==='AC_CONTACTS_LIST')return listContacts();
      if(msg.type==='AC_CONTACTS_MUTATE')return mutateContacts(msg);
      if(msg.type==='AC_CONTACT_DIAL')return callContact(msg);
      if(msg.type==='AC_NOTES_LIST')return listNotes();
      if(msg.type==='AC_NOTES_MUTATE')return mutateNotes(msg);
      if(msg.type==='AC_DRAWER_ACCESS')return {ok:true};
      if(msg.type==='AC_DESK_SETTINGS'){await chrome.runtime.openOptionsPage();return {ok:true};}
      return {ok:true,...await checkConnection()};
    })().then(reply).catch(()=>reply?.({ok:false,error:'Could not save or load your data. Copy any unsaved text before reloading.'}));
    return true;
  }
  if(msg?.type==='AC_CHECK_DISPATCH') {
    senderIsTrustedDispatch(sender).then(allowed=>reply?.({allowed})).catch(()=>reply?.({allowed:false}));
    return true;
  }
  if(msg?.type==='DIAL') {
    handleDial(msg,sender).then(accepted=>reply?.({received:accepted!==false})).catch(()=>{
      notifyDispatch(sender.tab?.id,{ok:false,reason:'unavailable'},{documentId:sender.documentId,clientRequestId:msg.clientRequestId});
      reply?.({received:false});
    });
    return true;
  }
  if(msg?.type==='DIAL_RESULT'&&msg.reqId){
    const entry=pendingDials.get(msg.reqId);
    if(!entry||sender.tab?.id!==entry.targetTabId||sender.frameId!==entry.frameId||sender.documentId!==entry.documentId)return;
    const reasons=['no-input','no-line','busy','invalid','unavailable','expired','ambiguous'];
    entry.notify(Date.now()>=entry.expiresAt?{ok:false,reason:'timeout'}:{ok:msg.ok===true,reason:reasons.includes(msg.reason)?msg.reason:undefined});
  }
  if(msg?.type==='AC_CHECK_CONNECTION'&&senderIsContactsUI(sender)){
    checkConnection().then(reply).catch(()=>reply({sites:0,tabs:0,dialers:0}));return true;
  }
});
async function senderIsTrustedDispatch(sender){
  if(sender.tab?.id==null||sender.frameId!==0)return false;
  let url;try{url=new URL(sender.url||'');}catch{return false;}
  if(url.protocol!=='https:'||!(await getSites()).includes(url.hostname))return false;
  return hasSitePermission(url.hostname);
}
importScripts('edge-worker.js');
async function permittedTabs(exclude){
  const sites=await getSites();
  const permitted=[];for(const host of sites)if(await hasSitePermission(host))permitted.push(host);
  if(!permitted.length)return [];
  const tabs=await chrome.tabs.query({url:permitted.flatMap(sitePatterns)});
  return tabs.filter(t=>t.id!=null&&t.id!==exclude).sort((a,b)=>Number(!!b.active)-Number(!!a.active)||(b.lastAccessed||0)-(a.lastAccessed||0));
}
async function findDialers(tab){
  try{
    const frames=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:()=>{
      return globalThis.__agentCardsDialProtocol===2&&[...document.querySelectorAll('#interaction-new-call-outbound-target')].some(opener=>opener.getClientRects().length>0&&!['hidden','collapse'].includes(getComputedStyle(opener).visibility));
    }});
    return frames.filter(f=>f.result===true&&typeof f.documentId==='string').sort((a,b)=>a.frameId-b.frameId);
  }catch{return [];}
}
async function checkConnection(){
  const sites=await getSites();const tabs=await permittedTabs();let dialers=0;
  for(const tab of tabs)dialers+=(await findDialers(tab)).length;
  return {sites:sites.length,tabs:tabs.length,dialers};
}
function callDeadline(value){
  const limit=Date.now()+DIAL_TIMEOUT_MS;
  return value===undefined?limit:typeof value==='number'&&Number.isFinite(value)?Math.min(value,limit):0;
}
async function beforeDeadline(work,expiresAt){
  const remaining=expiresAt-Date.now();
  const failure=reason=>Object.assign(new Error('Call request deadline reached'),{reason});
  if(remaining<=0)throw failure('expired');
  let timer;
  try{
    const result=await Promise.race([Promise.resolve().then(work),new Promise((_,reject)=>{
      timer=setTimeout(()=>reject(failure('timeout')),remaining);
    })]);
    if(Date.now()>=expiresAt)throw failure('expired');
    return result;
  }finally{clearTimeout(timer);}
}
async function handleDial(msg,sender){
  const expiresAt=callDeadline(msg.expiresAt);
  const report=status=>notifyDispatch(sender.tab?.id,status,{documentId:sender.documentId,clientRequestId:msg.clientRequestId});
  try{if(!(await beforeDeadline(()=>senderIsTrustedDispatch(sender),expiresAt)))return false;}
  catch(error){report({ok:false,reason:error.reason||'unavailable'});return;}
  const id=sender.tab.id;const number=normaliseNumber(msg.number);
  if(!validNumber(number)){report({ok:false,reason:'invalid'});return;}
  if(starting.has(id)||[...pendingDials.values()].some(p=>p.dispatchTabId===id)||(Date.now()-(lastRequest.get(id)||0)<3000)){report({ok:false,reason:'busy'});return;}
  starting.add(id);lastRequest.set(id,Date.now());
  if(lastRequest.size>200)lastRequest.delete(lastRequest.keys().next().value);
  try{await relayDial(number,id,report,expiresAt);}finally{starting.delete(id);}
}
async function relayDial(number,dispatchTabId,report,deadline){
  const notify=typeof report==='function'?report:((status)=>notifyDispatch(dispatchTabId,status));
  if(!validNumber(number)){notify({ok:false,reason:'invalid'});return;}
  const expiresAt=callDeadline(deadline);
  if(expiresAt<=Date.now()){notify({ok:false,reason:'expired'});return;}
  const reqId=crypto.randomUUID();
  let settled=false,submitted=false,target,frame,release;
  const ended=new Promise(resolve=>release=resolve);
  const finish=status=>{
    if(settled)return;settled=true;clearTimeout(timer);pendingDials.delete(reqId);release(null);
    if(submitted){targetCooldown.set(target.id,Date.now());if(targetCooldown.size>200)targetCooldown.delete(targetCooldown.keys().next().value);}
    notify(status);
  };
  const stopped=()=>{if(!settled&&Date.now()>=expiresAt)finish({ok:false,reason:'timeout'});return settled;};
  // Discovery is part of the deadline too. A late probe cannot revive a call.
  const timer=setTimeout(()=>finish({ok:false,reason:'timeout'}),Math.max(0,expiresAt-Date.now()));
  const entry={dispatchTabId,expiresAt,timer,notify:finish};pendingDials.set(reqId,entry);
  const wait=promise=>Promise.race([promise,ended]);
  try{
    const tabs=await wait(permittedTabs(dispatchTabId));if(stopped())return;
    if(!tabs.length){finish({ok:false,reason:'no-tab'});return;}
    // Inspect tabs in preference order. Probing never opens a dialler or calls.
    for(const tab of tabs){const frames=await wait(findDialers(tab));if(stopped())return;if(frames.length){target=tab;frame=frames[0];break;}}
    if(!target){finish({ok:false,reason:'no-dialer'});return;}
    if([...pendingDials.values()].some(p=>p!==entry&&p.targetTabId===target.id)||Date.now()-(targetCooldown.get(target.id)||0)<3000){finish({ok:false,reason:'busy'});return;}
    Object.assign(entry,{targetTabId:target.id,frameId:frame.frameId,documentId:frame.documentId});
    if(stopped())return;submitted=true;
    const receipt=await wait(chrome.tabs.sendMessage(target.id,{type:'DIAL',number,reqId,expiresAt},{documentId:frame.documentId}));
    if(stopped())return;
    if(receipt?.received!==true||receipt.protocol!==2)finish({ok:false,reason:'unavailable'});
  }catch{finish({ok:false,reason:'unavailable'});}
}
function notifyDispatch(tabId,status,source={}){
  if(tabId==null)return;
  const clientRequestId=typeof source.clientRequestId==='string'&&source.clientRequestId.length<=100?source.clientRequestId:undefined;
  const target=typeof source.documentId==='string'?{documentId:source.documentId}:{frameId:0};
  chrome.tabs.sendMessage(tabId,{type:'DIAL_STATUS',...status,clientRequestId},target).catch(()=>{});
}

function senderIsContactsUI(sender) {
  // An options page has a tab too. Match the exact extension page, not just a missing tab.
  return sender.id===chrome.runtime.id && (sender.frameId==null || sender.frameId===0) &&
    ['popup.html','options.html'].some(page=>sender.url===chrome.runtime.getURL(page));
}
async function getContactsSnapshot() {
  const C=AGENT_CARDS_CONTACTS,stored=await chrome.storage.local.get([C.KEY,C.REVISION_KEY]);
  return {contacts:C.read(stored[C.KEY]),revision:C.revision(stored[C.REVISION_KEY])};
}
async function getContacts() {return (await getContactsSnapshot()).contacts;}
async function listContacts() {
  await contactWrites;
  return {ok:true,...await getContactsSnapshot(),callState:contactCallState};
}
function mutateContacts(msg) {
  // One writer across popup and control centre, including bulk imports.
  const task=contactWrites.then(async()=>{
    const C=AGENT_CARDS_CONTACTS, snapshot=await getContactsSnapshot(), current=snapshot.contacts;
    let next, added, skipped;
    try {
      if(msg.action==='save') next=C.upsert(current,msg.contact,()=>crypto.randomUUID());
      else if(msg.action==='delete') next=current.filter(c=>c.id!==msg.id);
      else if(msg.action==='favourite') {
        if(!current.some(c=>c.id===msg.id)) throw new Error('This contact was removed.');
        next=current.map(c=>c.id===msg.id?{...c,favourite:msg.value===true}:c);
      } else if(msg.action==='import') ({contacts:next,added,skipped}=C.merge(current,msg.backup,()=>crypto.randomUUID()));
      else throw new Error('Unknown contact action.');
    } catch(e) { return {ok:false,error:e.message}; }
    const revision=snapshot.revision+1;
    await chrome.storage.local.set({[C.KEY]:next,[C.REVISION_KEY]:revision});
    return {ok:true,contacts:next,revision,added,skipped};
  });
  contactWrites=task.catch(()=>{});
  return task;
}
async function callContact(msg) {
  const expiresAt=callDeadline(msg.expiresAt);
  if(expiresAt<=Date.now())return {ok:false,reason:'expired'};
  if(contactCalling || Date.now()-(lastRequest.get('contacts')||0)<3000) return {ok:false,reason:'busy'};
  contactCalling=true;
  contactCallState={id:msg.id,state:'pending',at:Date.now()};
  const complete=status=>{
    contactCallState={id:msg.id,state:status.ok?'sent':'failed',at:Date.now(),...status};
    return status;
  };
  try {
    const contact=await beforeDeadline(async()=>{
      await contactWrites;
      return (await getContacts()).find(c=>c.id===msg.id);
    },expiresAt);
    if(!contact || !validNumber(contact.number)) return complete({ok:false,reason:'missing-contact'});
    // Resolve the saved number here. Never accept a caller-supplied number.
    lastRequest.set('contacts',Date.now());
    return await new Promise(resolve=>{
      let settled=false;
      const finish=status=>{
        if(settled)return; settled=true;
        resolve(complete(status));
      };
      relayDial(contact.number,undefined,finish,expiresAt).catch(()=>finish({ok:false,reason:'unavailable'}));
    });
  } catch(error) {
    return complete({ok:false,reason:error.reason||'unavailable'});
  } finally { contactCalling=false; }
}
