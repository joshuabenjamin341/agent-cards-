/* Receives a call request addressed to this exact document by the worker. */
(() => {
  if(globalThis.__agentDialGenesysLoaded)return;
  globalThis.__agentDialGenesysLoaded=true;
  globalThis.__agentCardsDialProtocol=2;
  const {normaliseNumber,validNumber}=AGENT_CARDS_SECURITY;
  const seen=new Set();let busy=false,lastClickAt=-Infinity;
  const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const visible=node=>!!node&&node.isConnected&&node.getClientRects().length>0&&!['hidden','collapse'].includes(getComputedStyle(node).visibility);
  const fail=reason=>{throw Object.assign(new Error(reason),{reason});};
  function checkExpiry(expiresAt){if(!Number.isFinite(expiresAt)||Date.now()>=expiresAt||expiresAt-Date.now()>15000)fail('expired');}
  function unique(selector){const nodes=[...document.querySelectorAll(selector)].filter(visible);if(nodes.length>1)fail('ambiguous');return nodes[0]||null;}
  async function waitFor(selector,ms,expiresAt){const until=Math.min(Date.now()+ms,expiresAt);while(Date.now()<until){checkExpiry(expiresAt);const node=unique(selector);if(node)return node;await sleep(Math.min(100,until-Date.now()));}checkExpiry(expiresAt);return null;}
  chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
    if(msg?.type!=='DIAL'||typeof msg.reqId!=='string'||!msg.reqId||msg.reqId.length>100||sender.id!==chrome.runtime.id)return;
    reply({received:true,protocol:2});
    if(seen.has(msg.reqId))return;
    seen.add(msg.reqId);if(seen.size>100)seen.delete(seen.values().next().value);
    try{checkExpiry(msg.expiresAt);}catch{return report(msg.reqId,{ok:false,reason:'expired'});}
    if(busy||Date.now()-lastClickAt<3000){report(msg.reqId,{ok:false,reason:'busy'});return;}
    const number=normaliseNumber(msg.number);
    if(!validNumber(number)){report(msg.reqId,{ok:false,reason:'invalid'});return;}
    busy=true;dial(number,msg.expiresAt).then(()=>report(msg.reqId,{ok:true})).catch(error=>report(msg.reqId,{ok:false,reason:error.reason||'unavailable'})).finally(()=>{busy=false;});
  });
  async function dial(number,expiresAt){
    checkExpiry(expiresAt);
    const opener=unique('#interaction-new-call-outbound-target');
    if(!opener)fail('unavailable');
    let input=unique('input.phone-number-input');
    if(!input){opener.click();input=await waitFor('input.phone-number-input',3000,expiresAt);}
    checkExpiry(expiresAt);
    if(!input||input.disabled||input.matches(':disabled')||input.readOnly)fail('no-input');
    input.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,number);
    input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
    input.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:number.slice(-1)}));
    const until=Math.min(Date.now()+3500,expiresAt);
    while(Date.now()<until){
      checkExpiry(expiresAt);
      if(unique('input.phone-number-input')!==input||input.disabled||input.matches(':disabled')||input.readOnly)fail('no-input');
      if(normaliseNumber(input.value)!==number)fail('invalid');
      const b=unique('button.make-call');
      if(b&&!b.disabled&&!b.matches(':disabled')&&b.getAttribute('aria-disabled')!=='true'&&!b.classList.contains('disabled')){
        checkExpiry(expiresAt);
        lastClickAt=Date.now();b.click();return;
      }
      await sleep(Math.min(100,until-Date.now()));
    }
    // A disabled button is a failed precondition, never permission to press Enter.
    checkExpiry(expiresAt);fail('no-line');
  }
  function report(reqId,result){try{chrome.runtime.sendMessage({type:'DIAL_RESULT',reqId,...result}).catch(()=>{});}catch{/* The extension may have reloaded while the dialler was open. */}}
})();
