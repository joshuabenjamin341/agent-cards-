AC_NOTES_UI.mount(document);
