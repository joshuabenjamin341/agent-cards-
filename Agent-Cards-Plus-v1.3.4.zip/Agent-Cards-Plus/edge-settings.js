(() => {
  const $=id=>document.getElementById(id);
  function status(text){$('edgeSettingsStatus').textContent=text;}
  chrome.storage.local.get(['edgeHidden','edgeEverywhere']).then(p=>{
    $('edgeVisible').checked=p.edgeHidden!==true;
    status(p.edgeEverywhere?'Side tab enabled on permitted websites.':'Side tab appears on Google and enabled work sites.');
  });
  $('edgeVisible').addEventListener('change',async()=>{
    try{await chrome.storage.local.set({edgeHidden:!$('edgeVisible').checked});status('Saved. Refresh open pages to apply the change.');}catch{status('Could not save this setting.');}
  });
  $('edgeEverywhere').addEventListener('click',async()=>{
    try {
      const permission=chrome.permissions.request({origins:['https://*/*','http://*/*']});
      if(!await permission){status('Browser access was declined. Existing sites are unchanged.');return;}
      await chrome.storage.local.set({edgeEverywhere:true,edgeHidden:false});$('edgeVisible').checked=true;
      status('Side tab enabled on websites. Refresh any page where it has not appeared.');
    }catch{status('Could not enable access. Try again from the toolbar popup.');}
  });
  $('edgeWorkOnly').addEventListener('click',async()=>{
    try{await chrome.storage.local.set({edgeEverywhere:false});status('Side tab limited to Google and enabled work sites. Refresh other open pages.');}catch{status('Could not save this setting.');}
  });
})();
