/* Shared settings and parsing. Existing 0.8 settings keep their storage keys. */
(() => {
  const defaults = Object.freeze({
    style: 'large', columns: 2, fontScale: 1, textScale: 1, autoFit: false, autoScroll: true,
    scrollSpeed: 35, edgePause: 2.5, pauseOnHover: true,
    callGlow: true, glowPulse: true, callTimerReplaces: true,
    wallboard: false, wallboardHeight: 60,
    theme: 'midnight', accent: 'mint', toolbar: true,
    showClock: true, clock24: true, reduceMotion: false,
    hideOffline: false, showPins: true, alerts: true,
    callThreshold: 15, breakThreshold: 20, awayThreshold: 30, wrapThreshold: 5,
    sort: 'original', confirmSeconds: 20
  });
  const enums = {
    style: ['large', 'compact'], theme: ['midnight', 'graphite', 'paper'],
    accent: ['mint', 'violet', 'blue', 'amber', 'rose', 'cyan'],
    sort: ['original', 'name', 'status', 'duration']
  };
  const ranges = {
    columns: [1, 6, 1], fontScale: [.75, 1.75, .05], textScale: [.75, 2, .05], scrollSpeed: [5, 100, 1],
    edgePause: [0, 15, .5], wallboardHeight: [30, 95, 5],
    callThreshold: [1, 180, 1], breakThreshold: [1, 180, 1],
    awayThreshold: [1, 240, 1], wrapThreshold: [1, 60, 1], confirmSeconds: [10, 60, 5]
  };
  const accents = {mint:'#69e0bd',violet:'#b5a0ff',blue:'#86b5ff',amber:'#f0c17b',rose:'#f4a1b8',cyan:'#6bd5ea'};
  const presets = {
    desk: {style:'large', columns:2, fontScale:1, autoFit:false, wallboard:false, autoScroll:false, glowPulse:false},
    tv: {style:'large', columns:4, fontScale:1.2, autoFit:true, wallboard:true, wallboardHeight:80, autoScroll:true, callGlow:true, glowPulse:true},
    compact: {style:'compact', columns:2, fontScale:.9, autoFit:false, wallboard:false, autoScroll:true, glowPulse:false}
  };
  function sanitize(input = {}) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) input = {};
    const out = {};
    for (const [key, fallback] of Object.entries(defaults)) {
      const value = input[key];
      if (enums[key]) out[key] = enums[key].includes(value) ? value : fallback;
      else if (ranges[key]) {
        const [min,max,step] = ranges[key];
        const n = typeof value === 'number' && Number.isFinite(value) ? value : fallback;
        out[key] = Number((Math.round(Math.min(max,Math.max(min,n))/step)*step).toFixed(2));
      } else out[key] = typeof value === 'boolean' ? value : fallback;
    }
    return out;
  }
  function duration(text) {
    const s = String(text || '').trim();
    const colon = s.match(/^(\d{1,3}):([0-5]\d)(?::([0-5]\d))?$/);
    if (colon) return colon[3] == null ? +colon[1]*60 + +colon[2] : +colon[1]*3600 + +colon[2]*60 + +colon[3];
    const units = s.match(/^(?:(\d+)\s*h\s*)?(?:(\d+)\s*m\s*)?(?:(\d+)\s*s)?$/i);
    return units && units.slice(1).some(v => v !== undefined) ? +(units[1]||0)*3600 + +(units[2]||0)*60 + +(units[3]||0) : null;
  }
  function status(label, classes = '') {
    const text = `${label} ${classes}`.toLowerCase().replace(/[_-]/g,' ');
    if (/after call|wrap|acw/.test(text)) return 'wrap';
    if (/interacting|on call|communicating/.test(text)) return 'call';
    if (/not responding/.test(text)) return 'busy';
    if (/offline/.test(text)) return 'offline';
    if (/break|meal/.test(text)) return 'break';
    if (/away|meeting|training|out of office/.test(text)) return 'away';
    if (/busy/.test(text)) return 'busy';
    if (/idle/.test(text)) return 'ready';
    if (/available/.test(text)) return 'available';
    // On Queue alone is not evidence that an agent is on a call.
    if (/on queue/.test(text)) return 'ready';
    return 'other';
  }
  function threshold(kind, settings) {
    return ({call:settings.callThreshold,break:settings.breakThreshold,away:settings.awayThreshold,wrap:settings.wrapThreshold})[kind] * 60 || Infinity;
  }
  function importSettings(data) {
    if (!data || data.format !== 'agent-cards-settings' || data.version !== 1 || !data.settings || typeof data.settings !== 'object' || Array.isArray(data.settings)) throw new Error('Choose an Agent Cards settings backup.');
    return sanitize(data.settings);
  }
  globalThis.AGENT_CARDS_DEFAULTS = defaults;
  globalThis.AC = {defaults, sanitize, accents, presets, duration, status, threshold, importSettings};
  if (typeof module !== 'undefined' && module.exports) module.exports = globalThis.AC;
})();
