(() => {
  function mount(root=document,api=chrome) {
    const document=root.ownerDocument||root, N=AGENT_CARDS_NOTES, $=id=>root.getElementById(id);
    let notes=[],filter='open',pending=0,alive=true,ready=false,storedRevision=-1,editRevision=0;
    const editors=new Map(),dirty=new Map();
    const setStatus=(message,error=false)=>{$('notesStatus').textContent=message;$('notesStatus').classList.toggle('error',error);};
    const drafts=()=>notes.map(n=>({...n,...Object.fromEntries(Object.entries(dirty.get(n.id)||{}).map(([key,edit])=>[key,edit.value]))}));
    function acceptSnapshot(next,version){
      version=N.revision(version);
      if(version<storedRevision)return;
      notes=N.read(next);storedRevision=version;
    }
    function render() {
      if(!alive)return;
      const current=drafts(),shown=current.filter(n=>filter==='all'||(filter==='handover'?n.handover&&!n.done:!n.done));
      const ids=new Set(notes.map(n=>n.id));
      for(const [id,view] of editors)if(!ids.has(id)&&!dirty.has(id)){view.card.remove();editors.delete(id);}
      $('notesCount').textContent=String(current.filter(n=>!n.done).length);
      $('noteAdd').disabled=!ready||notes.length>=N.LIMIT;
      $('notesEmpty').hidden=shown.length>0;
      $('notesEmpty').textContent=!ready?'Loading notes…':filter==='handover'?'Mark a note “For handover” to collect it here.':'Nothing outstanding. Add a note whenever you need one.';
      $('copyHandover').disabled=!N.handover(current);
      for(const b of root.querySelectorAll('[data-note-filter]'))b.setAttribute('aria-pressed',String(b.dataset.noteFilter===filter));
      for(const n of current) {
        let view=editors.get(n.id);
        if(!view) {
          const card=document.createElement('article');card.className='note-card';
          const header=document.createElement('div');header.className='note-head';
          const check=document.createElement('input');check.type='checkbox';check.setAttribute('aria-label','Mark note complete');
          const date=document.createElement('time');date.textContent=new Date(n.createdAt).toLocaleString('en-GB',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});date.dateTime=new Date(n.createdAt).toISOString();
          const remove=document.createElement('button');remove.type='button';remove.className='note-remove';remove.textContent='Delete';
          header.append(check,date,remove);
          const text=document.createElement('textarea');text.maxLength=N.TEXT_LIMIT;text.rows=4;text.placeholder='What needs doing? Names, reminders, loose ends…';text.setAttribute('aria-label','Note text');
          const label=document.createElement('label');label.className='note-handover';
          const handover=document.createElement('input');handover.type='checkbox';const caption=document.createElement('span');caption.textContent='For handover';label.append(handover,caption);
          const confirmation=document.createElement('div');confirmation.className='note-delete-check';confirmation.hidden=true;
          const prompt=document.createElement('span');prompt.textContent='Delete this note?';
          const keep=document.createElement('button');keep.type='button';keep.className='button';keep.textContent='Keep';
          const yes=document.createElement('button');yes.type='button';yes.className='button';yes.textContent='Delete';confirmation.append(prompt,keep,yes);
          card.append(header,text,label,confirmation);$('notesList').append(card);
          view={card,text,check,handover};editors.set(n.id,view);
          text.addEventListener('input',()=>{
            const value=text.value;
            // Dispatch immediately. The worker owns the write even if this drawer closes.
            change({action:'patch',id:n.id,patch:{text:value}});
          });
          check.addEventListener('change',()=>change({action:'patch',id:n.id,patch:{done:check.checked}}));
          handover.addEventListener('change',()=>change({action:'patch',id:n.id,patch:{handover:handover.checked}}));
          remove.addEventListener('click',()=>{confirmation.hidden=false;yes.focus();});
          keep.addEventListener('click',()=>{confirmation.hidden=true;remove.focus();});
          yes.addEventListener('click',()=>change({action:'delete',id:n.id}));
        }
        view.card.hidden=!shown.some(s=>s.id===n.id);
        view.card.classList.toggle('completed',n.done);
        if(view.text.value!==n.text)view.text.value=n.text;
        view.check.checked=n.done;view.handover.checked=n.handover;
      }
    }
    async function change(message) {
      const sent={};
      if(message.action==='patch'){
        const edits=dirty.get(message.id)||{};
        for(const [key,value] of Object.entries(message.patch)){
          const revision=++editRevision;edits[key]={value,revision};sent[key]=revision;
        }
        dirty.set(message.id,edits);render();
      }
      pending++;setStatus('Saving…');
      try {
        const result=await api.runtime.sendMessage({type:'AC_NOTES_MUTATE',...message});
        if(!result?.ok)throw new Error(result?.error||'Could not save. Copy your text before closing this page.');
        const edits=dirty.get(message.id);
        if(edits){
          for(const [key,revision] of Object.entries(sent))if(edits[key]?.revision===revision)delete edits[key];
          if(!Object.keys(edits).length)dirty.delete(message.id);
        }
        if(message.action==='delete')dirty.delete(message.id);
        acceptSnapshot(result.notes,result.revision);render();
        if(message.action==='add'){const note=result.notes.at(-1);filter='open';render();editors.get(note?.id)?.text.focus();}
      }catch(e){setStatus(e.message,true);return;}
      finally{pending--;}
      if(!pending)setStatus(dirty.size?'Some changes have not saved. Copy your text or edit the note to try again.':'All notes saved on this browser',dirty.size>0);
    }
    $('noteAdd').addEventListener('click',()=>change({action:'add'}));
    for(const b of root.querySelectorAll('[data-note-filter]'))b.addEventListener('click',()=>{filter=b.dataset.noteFilter;render();});
    $('copyHandover').addEventListener('click',async()=>{
      const text=N.handover(drafts());if(!text)return;
      try {
        // A local selection copy also works when the drawer is on an HTTP page.
        const box=$('handoverCopy');box.hidden=false;box.value=text;box.focus();box.select();
        if(!document.execCommand('copy'))throw new Error('Select the handover text below and press Ctrl+C.');
        box.hidden=true;setStatus('Handover copied. Ready to paste.');
      }catch(e){setStatus(e.message,true);}
    });
    $('exportNotes').addEventListener('click',()=>{
      const text='AGENT CARDS SHIFT NOTES\n\n'+drafts().map(n=>`${n.done?'[Done]':'[Open]'}${n.handover?' [Handover]':''} ${new Date(n.createdAt).toLocaleString('en-GB')}\n${n.text}`).join('\n\n');
      const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='Shift-Notes.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
    });
    const changed=(changes,area)=>{if(area==='local'&&changes[N.KEY]){acceptSnapshot(changes[N.KEY].newValue,changes[N.REVISION_KEY]?.newValue);render();}};
    api.storage.onChanged.addListener(changed);
    api.runtime.sendMessage({type:'AC_NOTES_LIST'}).then(result=>{
      if(!result?.ok)throw new Error(result?.error||'Could not load your notes. Reopen the extension.');
      acceptSnapshot(result.notes,result.revision);ready=true;render();if(!pending&&!dirty.size)setStatus('All notes saved on this browser');
    }).catch(e=>setStatus(e.message,true));render();
    return ()=>{alive=false;api.storage.onChanged.removeListener?.(changed);};
  }
  globalThis.AC_NOTES_UI={mount};
})();
