const $ = id => document.getElementById(id);
let currentTab=null;let sitesRender=0;
function siteMsg(text, isError = false) {
  $('siteMsg').textContent = text;
  $('siteMsg').classList.toggle('error', isError);
}

function currentHttpsHost() {
  try {
    const url = new URL(currentTab?.url || '');
    return url.protocol === 'https:' && isValidSiteHost(url.hostname) ? url.hostname : null;
  } catch (e) {
    return null;
  }
}

function icon(paths) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  for (const d of paths) {
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', d);
    svg.appendChild(path);
  }
  return svg;
}

async function renderSites() {
  const revision = ++sitesRender;
  const sites = await getSites();
  const access = await Promise.all(sites.map(hasSitePermission));
  if (revision !== sitesRender) return;
  const list = $('sites');
  list.replaceChildren();
  $('siteCount').textContent = `${sites.length} ${sites.length === 1 ? 'site' : 'sites'}`;
  const currentHost = currentHttpsHost();
  const enabled = currentHost && sites.includes(currentHost) && access[sites.indexOf(currentHost)];
  $('currentHost').textContent = currentHost || 'Open a Genesys or dispatch tab';
  $('currentHost').title = currentHost || '';
  $('currentHint').textContent = enabled ? 'Agent Cards has access to this site.' : 'Enable on Genesys, then your dispatch site.';
  $('currentSiteState').textContent = enabled ? 'Enabled' : currentHost ? 'Not enabled' : 'HTTPS required';
  $('currentSiteState').classList.toggle('enabled', !!enabled);
  $('addSite').disabled = !currentHost || !!enabled;
  $('addSite').classList.toggle('enabled', !!enabled);
  $('addSiteLabel').textContent = enabled ? 'Site enabled' : 'Enable this site';
  $('addSite').querySelector('path').setAttribute('d', enabled ? 'm5 12 4 4L19 6' : 'M12 5v14M5 12h14');

  if (!sites.length) {
    const li = document.createElement('li');
    li.className = 'empty';
    li.appendChild(icon(['M8 12h8M12 8v8', 'M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2']));
    const title = document.createElement('strong');
    title.textContent = 'Your workspace starts here';
    const hint = document.createElement('p');
    hint.textContent = 'Add Genesys first, then your dispatch site to get calling set up.';
    li.append(title, hint);
    list.appendChild(li);
    return;
  }

  sites.forEach((host, index) => {
    const li = document.createElement('li');
    const dot = document.createElement('span');
    dot.className = `site-dot${access[index] ? '' : ' warn'}`;
    dot.setAttribute('aria-hidden', 'true');
    const detail = document.createElement('div');
    detail.className = 'site-detail';
    const name = document.createElement('span');
    name.className = 'host';
    name.textContent = host;
    name.title = host;
    const status = document.createElement('span');
    status.className = 'site-access';
    status.textContent = access[index] ? 'Access granted' : 'Site access needed';
    detail.append(name, status);
    li.append(dot, detail);
    if (!access[index]) {
      const enable = document.createElement('button');
      enable.className = 'small';
      enable.type = 'button';
      enable.textContent = 'Enable';
      enable.setAttribute('aria-label', `Enable ${host}`);
      enable.addEventListener('click', () => enableSite(host));
      li.appendChild(enable);
    }
    const remove = document.createElement('button');
    remove.className = 'remove-site';
    remove.type = 'button';
    remove.title = `Remove ${host}`;
    remove.setAttribute('aria-label', `Remove ${host}`);
    remove.appendChild(icon(['M6 6l12 12M18 6 6 18']));
    remove.addEventListener('click', async () => {
      remove.disabled = true;
      try { await removeSite(host); } catch (e) {
        siteMsg(`Could not remove site: ${e.message}`, true);
        remove.disabled = false;
      }
    });
    li.appendChild(remove);
    list.appendChild(li);
  });
}

async function enableSite(host, tab = null) {
  if (!isValidSiteHost(host)) {
    siteMsg('Choose an exact HTTPS hostname.', true);
    return;
  }
  // Keep the request inside the button's user gesture, before any await.
  let granted;
  try {
    const request = chrome.permissions.request({ origins: sitePatterns(host) });
    if (host === currentHttpsHost()) {
      $('addSite').disabled = true;
      $('addSiteLabel').textContent = 'Enabling...';
    }
    granted = await request;
    if (!granted) {
      siteMsg('Permission was declined. Nothing changed.', true);
      await renderSites();
      return;
    }
    await registerSite(host);
    const sites = await getSites();
    if (!sites.includes(host)) await setSites([...sites, host]);
    if (tab?.id != null) {
      try {
        await chrome.scripting.insertCSS({ target: { tabId: tab.id, allFrames: true }, files: CONTENT_CSS });
        await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: CONTENT_JS });
      } catch (e) {
        siteMsg(`Enabled on ${host}. Refresh the tab to apply it.`);
        await renderSites();
        return;
      }
    }
    siteMsg(`Enabled on ${host}.`);
  } catch (e) {
    siteMsg(`Could not enable site: ${e.message}`, true);
  }
  await renderSites();
}

async function removeSite(host) {
  await unregisterSite(host);
  await setSites((await getSites()).filter(h => h !== host));
  try { await chrome.permissions.remove({ origins: sitePatterns(host) }); } catch (e) {}
  siteMsg(`Removed ${host}. Refresh its tab to clear the styling.`);
  await renderSites();
}
$('addSite').addEventListener('click', () => {
  const host = currentHttpsHost();
  if (host) enableSite(host, currentTab);
});
chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
  currentTab = tab || null;
  return renderSites();
}).catch(() => siteMsg('Could not read this tab. Reopen the popup on your workspace.', true));

