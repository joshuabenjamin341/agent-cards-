/* Per-widget sizing. Only presentation properties are changed; Genesys owns
   the rows and dashboard widgets. Pure geometry helpers also run in Node. */
(() => {
  const MIN_SCALE = .75, MAX_SCALE = 3, MAX_COLUMNS = 12;
  const number = (value, fallback) => Number.isFinite(value) ? value : fallback;
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const px = value => parseFloat(value) || 0;

  function grid({width, height, count, cardHeight = 132, cardWidth = 204, gap = 12,
    minScale = MIN_SCALE, maxScale = MAX_SCALE, columnLimit = MAX_COLUMNS}) {
    width = Math.max(0, number(width, 0)); height = Math.max(0, number(height, 0));
    count = Math.max(0, Math.floor(number(count, 0)));
    cardHeight = Math.max(1, number(cardHeight, 132));
    cardWidth = Math.max(1, number(cardWidth, 204)); gap = Math.max(0, number(gap, 12));
    minScale = clamp(number(minScale, MIN_SCALE), MIN_SCALE, MAX_SCALE);
    maxScale = clamp(number(maxScale, MAX_SCALE), minScale, MAX_SCALE);
    columnLimit = clamp(Math.floor(number(columnLimit, MAX_COLUMNS)), 1, MAX_COLUMNS);
    if (!count || !width || !height) return null;
    // Choose the largest readable scale which fits *all* visible cards.
    // If impossible, retain the readable minimum and let the table scroll.
    const maxColumns = Math.max(1, Math.min(columnLimit, count,
      Math.floor((width + gap) / (cardWidth * minScale + gap))));
    let best = null;
    for (let columns = 1; columns <= maxColumns; columns++) {
      const rows = Math.ceil(count / columns);
      const horizontal = (width - (columns - 1) * gap) / (columns * cardWidth);
      const vertical = (height - (rows - 1) * gap) / (rows * cardHeight);
      // Round down so sub-pixel rounding cannot add an unwanted final row.
      const scale = Math.max(minScale, Math.floor(Math.min(maxScale, horizontal, vertical) * 100) / 100);
      const contentHeight = rows * cardHeight * scale + (rows - 1) * gap;
      const overflow = contentHeight > height + 1;
      const candidate = {columns, rows, scale, contentHeight, overflow};
      if (!best || (!overflow && best.overflow) ||
          (overflow === best.overflow && (scale > best.scale ||
            (overflow && scale === best.scale && contentHeight < best.contentHeight)))) best = candidate;
    }
    return best;
  }

  function bandHeight({height, otherRows = 0, gap = 12}) {
    height = Math.max(0, number(height, 0)); gap = Math.max(0, number(gap, 12));
    otherRows = Math.max(0, Math.floor(number(otherRows, 0)));
    if (!height) return 0;
    if (!otherRows) return Math.floor(height);
    // Native widgets retain their own sizing. Reserve 30–60% for their rows,
    // rather than letting a fixed vh agent band consume the whole dashboard.
    const reserve = clamp(otherRows * 160 + (otherRows - 1) * gap, height * .3, height * .6);
    return Math.max(1, Math.floor(height - reserve - gap));
  }

  function setProperty(node, key, value) {
    if (node.style.getPropertyValue(key) !== String(value)) node.style.setProperty(key, value);
  }
  function viewportHeight() { return document.documentElement.clientHeight || globalThis.innerHeight || 0; }
  function viewportWidth() { return document.documentElement.clientWidth || globalThis.innerWidth || 0; }

  function space(table, widget) {
    const rect = table.getBoundingClientRect();
    if (!rect.width || !widget.getBoundingClientRect().height) return null;
    let width = Math.min(rect.width, viewportWidth());
    let height = Infinity, scrolled = 0, insideWidget = true, inset = 0;
    // Measure the table's inset within its own widget. Outer page scrolling
    // moves the whole widget and must not consume its available height.
    // The table's own fitted height is deliberately not an input to this pass.
    for (let node = table.parentElement; node && node !== document.documentElement; node = node.parentElement) {
      const style = getComputedStyle(node), bounds = node.getBoundingClientRect();
      if (insideWidget) scrolled += node.scrollTop || 0;
      if (node === widget || /auto|scroll|hidden|clip/.test(style.overflowY)) {
        const offset = insideWidget ? rect.top + scrolled - bounds.top - (node.clientTop || 0) : inset + px(style.paddingTop);
        height = Math.min(height, node.clientHeight - offset - px(style.paddingBottom));
        width = Math.min(width, node.clientWidth - px(style.paddingLeft) - px(style.paddingRight));
      }
      if (node === widget) {
        inset = Math.max(0, rect.top + scrolled - bounds.top - (node.clientTop || 0));
        insideWidget = false;
      }
      if (node === document.fullscreenElement) break;
    }
    height = Math.min(height, viewportHeight() - inset);
    return {width: Math.max(0, Math.floor(width)), height: Math.max(0, Math.floor(height))};
  }

  function dashboardRows(main) {
    if (!main) return 0;
    let nodes = [...main.querySelectorAll('.analytics-ui-dashboard-card-widget')];
    if (!nodes.length) nodes = [...main.children];
    const tops = [];
    for (const node of nodes) {
      const rect = node.getBoundingClientRect();
      if (rect.width && rect.height && !tops.some(top => Math.abs(top - rect.top) < 10)) tops.push(rect.top);
    }
    return tops.length;
  }

  function measureCards(board, textScale, cardWidth) {
    // A synchronous, unpainted measurement at 100% card scale separates text
    // size from overall card size. Auto fit must not shrink away a text change.
    const scrollPositions = [];
    for (let node = board.table; node; node = node.parentElement) {
      scrollPositions.push({node, top: node.scrollTop || 0, left: node.scrollLeft || 0});
    }
    board.table.dataset.acMeasure = 'true';
    board.table.style.setProperty('--ac-measure-text', textScale);
    board.table.style.setProperty('--ac-measure-width', `${cardWidth}px`);
    let height = 0;
    try {
      for (const row of board.visibleRows || []) height = Math.max(height, row.getBoundingClientRect().height);
    } finally {
      delete board.table.dataset.acMeasure;
      board.table.style.removeProperty('--ac-measure-text');
      board.table.style.removeProperty('--ac-measure-width');
      // The temporary smaller layout can clamp scroll offsets. Restore them
      // after restoring the real layout, before the browser paints anything.
      board.table.getBoundingClientRect();
      for (const {node, top, left} of scrollPositions) {
        if (node.scrollTop !== top) node.scrollTop = top;
        if (node.scrollLeft !== left) node.scrollLeft = left;
      }
    }
    return height;
  }

  function create(onResize = () => {}) {
    let observed = new Set(), fitted = new Set(), bands = new Set();
    const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(() => {
      for (const board of fitted) board.measurement = null;
      onResize();
    }) : null;
    function clearBoard(board) {
      board.widget.style.removeProperty('--agent-cards-cols');
      board.widget.style.removeProperty('--agent-cards-scale');
      board.table.style.removeProperty('--ac-fit-height');
      delete board.table.dataset.acFit;
      board.fit = null; board.measurement = null;
    }
    function update(input, settings) {
      const boards = [...input], targets = new Set(), activeBands = new Set();
      const active = settings.autoFit || settings.textScale !== 1;
      for (const old of fitted) if (!active || !boards.includes(old)) clearBoard(old);
      fitted = new Set(active ? boards : []);
      if (settings.autoFit && settings.wallboard) for (const board of boards) {
        // Full screen has its own viewport and must not change the dashboard.
        if (document.fullscreenElement) continue;
        const parent = board.widget.closest('.flow-layout-parent');
        const sidebar = board.widget.closest('.flow-layout-sidebar');
        if (!parent || !sidebar || activeBands.has(parent)) continue;
        const style = getComputedStyle(parent);
        const available = Math.max(0, Math.min(parent.clientHeight, viewportHeight()) - px(style.paddingTop) - px(style.paddingBottom));
        if (!available) continue;
        const main = parent.querySelector('.flow-layout-main');
        const height = bandHeight({height: available, otherRows: dashboardRows(main), gap: px(style.rowGap) || 12});
        setProperty(parent, '--agent-cards-wallboard-h', `${height}px`);
        activeBands.add(parent); targets.add(parent); if (main) targets.add(main);
      }
      for (const parent of bands) if (!activeBands.has(parent)) parent.style.removeProperty('--agent-cards-wallboard-h');
      bands = activeBands;
      if (active) for (const board of boards) {
        targets.add(board.widget); targets.add(board.host);
        if (board.table.parentElement) targets.add(board.table.parentElement);
        const bounds = space(board.table, board.widget);
        if (!bounds || bounds.width < 40 || bounds.height < 40) {clearBoard(board); continue;}
        const tbody = board.table.querySelector('tbody');
        if (!tbody) {clearBoard(board); continue;}
        const style = getComputedStyle(tbody);
        const rows = board.visibleRows || [];
        if (!rows.length) {clearBoard(board); continue;}
        const scrollbar = 18; // Keep width stable when vertical overflow begins.
        const baseWidth = settings.style === 'compact' ? 300 : 204;
        const fallbackHeight = settings.style === 'compact' ? 66 : 132;
        let baseHeight = fallbackHeight, textHeight = fallbackHeight;
        if (settings.autoFit) {
          // A ticking timer with the same digit count cannot change the layout.
          // Cache these measurements rather than forcing row reflow every second.
          const key = [settings.style,settings.theme,settings.textScale,settings.callTimerReplaces,
            rows.map(row=>(row.textContent||'').replace(/\d/g,'0')).join('\u001f')].join('|');
          if (board.measurement?.key !== key) {
            baseHeight = measureCards(board, 1, baseWidth) || fallbackHeight;
            textHeight = settings.textScale === 1 ? baseHeight : measureCards(board, settings.textScale, baseWidth * settings.textScale) || baseHeight * settings.textScale;
            board.measurement = {key,baseHeight,textHeight};
          }
          ({baseHeight,textHeight} = board.measurement);
        }
        const geometry = {width: bounds.width - px(style.paddingLeft) - px(style.paddingRight) - scrollbar,
          height: bounds.height - px(style.paddingTop) - px(style.paddingBottom) - 2,
          count: rows.length, cardHeight: baseHeight, cardWidth: baseWidth, gap: px(style.rowGap) || 12};
        let result;
        if (settings.autoFit) {
          result = grid(geometry);
          if (result && settings.textScale !== 1) {
            result = grid({...geometry, cardHeight: textHeight, cardWidth: baseWidth * settings.textScale,
              minScale: result.scale, maxScale: result.scale});
          }
        } else {
          // Manual card scale stays intact. Larger type reduces columns only
          // when needed; natural row heights and wrapping accommodate the text.
          const wanted = settings.style === 'compact' && !settings.wallboard ? 1 : settings.columns;
          const columns = clamp(Math.floor((geometry.width + geometry.gap) /
            (baseWidth * settings.textScale * settings.fontScale + geometry.gap)), 1, wanted);
          result = {columns, scale: settings.fontScale, overflow: false};
        }
        // Empty filters leave the last fit alone and keep the reset controls usable.
        if (!result) {board.fit = null; continue;}
        setProperty(board.widget, '--agent-cards-cols', result.columns);
        setProperty(board.widget, '--agent-cards-scale', result.scale);
        if (settings.autoFit) {
          setProperty(board.table, '--ac-fit-height', `${bounds.height}px`);
          board.table.dataset.acFit = 'true';
        } else {
          board.table.style.removeProperty('--ac-fit-height'); delete board.table.dataset.acFit;
        }
        board.fit = result;
      }
      for (const node of observed) if (!targets.has(node)) observer?.unobserve(node);
      for (const node of targets) if (!observed.has(node)) observer?.observe(node);
      observed = targets;
    }
    function destroy() {
      observer?.disconnect(); observed.clear();
      for (const board of fitted) clearBoard(board);
      for (const parent of bands) parent.style.removeProperty('--agent-cards-wallboard-h');
      fitted.clear(); bands.clear();
    }
    return {update, destroy};
  }
  const api = {grid, bandHeight, space, create};
  globalThis.AC_FIT = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
