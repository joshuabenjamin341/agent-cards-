/* Shared UI ownership across isolated copies of this integration.
   This coordinates presentation only. It cannot approve a call or replace
   the worker's sender and number checks. No phone number is stored in DOM. */
(() => {
  if (globalThis.AGENT_CARDS_DIAL_LIFECYCLE) return;
  const OWNER_ATTRIBUTE = 'data-agent-cards-dial-owner';

  function runtimeAlive(runtime) {
    try {
      return typeof runtime?.id === 'string' && !!runtime.id &&
        typeof runtime.getManifest === 'function' && !!runtime.getManifest();
    } catch {
      return false;
    }
  }

  function claim({ runtime = chrome.runtime, root = document.documentElement, onStop = () => {} } = {}) {
    let stopped = false;
    let observer;
    const owner = crypto.randomUUID();
    function stop() {
      if (stopped) return;
      stopped = true;
      observer?.disconnect();
      if (root.getAttribute(OWNER_ATTRIBUTE) === owner) root.removeAttribute(OWNER_ATTRIBUTE);
      onStop();
    }
    function isActive() {
      if (!stopped && runtimeAlive(runtime) && root.getAttribute(OWNER_ATTRIBUTE) === owner) return true;
      stop();
      return false;
    }
    if (!runtimeAlive(runtime)) {
      stopped = true;
      return { isActive, stop };
    }
    root.setAttribute(OWNER_ATTRIBUTE, owner);
    observer = new MutationObserver(() => { isActive(); });
    observer.observe(root, { attributes: true, attributeFilter: [OWNER_ATTRIBUTE] });
    return { isActive, stop };
  }

  globalThis.AGENT_CARDS_DIAL_LIFECYCLE = { claim };
})();
