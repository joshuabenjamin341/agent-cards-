/* UI interaction tests in a simulated DOM. No browser account or real call. */
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const flush=()=>new Promise(resolve=>setImmediate(resolve));
function fixture(initial=[],{deferMutations=false}={}) {
  let data=JSON.parse(JSON.stringify(initial)), sequence=0, revision=0, resolveDial, rejectDial, storageListener;
  const messages=[], timers=new Map(), mutationReplies=[];
  class Element {
    constructor(tag='div'){this.tagName=tag;this.children=[];this.dataset={};this.events={};this.attributes={};this.value='';this.checked=false;this.hidden=false;this.disabled=false;this._text='';this.className='';this.classList={toggle:()=>{}};}
    get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
    set textContent(value){this._text=String(value);this.children=[];}
    append(...nodes){for(const node of nodes){this.children.push(node);node.parentNode=this;}}
    replaceChildren(...nodes){this.children=[];this.append(...nodes);}
    setAttribute(k,v){this.attributes[k]=String(v);}
    addEventListener(event,callback){(this.events[event]||=[]).push(callback);}
    matches(selector){return selector==='[data-contact-action]'?!!this.dataset.contactAction:selector.startsWith('.')?this.className.split(' ').includes(selector.slice(1)):this.tagName===selector;}
    closest(selector){return this.matches(selector)?this:this.parentNode?.closest(selector);}
    querySelectorAll(selector){return this.children.flatMap(c=>[...(c.matches(selector)?[c]:[]),...c.querySelectorAll(selector)]);}
    focus(){document.activeElement=this;}
    async emit(event,props={}) {for(const callback of this.events[event]||[])await callback({isTrusted:true,preventDefault(){},...props});}
    click(){if(!this.disabled)return this.emit('click');}
  }
  const ids=[...fs.readFileSync(path.join(root,'popup.html'),'utf8').matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
  const elements=Object.fromEntries(ids.map(id=>[id,new Element()]));
  elements.contactEditor.hidden=true;
  elements.contactForm.elements=['contactName','contactNumber','contactLabel','contactFavourite','contactSave','contactCancel','contactDelete','contactDeleteKeep','contactDeleteConfirm'].map(id=>elements[id]);
  elements.contactForm.reset=()=>{for(const e of elements.contactForm.elements){e.value='';e.checked=false;}};
  const document={activeElement:null,getElementById:id=>{assert.ok(elements[id],`missing element ${id}`);return elements[id];},createElement:tag=>new Element(tag),createElementNS:(ns,tag)=>{const el=new Element(tag);el.namespaceURI=ns;return el;}};
  const context=vm.createContext({document,crypto:{randomUUID:()=>`c-${++sequence}`},URL,Blob,
    setTimeout:(fn,ms)=>{const id=++sequence;timers.set(id,{fn,ms});return id;},clearTimeout:id=>timers.delete(id),
    chrome:{storage:{onChanged:{addListener:fn=>{storageListener=fn;}}},runtime:{sendMessage:async msg=>{
      messages.push(msg);const C=context.AGENT_CARDS_CONTACTS;
      if(msg.type==='AC_CONTACTS_LIST')return {ok:true,contacts:data,revision};
      if(msg.type==='AC_CONTACT_DIAL')return new Promise((resolve,reject)=>{resolveDial=resolve;rejectDial=reject;});
      if(msg.type==='AC_CONTACTS_MUTATE'){
        if(msg.action==='save')data=C.upsert(data,msg.contact,()=>`c-${++sequence}`);
        if(msg.action==='favourite')data=data.map(c=>c.id===msg.id?{...c,favourite:msg.value}:c);
        if(msg.action==='delete')data=data.filter(c=>c.id!==msg.id);
        revision++;
        storageListener({[C.KEY]:{newValue:data},agentCardsContactsRevisionV1:{newValue:revision}},'local');
        const result={ok:true,contacts:data,revision};
        if(deferMutations)return new Promise(resolve=>mutationReplies.push(()=>resolve(result)));
        return result;
      }
    }}}
  });
  for(const name of ['security.js','contacts.js','contacts-ui.js','contacts-start.js'])vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),context,{filename:name});
  const actions=action=>elements.contactList.querySelectorAll('[data-contact-action]').filter(b=>b.dataset.contactAction===action);
  return {elements,messages,actions,timers,mutationReplies,resolveDial:value=>resolveDial(value),rejectDial:()=>rejectDial(new Error('transport closed')),data:()=>JSON.parse(JSON.stringify(data)),storageListener,
    changeContacts(next){data=next;revision++;storageListener({agentCardsContactsV1:{newValue:data},agentCardsContactsRevisionV1:{newValue:revision}},'local');}};
}
const contact={id:'desk',name:'Dispatch desk',number:'+447700900123',label:'Office',favourite:false};

test('empty Contacts loads and saving a named number produces a usable contact card',async()=>{
  const f=fixture();await flush();assert.equal(f.elements.contactEmpty.hidden,false);
  await f.elements.contactAdd.click();assert.equal(f.elements.contactEditor.hidden,false);
  f.elements.contactName.value=contact.name;f.elements.contactNumber.value='07700 900123';
  await f.elements.contactForm.emit('submit');
  assert.equal(f.data()[0].number,contact.number);assert.equal(f.elements.contactEditor.hidden,true);
  assert.equal(f.actions('call').length,1);assert.equal(f.elements.contactsStatus.textContent,'Contact saved.');
});
test('search matches contact name, label and national number without changing stored contacts',async()=>{
  const f=fixture([contact]);await flush();
  for(const query of ['dispatch','Office','07700 900123','+44 7700 900123']){f.elements.contactSearch.value=query;await f.elements.contactSearch.emit('input');assert.equal(f.actions('call').length,1);}
  f.elements.contactSearch.value='not found';await f.elements.contactSearch.emit('input');assert.equal(f.actions('call').length,0);
  assert.equal(f.data().length,1);
});
test('editing, favouriting and deleting a contact never place a call',async()=>{
  const f=fixture([contact]);await flush();await f.actions('favourite')[0].click();
  assert.equal(f.data()[0].favourite,true);
  await f.actions('edit')[0].click();f.elements.contactName.value='Evening desk';await f.elements.contactForm.emit('submit');
  assert.equal(f.data()[0].name,'Evening desk');await f.actions('edit')[0].click();
  await f.elements.contactDelete.click();assert.equal(f.elements.contactDeletePrompt.hidden,false);
  await f.elements.contactDeleteKeep.click();assert.equal(f.data().length,1);
  await f.elements.contactDelete.click();await f.elements.contactDeleteConfirm.click();assert.equal(f.data().length,0);
  assert.equal(f.messages.filter(m=>m.type==='AC_CONTACT_DIAL').length,0);
});
test('pressing a contact submits once without a second confirmation and locks rapid clicks',async()=>{
  const f=fixture([contact]);await flush();const call=f.actions('call')[0];
  await call.click();await call.emit('click');
  assert.equal(f.messages.filter(m=>m.type==='AC_CONTACT_DIAL').length,1);
  assert.equal(f.actions('call')[0].disabled,true);assert.match(f.elements.contactsStatus.textContent,/Sending call request/);
  f.resolveDial({ok:true});await flush();assert.match(f.elements.contactsStatus.textContent,/Call request sent to Genesys/);
  assert.equal(f.actions('call')[0].disabled,true);
});
test('untrusted generated clicks cannot dial a contact',async()=>{
  const f=fixture([contact]);await flush();await f.actions('call')[0].emit('click',{isTrusted:false});
  assert.equal(f.messages.filter(m=>m.type==='AC_CONTACT_DIAL').length,0);
});
test('lost response warns to check Genesys and never retries automatically',async()=>{
  const f=fixture([contact]);await flush();await f.actions('call')[0].click();f.rejectDial();await flush();
  assert.match(f.elements.contactsStatus.textContent,/outcome is unknown/);assert.equal(f.messages.filter(m=>m.type==='AC_CONTACT_DIAL').length,1);
});
test('a contact click expires and a missing worker reply cannot leave it pending forever',async()=>{
 const f=fixture([contact]);await flush();await f.actions('call')[0].click();
 const call=f.messages.find(m=>m.type==='AC_CONTACT_DIAL');assert.ok(Number.isFinite(call.expiresAt));assert.ok(call.expiresAt<=Date.now()+14000);
 const timeout=[...f.timers.values()].find(t=>t.ms===18000);assert.ok(timeout);timeout.fn();await flush();
 assert.match(f.elements.contactsStatus.textContent,/outcome is unknown/);
 f.resolveDial({ok:true});await flush();assert.doesNotMatch(f.elements.contactsStatus.textContent,/request sent/);
 assert.equal(f.messages.filter(m=>m.type==='AC_CONTACT_DIAL').length,1);
});
test('reopening Contacts uses saved data and text-shaped markup remains text',async()=>{
  const f=fixture([{...contact,name:'<img src=x onerror=alert(1)>'}]);await flush();
  assert.match(f.elements.contactList.textContent,/<img/);assert.equal(f.elements.contactList.querySelectorAll('img').length,0);
  const reopened=fixture(f.data());await flush();assert.equal(reopened.actions('call').length,1);
  assert.equal(reopened.messages.filter(m=>m.type==='AC_CONTACT_DIAL').length,0);
});
test('other-window storage changes refresh contact cards while preserving an unsaved form',async()=>{
  const f=fixture([contact]);await flush();await f.actions('edit')[0].click();f.elements.contactName.value='Unsaved name';
  f.storageListener({agentCardsContactsV1:{newValue:[contact,{...contact,id:'second',name:'Second',number:'+447700900124'}]}},'local');
  assert.equal(f.actions('call').length,2);assert.equal(f.elements.contactName.value,'Unsaved name');assert.equal(f.elements.contactEditor.hidden,false);
});
test('a delayed contact-save reply cannot remove newer contacts from another window',async()=>{
  const f=fixture([contact],{deferMutations:true});await flush();
  const saving=f.actions('favourite')[0].click();await flush();
  f.changeContacts([...f.data(),{...contact,id:'second',name:'Second desk',number:'+447700900124'}]);
  f.mutationReplies[0]();await saving;
  assert.equal(f.actions('call').length,2);assert.equal(f.elements.contactCount.textContent,'2');
});
test('a delayed save reply cannot put an older contact number back on screen',async()=>{
  const f=fixture([contact],{deferMutations:true});await flush();
  const saving=f.actions('favourite')[0].click();await flush();
  f.changeContacts([{...f.data()[0],number:'+447700900124'}]);
  f.mutationReplies[0]();await saving;
  assert.match(f.elements.contactList.textContent,/07700 900124/);assert.doesNotMatch(f.elements.contactList.textContent,/07700 900123/);
});
