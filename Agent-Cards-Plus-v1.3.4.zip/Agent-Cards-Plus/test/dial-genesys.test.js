/* Exercises the actual receiver with a virtual clock and fake dialler.
   No browser, real Genesys session or telephone call is used. */
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const flush=()=>new Promise(resolve=>setImmediate(resolve));
function fixture(){
 let now=100000,sequence=0,listener,clicks=0,opened=0;
 const timers=new Map(),reports=[],acks=[];
 class Node {
  constructor(){this.hidden=false;this.isConnected=true;this.disabled=false;this.readOnly=false;this.attrs={};this.events=[];this.classList={contains:()=>false};}
  getClientRects(){return this.isConnected&&!this.hidden?[{}]:[];}
  getAttribute(name){return this.attrs[name]??null;}
  matches(selector){return selector===':disabled'&&(this.disabled||this.fieldsetDisabled);}
  focus(){} dispatchEvent(event){this.events.push(event);return true;}
 }
 class Input extends Node {get value(){return this._value||'';}set value(value){this._value=String(value);}}
 const opener=new Node();opener.click=()=>opened++;
 const input=new Input(),button=new Node();button.click=()=>clicks++;
 const inputs=[input],buttons=[button];
 const find=selector=>selector==='#interaction-new-call-outbound-target'?[opener]:selector==='input.phone-number-input'?inputs:selector==='button.make-call'?buttons:[];
 class Clock extends Date {static now(){return now;}}
 class FakeEvent {constructor(type,options){this.type=type;Object.assign(this,options);this.isTrusted=false;}}
 const context=vm.createContext({document:{querySelector:s=>find(s)[0]||null,querySelectorAll:find},Date:Clock,HTMLInputElement:Input,Event:FakeEvent,KeyboardEvent:FakeEvent,
  getComputedStyle:node=>({visibility:node.hidden?'hidden':'visible'}),
  setTimeout(fn,ms){const id=++sequence;timers.set(id,{fn,at:now+ms});return id;},clearTimeout:id=>timers.delete(id),
  chrome:{runtime:{id:'extension',onMessage:{addListener:fn=>listener=fn},async sendMessage(msg){reports.push(msg);}}}
 });
 for(const file of ['security.js','dial-genesys.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'..',file),'utf8'),context,{filename:file});
 return {input,button,inputs,buttons,opener,reports,acks,context,Input,Node,clicks:()=>clicks,opened:()=>opened,now:()=>now,
  async send(patch={},sender={id:'extension'}){const msg={type:'DIAL',reqId:`request-${++sequence}`,number:'+447700900123',expiresAt:now+14000,...patch};listener(msg,sender,ack=>acks.push(ack));await flush();return msg;},
  async tick(ms){const until=now+ms;while(true){const next=[...timers].filter(([,t])=>t.at<=until).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;now=next[1].at;timers.delete(next[0]);next[1].fn();await flush();}now=until;await flush();}
 };
}
test('receiver fills the number and reports success only after one enabled button click',async()=>{
 const f=fixture();await f.send();assert.equal(f.input.value,'+447700900123');assert.equal(f.clicks(),1);assert.equal(f.reports.at(-1).ok,true);
});
test('receiver ignores other-extension messages and duplicate request IDs',async()=>{
 const f=fixture();await f.send({}, {id:'other'});assert.equal(f.clicks(),0);
 const msg=await f.send();await f.tick(4000);await f.send(msg);assert.equal(f.clicks(),1);
});
test('a disabled outbound call button never triggers an Enter fallback or success',async()=>{
 const f=fixture();f.button.disabled=true;await f.send();await f.tick(3600);
 assert.equal(f.clicks(),0);assert.equal(f.reports.at(-1).reason,'no-line');assert.ok(f.input.events.every(e=>e.key!=='Enter'));
});
test('overlapping receiver requests are rejected while the first is waiting',async()=>{
 const f=fixture();f.button.disabled=true;await f.send();await f.send();assert.equal(f.reports.at(-1).reason,'busy');assert.equal(f.clicks(),0);
});
test('a manually changed number is never replaced or called after waiting',async()=>{
 const f=fixture();f.button.disabled=true;await f.send();f.input.value='+447700900124';f.button.disabled=false;await f.tick(100);
 assert.equal(f.clicks(),0);assert.equal(f.reports.at(-1).ok,false);assert.equal(f.input.value,'+447700900124');
});
test('an already expired request cannot fill the dialler or place a late call',async()=>{
 const f=fixture();await f.send({expiresAt:f.now()-1});assert.equal(f.clicks(),0);assert.equal(f.input.value,'');assert.equal(f.reports.at(-1).reason,'expired');
});
test('a request which expires while waiting cannot call when the button later enables',async()=>{
 const f=fixture();f.button.disabled=true;await f.send({expiresAt:f.now()+150});await f.tick(100);f.button.disabled=false;await f.tick(100);
 assert.equal(f.clicks(),0);assert.equal(f.reports.at(-1).reason,'expired');
});
test('hidden old dialler controls do not mask the visible input and Call button',async()=>{
 const f=fixture(),hiddenInput=new f.Input(),hiddenButton=new f.Node();hiddenInput.hidden=true;hiddenButton.hidden=true;
 f.inputs.unshift(hiddenInput);f.buttons.unshift(hiddenButton);await f.send();await f.tick(4000);
 assert.equal(f.clicks(),1);assert.equal(f.input.value,'+447700900123');assert.equal(hiddenInput.value,'');
});
test('two visible number boxes are rejected instead of choosing an arbitrary one',async()=>{
 const f=fixture();f.inputs.push(new f.Input());await f.send();assert.equal(f.clicks(),0);assert.equal(f.reports.at(-1).reason,'ambiguous');
});
test('the receiver rejects a second rapid request with a different ID',async()=>{
 const f=fixture();await f.send();await f.send({number:'+447700900124'});assert.equal(f.clicks(),1);assert.equal(f.reports.at(-1).reason,'busy');
 await f.tick(3100);await f.send({number:'+447700900124'});assert.equal(f.clicks(),2);
});
test('a number box hidden while waiting cancels the call',async()=>{
 const f=fixture();f.button.disabled=true;await f.send();f.input.hidden=true;f.button.disabled=false;await f.tick(100);assert.equal(f.clicks(),0);
});
test('missing or unbounded request deadlines never reach the number input',async()=>{
 for(const expiresAt of [undefined,null,'114000',Infinity,116000]){
  const f=fixture();await f.send({expiresAt});assert.equal(f.input.value,'');assert.equal(f.clicks(),0);assert.equal(f.reports.at(-1).reason,'expired');
 }
});
test('two visible Call buttons are rejected without clicking either one',async()=>{
 const f=fixture();f.buttons.push(new f.Node());await f.send();assert.equal(f.clicks(),0);assert.equal(f.reports.at(-1).reason,'ambiguous');
});
test('a number input disabled by its parent fieldset cannot be filled or called',async()=>{
 const f=fixture();f.input.fieldsetDisabled=true;await f.send();assert.equal(f.input.value,'');assert.equal(f.clicks(),0);assert.equal(f.reports.at(-1).reason,'no-input');
});
