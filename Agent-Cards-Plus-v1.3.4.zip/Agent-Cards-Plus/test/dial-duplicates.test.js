/* Simulated documents and isolated extension contexts. No browser, account
   or real call is used. Assertions exercise the actual dispatch scripts. */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const scripts = ['defaults.js', 'security.js', 'dial-lifecycle.js', 'dial-dispatch.js'];
const source = Object.fromEntries(scripts.map(name => [name, fs.readFileSync(path.join(__dirname, '..', name), 'utf8')]));
const flush = () => new Promise(resolve => setImmediate(resolve));

function fixture() {
  const observers = new Set();
  const roots = [];
  const sent = [];
  let sequence = 0;
  const documentListeners = new Map();
  class Observer {
    constructor(callback) { this.callback = callback; }
    observe(target, options) { this.target = target; this.options = options; observers.add(this); }
    disconnect() { observers.delete(this); }
  }
  function notify(target, name) {
    for (const observer of observers) {
      if (observer.target !== target || !observer.options.attributes || !observer.options.attributeFilter?.includes(name)) continue;
      queueMicrotask(() => { if (observers.has(observer)) observer.callback([{ target, attributeName: name }]); });
    }
  }
  class Element {
    constructor(tag) {
      this.tagName = tag; this.children = []; this.attributes = new Map();
      this.dataset = {}; this.style = { setProperty() {} }; this.className = '';
      this.events = new Map(); this._text = ''; this.nodeType = 1;
    }
    get isConnected() { return this === document.documentElement || !!this.parentNode?.isConnected; }
    get parentElement(){return this.parentNode;}
    getClientRects(){let node=this;while(node){if(node.hidden)return [];node=node.parentNode;}return this.isConnected?[{}]:[];}
    get textContent() { return this._text + this.children.map(c => c.textContent || '').join(''); }
    set textContent(value) { this._text = String(value); this.children = []; }
    setAttribute(name, value) { this.attributes.set(name, String(value)); notify(this, name); }
    getAttribute(name) { return this.attributes.get(name) ?? null; }
    removeAttribute(name) { this.attributes.delete(name); notify(this, name); }
    append(...children) { for (const child of children) this.appendChild(child); }
    appendChild(child) {
      if (typeof child === 'string') { const text = new Element('#text'); text.textContent = child; child = text; }
      child.parentNode = this; this.children.push(child); return child;
    }
    remove() {
      if (this.parentNode) this.parentNode.children = this.parentNode.children.filter(c => c !== this);
      this.parentNode = null;
    }
    addEventListener(name, fn) { if (!this.events.has(name)) this.events.set(name, new Set()); this.events.get(name).add(fn); }
    removeEventListener(name, fn) { this.events.get(name)?.delete(fn); }
    attachShadow() {
      const shadow = new Element('#shadow'); shadow.host = this; shadow.parentNode = this;
      roots.push(shadow); return shadow;
    }
    matches(selector) {
      if(selector==='a[href^="tel:" i]')return this.tagName==='a'&&/^tel:/i.test(this.getAttribute('href')||'');
      if (selector.startsWith('.')) return this.className.split(' ').includes(selector.slice(1));
      if (selector.startsWith('#')) return this.id === selector.slice(1);
      return this.tagName === selector;
    }
    closest(selector) { return this.matches(selector) ? this : this.parentNode?.closest(selector); }
    querySelectorAll(selector) {
      return this.children.flatMap(child => [ ...(child.matches(selector) ? [child] : []), ...child.querySelectorAll(selector) ]);
    }
    querySelector(selector) { return this.querySelectorAll(selector)[0] || null; }
    focus() {
      let node = this;
      while (node && node.tagName !== '#shadow') node = node.parentNode;
      if (node) { node.activeElement = this; document.activeElement = node.host; }
      else document.activeElement = this;
    }
  }
  const document = {
    createElement: tag => new Element(tag),
    createElementNS: (_, tag) => new Element(tag),
    addEventListener(name, fn) { if (!documentListeners.has(name)) documentListeners.set(name, new Set()); documentListeners.get(name).add(fn); },
    removeEventListener(name, fn) { documentListeners.get(name)?.delete(fn); },
    querySelectorAll: selector => document.documentElement.querySelectorAll(selector),
  };
  document.documentElement = new Element('html');
  const trigger = new Element('button'); trigger.className = 'init-call'; trigger.textContent = '07700 900123';
  document.documentElement.appendChild(trigger);
  document.activeElement = trigger;
  function emit(name, props = {}) {
    const event = { isTrusted: true, target: trigger, preventDefault() {}, stopPropagation() {}, ...props };
    for (const listener of [...documentListeners.get(name) || []]) listener(event);
  }
  function install(id) {
    const timers = new Map(), intervals = new Map();
    const listeners = { message: new Set(), storage: new Set() };
    const state = { alive: true, allowed: true, rejectProbe: false, holdProbe: false, rejectDial: false, holdDial: false };
    const runtime = {
      id,
      getManifest() { if (!state.alive) throw new Error('Extension context invalidated.'); return { version: '1.0.2' }; },
      async sendMessage(message) {
        if (!state.alive || state.rejectProbe) throw new Error('Extension context invalidated.');
        sent.push({ id, message });
        if (message.type === 'AC_CHECK_DISPATCH') return state.holdProbe?new Promise(()=>{}):{ allowed: state.allowed };
        if (message.type === 'DIAL' && state.rejectDial) throw new Error('Call transport unavailable');
        if (message.type === 'DIAL' && state.holdDial) return new Promise(() => {});
        return { received: true };
      },
      onMessage: { addListener: fn => listeners.message.add(fn), removeListener: fn => listeners.message.delete(fn) },
    };
    const context = vm.createContext({
      document, window: { top: null }, MutationObserver: Observer,getComputedStyle:node=>({visibility:node.hidden?'hidden':'visible'}),
      crypto: { randomUUID: () => `owner-${++sequence}` },
      chrome: {
        runtime,
        storage: {
          sync: { async get(defaults) { return { ...defaults }; } },
          onChanged: { addListener: fn => listeners.storage.add(fn), removeListener: fn => listeners.storage.delete(fn) },
        },
      },
      setTimeout(fn, ms) { const id = ++sequence; timers.set(id, { fn, ms }); return id; },
      clearTimeout: id => timers.delete(id),
      setInterval(fn, ms) { const id = ++sequence; intervals.set(id, { fn, ms }); return id; },
      clearInterval: id => intervals.delete(id),
    });
    context.window.top = context.window;
    for (const name of scripts) vm.runInContext(source[name], context, { filename: name });
    return { state, listeners, timers, intervals, reinject() { vm.runInContext(source['dial-dispatch.js'], context); } };
  }
  function clickButton(button, trusted = true) {
    const event = { isTrusted: trusted, target: button, preventDefault() {}, stopImmediatePropagation() {} };
    for (const listener of [...button.events.get('click') || []]) listener(event);
  }
  function mutate(records){for(const observer of observers)if(observer.options.childList)observer.callback(records);}
  function popup(number='',hidden=false){
    const node=new Element('div');node.className='info_popup';node.hidden=hidden;
    const body=new Element('div');body.className='popup_inner_inner';node.append(body);
    if(number){const label=new Element('span');label.textContent='Connecting to';const value=new Element('span');value.textContent=number;body.append(label,value);}
    document.documentElement.append(node);return {node,body};
  }
  return { install, emit, clickButton, trigger, roots, sent, dialogs: () => roots.flatMap(r => r.isConnected ? r.querySelectorAll('.ac-dialog') : []),
    dials: () => sent.filter(s => s.message.type === 'DIAL'), documentListeners,mutate,popup,Element,
    toasts:()=>roots.flatMap(r=>r.isConnected?r.querySelectorAll('.ac-toast'):[]) };
}

test('reinjecting into the same context creates only one prompt and request', async () => {
  const f = fixture(); const a = f.install('current'); a.reinject();
  f.emit('click'); await flush(); assert.equal(f.dialogs().length, 1);
  f.emit('keydown', { key: 'Enter' }); await flush();
  assert.equal(f.dials().length, 1); assert.equal(f.dials()[0].message.number, '+447700900123');
});

test('two isolated guarded copies share one active prompt owner', async () => {
  const f = fixture(); const a = f.install('first'); const b = f.install('second'); await flush();
  assert.equal(a.listeners.message.size, 0); assert.equal(a.listeners.storage.size, 0);
  f.emit('click'); await flush(); assert.equal(f.dialogs().length, 1);
  f.emit('keydown', { key: 'Enter' }); await flush();
  assert.deepEqual(f.dials().map(s => s.id), ['second']);
  assert.equal(b.intervals.size, 0);
});

test('a newer guarded instance cancels and removes an already-open stale dialog', async () => {
  const f = fixture(); const a = f.install('first');
  f.emit('click'); await flush(); assert.equal(f.dialogs().length, 1);
  f.install('second'); await flush(); assert.equal(f.dialogs().length, 0);
  assert.equal(a.intervals.size, 0); assert.equal(a.timers.size, 0);
  f.emit('keydown', { key: 'Enter' }); await flush(); assert.equal(f.dials().length, 0);
  f.emit('click'); await flush(); assert.equal(f.dialogs().length, 1);
});

test('an invalidated runtime cannot open a prompt', async () => {
  const f = fixture(); const a = f.install('old'); a.state.alive = false;
  f.emit('click'); await flush(); assert.equal(f.dialogs().length, 0); assert.equal(f.dials().length, 0);
  assert.equal(a.listeners.message.size, 0);
});

test('invalidating an open prompt removes it without sending a call', async () => {
  const f = fixture(); const a = f.install('old');
  f.emit('click'); await flush(); a.state.alive = false;
  for (const timer of [...a.intervals.values()]) timer.fn();
  await flush(); assert.equal(f.dialogs().length, 0); assert.equal(f.dials().length, 0);
  assert.equal(a.intervals.size, 0); assert.equal(a.timers.size, 0);
});

test('a rejected worker probe cannot leave an old prompt behind', async () => {
  const f = fixture(); const a = f.install('old'); a.state.rejectProbe = true;
  f.emit('click'); await flush(); assert.equal(f.dialogs().length, 0); assert.equal(f.dials().length, 0);
});

test('disabled site is not offered a prompt and can be enabled later', async () => {
  const f = fixture(); const a = f.install('current'); a.state.allowed = false;
  f.emit('click'); await flush(); assert.equal(f.dialogs().length, 0);
  a.state.allowed = true; f.emit('click'); await flush(); assert.equal(f.dialogs().length, 1);
});

test('synthetic clicks and keys cannot approve a call', async () => {
  const f = fixture(); f.install('current');
  f.emit('click', { isTrusted: false }); await flush(); assert.equal(f.dialogs().length, 0);
  f.emit('click'); await flush();
  f.emit('keydown', { isTrusted: false, key: 'Enter' }); await flush();
  assert.equal(f.dialogs().length, 1); assert.equal(f.dials().length, 0);
  f.emit('keydown', { key: 'Escape' }); await flush(); assert.equal(f.dialogs().length, 0);
});

test('confirmation timeout cancels and clears its watchdog', async () => {
  const f = fixture(); const a = f.install('current');
  f.emit('click'); await flush();
  const timeout = [...a.timers.values()].find(t => t.ms === 20000);
  assert.ok(timeout); timeout.fn(); await flush();
  assert.equal(f.dialogs().length, 0); assert.equal(f.dials().length, 0); assert.equal(a.intervals.size, 0);
});


test('Call button removes the complete overlay synchronously before a delayed response', async () => {
  const f = fixture(); const a = f.install('current'); a.state.holdDial = true;
  f.emit('click'); await flush();
  const root = f.roots.find(r => r.isConnected);
  const button = f.dialogs()[0].querySelector('.primary');
  f.clickButton(button);
  assert.equal(root.host.isConnected, false);
  assert.equal(f.dialogs().length, 0);
  assert.equal(button.disabled, true);
  await flush(); assert.equal(f.dials().length, 1);
  assert.equal(a.intervals.size, 0);
});

test('a page focus error cannot strand the confirmation or stop its confirmed call', async () => {
  const f = fixture(); f.install('current');
  f.emit('click'); await flush();
  f.trigger.focus = () => { throw new Error('Page focus handler failed'); };
  f.clickButton(f.dialogs()[0].querySelector('.primary'));
  assert.equal(f.dialogs().length, 0);
  await flush(); assert.equal(f.dials().length, 1);
});

test('Cancel button removes the complete surface without sending a call', async () => {
  const f = fixture(); f.install('current');
  f.emit('click'); await flush();
  const root = f.roots.find(r => r.isConnected);
  f.clickButton(f.dialogs()[0].querySelectorAll('button')[0]);
  assert.equal(root.host.isConnected, false);
  await flush(); assert.equal(f.dials().length, 0);
});

test('rapid repeated clicks on the same Call button send only one request', async () => {
  const f = fixture(); f.install('current');
  f.emit('click'); await flush();
  const button = f.dialogs()[0].querySelector('.primary');
  f.clickButton(button); f.clickButton(button); await flush();
  assert.equal(f.dialogs().length, 0); assert.equal(f.dials().length, 1);
});

test('a rejected call request does not restore the dismissed confirmation', async () => {
  const f = fixture(); const a = f.install('current'); a.state.rejectDial = true;
  f.emit('click'); await flush();
  f.clickButton(f.dialogs()[0].querySelector('.primary')); await flush();
  assert.equal(f.dialogs().length, 0); assert.equal(f.dials().length, 1);
  assert.equal(a.intervals.size, 0);
});

test('a synthetic button click cannot dismiss or confirm the prompt', async () => {
  const f = fixture(); f.install('current');
  f.emit('click'); await flush();
  f.clickButton(f.dialogs()[0].querySelector('.primary'), false); await flush();
  assert.equal(f.dialogs().length, 1); assert.equal(f.dials().length, 0);
});
test('customer popup populated after insertion still offers a confirmation',async()=>{
 const f=fixture();f.install('current');const p=f.popup();f.mutate([{target:p.node.parentNode,addedNodes:[p.node]}]);await flush();
 const label=new f.Element('span');label.textContent='Connecting to';const number=new f.Element('span');number.textContent='07700900123';p.body.append(label,number);
 f.mutate([{target:p.body,addedNodes:[label,number]}]);await flush();assert.equal(f.dialogs().length,1);
});
test('a reused customer popup can offer a different number after the first is cancelled',async()=>{
 const f=fixture(),p=f.popup('07700900123');f.install('current');await flush();f.emit('keydown',{key:'Escape'});await flush();
 const number=p.body.querySelectorAll('span')[1];number.textContent='07700900124';
 f.mutate([{target:number,addedNodes:[{nodeType:3}]}]);await flush();
 assert.equal(f.dialogs().length,1);assert.match(f.dialogs()[0].textContent,/447700900124/);
});
test('hidden customer popups are ignored until they actually open',async()=>{
 const f=fixture(),p=f.popup('07700900123',true);f.install('current');await flush();assert.equal(f.dialogs().length,0);
 p.node.hidden=false;f.mutate([{target:p.node,addedNodes:[],type:'attributes'}]);await flush();assert.equal(f.dialogs().length,1);
});
test('a pending dispatch call blocks another confirmation until its outcome arrives',async()=>{
 const f=fixture();f.install('current');f.emit('click');await flush();f.emit('keydown',{key:'Enter'});await flush();
 f.trigger.textContent='07700900124';f.emit('click');await flush();assert.equal(f.dialogs().length,0);assert.equal(f.dials().length,1);
});
test('dispatch ignores an outcome belonging to an older request',async()=>{
 const f=fixture(),a=f.install('current');f.emit('click');await flush();f.emit('keydown',{key:'Enter'});await flush();
 for(const listener of a.listeners.message)listener({type:'DIAL_STATUS',clientRequestId:'old-request',ok:true},{id:'current'});
 assert.doesNotMatch(f.toasts().at(-1).textContent,/request sent/);
 const request=f.dials()[0].message;
 assert.equal(typeof request.clientRequestId,'string');assert.ok(Number.isFinite(request.expiresAt));
 for(const listener of a.listeners.message)listener({type:'DIAL_STATUS',clientRequestId:request.clientRequestId,ok:true},{id:'current'});
 assert.match(f.toasts().at(-1).textContent,/request sent/);
});
test('lost worker outcomes eventually release the dispatch pending state without retrying',async()=>{
 const f=fixture(),a=f.install('current');f.emit('click');await flush();f.emit('keydown',{key:'Enter'});await flush();
 const watchdog=[...a.timers.values()].find(t=>t.ms===18000);assert.ok(watchdog);watchdog.fn();await flush();
 assert.match(f.toasts().at(-1).textContent,/Check Genesys/);assert.equal(f.dials().length,1);
 f.trigger.textContent='07700900124';f.emit('click');await flush();assert.equal(f.dialogs().length,1);
});
test('a failed worker check does not permanently disable future driver clicks',async()=>{
 const f=fixture(),a=f.install('current');a.state.rejectProbe=true;f.emit('click');await flush();assert.equal(f.dialogs().length,0);
 a.state.rejectProbe=false;f.emit('click');await flush();assert.equal(f.dialogs().length,1);assert.equal(f.dials().length,0);
});
test('a stalled worker check releases the confirmation gate and explains how to recover',async()=>{
 const f=fixture(),a=f.install('current');a.state.holdProbe=true;f.emit('click');await flush();
 const timeout=[...a.timers.values()].find(t=>t.ms===5000);assert.ok(timeout);timeout.fn();await flush();
 assert.match(f.toasts().at(-1).textContent,/try again|refresh/i);
 a.state.holdProbe=false;f.emit('click');await flush();assert.equal(f.dialogs().length,1);
});
test('a driver number stored on an icon-only call control opens confirmation',async()=>{
 const f=fixture();f.trigger.textContent='';f.trigger.setAttribute('data-phone-number','07700 900123');f.install('current');
 f.emit('click');await flush();assert.equal(f.dialogs().length,1);assert.match(f.dialogs()[0].textContent,/447700900123/);assert.equal(f.dials().length,0);
});
test('a standard telephone link opens confirmation without the old iCabbi class',async()=>{
 const f=fixture();f.trigger.className='driver-phone';f.trigger.tagName='a';f.trigger.textContent='Call driver';f.trigger.setAttribute('href','tel:%2B44%207700%20900123');f.install('current');
 let prevented=false;f.emit('click',{preventDefault(){prevented=true;}});await flush();assert.equal(f.dialogs().length,1);assert.equal(prevented,true);assert.equal(f.dials().length,0);
 f.clickButton(f.dialogs()[0].querySelector('.primary'));await flush();assert.equal(f.dials().length,1);assert.equal(f.dials()[0].message.number,'+447700900123');
});
test('a text-node click on a driver number does not throw or lose the confirmation',async()=>{
 const f=fixture();f.install('current');f.emit('click',{target:{nodeType:3,parentElement:f.trigger}});await flush();assert.equal(f.dialogs().length,1);
});
test('disabled dispatch access explains the missing confirmation',async()=>{
 const f=fixture(),a=f.install('current');a.state.allowed=false;f.emit('click');await flush();
 assert.equal(f.dialogs().length,0);assert.match(f.toasts().at(-1).textContent,/Sites/);assert.equal(f.dials().length,0);
});
test('conflicting numbers on a driver link cannot silently select a different destination',async()=>{
 const f=fixture();f.trigger.setAttribute('data-phone-number','07700 900124');f.install('current');f.emit('click');await flush();
 assert.equal(f.dialogs().length,0);assert.equal(f.dials().length,0);assert.match(f.toasts().at(-1).textContent,/different numbers/);
});
