const {test}=require('node:test');
const assert=require('node:assert/strict');
const N=require('../notes.js');
const sample={id:'one',text:'Driver to ring back',done:false,handover:true,createdAt:100,updatedAt:100};
test('notes create with stable timestamps and preserve newlines',()=>{
 const notes=N.mutate([],{action:'add'},()=>sample.id,100);
 const edited=N.mutate(notes,{action:'patch',id:sample.id,patch:{text:'Line one\nLine two'}},null,200);
 assert.equal(edited[0].text,'Line one\nLine two');assert.equal(edited[0].createdAt,100);assert.equal(edited[0].updatedAt,200);
});
test('completion and handover patches do not overwrite note text',()=>{
 const result=N.mutate([sample],{action:'patch',id:sample.id,patch:{done:true}},null,200);
 assert.equal(result[0].text,sample.text);assert.equal(result[0].handover,true);assert.equal(result[0].done,true);assert.equal(sample.done,false);
});
test('handover includes only outstanding marked notes and preserves their text',()=>{
 const text=N.handover([sample,{...sample,id:'two',done:true,text:'Already done'},{...sample,id:'three',handover:false,text:'Private scratch'},{...sample,id:'four',text:'   '}]);
 assert.match(text,/Driver to ring back/);assert.doesNotMatch(text,/Already done|Private scratch/);
 assert.equal(N.handover([{...sample,done:true}]),'');
});
test('notes reject oversized text and edits to deleted entries',()=>{
 assert.throws(()=>N.mutate([sample],{action:'patch',id:'one',patch:{text:'x'.repeat(4001)}},null,200),/4,000/);
 assert.throws(()=>N.mutate([],{action:'patch',id:'one',patch:{text:'Lost'}},null,200),/removed/);
 assert.throws(()=>N.mutate([sample],{action:'patch',id:'one',patch:{done:'true'}},null,200),/Invalid/);
});
test('deletion preserves other notes and corrupted entries cannot crash loading',()=>{
 const list=N.read([null,{},sample,{...sample,id:'two'},sample]);assert.equal(list.length,2);
 const next=N.mutate(list,{action:'delete',id:'one'},null,200);assert.equal(next.length,1);assert.equal(next[0].id,'two');
});
