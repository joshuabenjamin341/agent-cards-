/* Regression checks for enabling sites without managed host approval.
   Browser APIs are mocked. These checks never make a phone call. */
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');

function setup({ sites = [], permitted = [], registered = [], tabs = [], dialerTabs = null, contacts = [], contactsRevision, notes = [], notesRevision, edgeEverywhere = false, edgeHidden = false } = {}) {
  const store = { sites: [...sites], agentCardsContactsV1: contacts, agentCardsContactsRevisionV1:contactsRevision,agentCardsNotesV1:notes,agentCardsNotesRevisionV1:notesRevision,edgeEverywhere,edgeHidden };
  const grants = new Set(permitted.map(h => `https://${h}/*`));
  const scripts = new Map(registered.map(id => [id, { id }]));
  const messages = [], menuItems=[],badges=[];
  const listeners = {};
  const timers = new Map();
  let sequence = 0;
  const managed = { get() { throw new Error('Managed storage must not be read.'); } };
  const chrome = {
    storage: {
      managed,
      local: {
        async get() { return { ...store }; },
        async set(value) { Object.assign(store, value); },
      },
      onChanged:{addListener(fn){listeners.storage=fn;}},
    },
    scripting: {
      async executeScript({target,args}) { if(args)return [{frameId:0,documentId:`source-${target.tabId}`}];return dialerTabs === null || dialerTabs.includes(target.tabId) ? [{frameId:2, documentId:`doc-${target.tabId}`, result:true},{frameId:3, documentId:`other-${target.tabId}`, result:true}] : [{frameId:0,documentId:`doc-${target.tabId}`,result:false}]; },
      async getRegisteredContentScripts(filter) {
        return [...scripts.values()].filter(s => !filter?.ids || filter.ids.includes(s.id));
      },
      async registerContentScripts(values) {
        for (const value of values) scripts.set(value.id, value);
      },
      async unregisterContentScripts({ ids }) { for (const id of ids) scripts.delete(id); },
    },
    permissions: {
      async contains({ origins }) { return origins.every(origin => grants.has(origin)); },
      onRemoved: { addListener(fn) { listeners.removed = fn; } },
      onAdded:{addListener(fn){listeners.added=fn;}},
    },
    runtime: {
      id: 'test-extension',
      getURL: page => `chrome-extension://test-extension/${page}`,
      async openOptionsPage(){listeners.optionsOpened=true;},
      onInstalled: { addListener(fn) { listeners.installed = fn; } },
      onStartup: { addListener(fn) { listeners.startup = fn; } },
      onMessage: { addListener(fn) { listeners.message = fn; } },
    },
    tabs: {
      async query() { return tabs; },
      async sendMessage(id, message, options) { messages.push({ id, message, options }); return { received: true, protocol: 2 }; },
    },
    contextMenus:{removeAll(fn){menuItems.length=0;fn();},create(item,fn){menuItems.push(item);fn?.();},onClicked:{addListener(fn){listeners.menu=fn;}}},
    action:{async setBadgeText(value){badges.push(value);},async setTitle(){},async setBadgeBackgroundColor(){}},
  };
  const context = vm.createContext({
    chrome, URL,
    crypto: { randomUUID() { return `request-${++sequence}`; } },
    setTimeout(fn) { const id = ++sequence; timers.set(id, fn); return id; },
    clearTimeout(id) { timers.delete(id); },
  });
  context.importScripts = (...names) => {
    for (const name of names) vm.runInContext(fs.readFileSync(path.join(root, name), 'utf8'), context);
  };
  context.importScripts('background.js');
  const request=(msg,source={id:'test-extension',url:'chrome-extension://test-extension/popup.html'})=>new Promise(resolve=>listeners.message(msg,source,resolve));
  return { context, store, scripts, grants, messages, listeners, timers, request,menuItems,badges };
}

const sender = { tab: { id: 10 }, frameId: 0, url: 'https://dispatch.example.test/overview' };
const enabled = ['dispatch.example.test', 'genesys.example.test'];

test('a new exact host registers without a managed approval list', async () => {
  const h = setup({ permitted: ['genesys.example.test'] });
  await h.context.registerSite('genesys.example.test');
  assert.deepEqual(Array.from(h.scripts.get('agent-cards:genesys.example.test').matches),
    ['https://genesys.example.test/*']);
});

test('browser permission is still required to register a site', async () => {
  const h = setup();
  await assert.rejects(h.context.registerSite('genesys.example.test'), /Grant browser access/);
  assert.equal(h.scripts.size, 0);
});

test('host validation rejects wildcard, path, credentials, port and invalid input', () => {
  const h = setup();
  for (const host of ['*', '*.example.test', 'example.test/path', 'user@example.test',
    'example.test:8443', 'example.test?query', 'example.test#hash', '', null]) {
    assert.equal(h.context.isValidSiteHost(host), false, String(host));
  }
  assert.equal(h.context.isValidSiteHost('genesys.example.test'), true);
});

test('startup restores granted enabled sites and removes stale registrations', async () => {
  const h = setup({ sites: enabled, permitted: ['genesys.example.test'],
    registered: ['agent-cards:dispatch.example.test', 'agent-cards:old.example.test'] });
  await h.context.syncRegistrations();
  assert.deepEqual([...h.scripts.keys()], ['agent-cards:genesys.example.test']);
});

test('stored hosts are deduplicated and invalid entries are discarded', async () => {
  const h = setup({ sites: ['genesys.example.test', '*', 'genesys.example.test', null] });
  assert.deepEqual(Array.from(await h.context.getSites()), ['genesys.example.test']);
});

test('enabled top-level dispatch with browser access is trusted without IT policy', async () => {
  const h = setup({ sites: enabled, permitted: enabled });
  assert.equal(await h.context.senderIsTrustedDispatch(sender), true);
});

test('disabled, unpermitted, subframe and non-HTTPS senders are rejected', async () => {
  const h = setup({ sites: enabled, permitted: enabled });
  for (const bad of [
    { ...sender, url: 'https://unlisted.example.test/' },
    { ...sender, url: 'http://dispatch.example.test/' },
    { ...sender, frameId: 1 },
    { ...sender, tab: undefined },
  ]) assert.equal(await h.context.senderIsTrustedDispatch(bad), false);
  h.grants.delete('https://dispatch.example.test/*');
  assert.equal(await h.context.senderIsTrustedDispatch(sender), false);
});

test('dispatch call reaches one Genesys tab after UK normalisation', async () => {
  const h = setup({ sites: enabled, permitted: enabled,
    tabs: [{ id: 20, active: true }, { id: 21, active: false }] });
  await h.context.handleDial({ number: '07700 900123' }, sender);
  await new Promise(resolve => setImmediate(resolve));
  const calls = h.messages.filter(m => m.message.type === 'DIAL');
  assert.equal(calls.length, 1);
  assert.equal(calls[0].id, 20);
  assert.equal(calls[0].message.number, '+447700900123');
});

test('premium number is rejected before a dial reaches Genesys', async () => {
  const h = setup({ sites: enabled, permitted: enabled, tabs: [{ id: 20 }] });
  await h.context.handleDial({ number: '0912 345 6789' }, sender);
  assert.equal(h.messages.length, 1);
  assert.equal(h.messages[0].message.reason, 'invalid');
  assert.equal(h.messages[0].id, 10);
});

test('unpermitted sender cannot trigger a call', async () => {
  const h = setup({ sites: enabled, permitted: ['genesys.example.test'], tabs: [{ id: 20 }] });
  await h.context.handleDial({ number: '07700900123' }, sender);
  assert.equal(h.messages.length, 0);
});

test('only the selected Genesys tab can report the outcome', async () => {
  const h = setup({ sites: enabled, permitted: enabled, tabs: [{ id: 20 }] });
  await h.context.relayDial('+447700900123', 10, sender.url);
  const reqId = h.messages[0].message.reqId;
  h.listeners.message({ type: 'DIAL_RESULT', reqId, ok: true }, { tab: { id: 99 } });
  assert.equal(h.messages.length, 1);
  h.listeners.message({ type: 'DIAL_RESULT', reqId, ok: true }, { tab: { id: 20 }, frameId: 2, documentId: 'doc-20' });
  assert.equal(h.messages.length, 2);
  assert.equal(h.messages[1].id, 10);
  assert.equal(h.messages[1].message.type, 'DIAL_STATUS');
  assert.equal(h.messages[1].message.ok, true);
  assert.equal(h.timers.size, 0);
});

test('no available Genesys tab reports a helpful error', async () => {
  const h = setup({ sites: enabled, permitted: enabled });
  await h.context.relayDial('+447700900123', 10, sender.url);
  assert.equal(h.messages[0].message.reason, 'no-tab');
});


test('a non-dialler tab is skipped even when it is active', async () => {
  const h=setup({sites:enabled,permitted:enabled,tabs:[{id:30,active:true},{id:20}],dialerTabs:[20]});
  await h.context.handleDial({number:'07700900123'},sender);
  const calls=h.messages.filter(m=>m.message.type==='DIAL');
  assert.equal(calls.length,1);assert.equal(calls[0].id,20);
  assert.equal(calls[0].options.documentId,'doc-20');
});
test('an open permitted tab without a dialler is not sent a call', async () => {
  const h=setup({sites:enabled,permitted:enabled,tabs:[{id:30}],dialerTabs:[]});
  await h.context.handleDial({number:'07700900123'},sender);
  assert.equal(h.messages[0].message.reason,'no-dialer');
});
test('only the chosen document and frame can acknowledge a request', async () => {
  const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});
  await h.context.relayDial('+447700900123',10);
  const reqId=h.messages[0].message.reqId;
  for(const source of [{tab:{id:20},frameId:3,documentId:'other-20'},{tab:{id:20},frameId:2,documentId:'stale'}])h.listeners.message({type:'DIAL_RESULT',reqId,ok:true},source);
  assert.equal(h.messages.length,1);
  h.listeners.message({type:'DIAL_RESULT',reqId,ok:true},{tab:{id:20},frameId:2,documentId:'doc-20'});
  assert.equal(h.messages.length,2);
});
test('overlapping requests never create a second call', async () => {
  const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});
  await Promise.all([h.context.handleDial({number:'07700900123'},sender),h.context.handleDial({number:'07700900124'},sender)]);
  assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
  assert.equal(h.messages.filter(m=>m.message.reason==='busy').length,1);
});
test('bad input types are rejected without crashing the worker', async () => {
  const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});
  for(const number of [123,{},[],true])await h.context.handleDial({number},sender);
  assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,0);
  assert.equal(h.messages.filter(m=>m.message.reason==='invalid').length,4);
});
test('timeout reports uncertainty, never automatic success or redial', async () => {
  const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});
  await h.context.relayDial('+447700900123',10);
  [...h.timers.values()][0]();
  assert.equal(h.messages.at(-1).message.reason,'timeout');
  assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
});

test('dispatch UI probe only allows an enabled, permitted top-level site', async () => {
  const h=setup({sites:enabled,permitted:enabled});
  async function probe(source){
    return new Promise(resolve=>{
      assert.equal(h.listeners.message({type:'AC_CHECK_DISPATCH'},source,resolve),true);
    });
  }
  assert.equal((await probe(sender)).allowed,true);
  assert.equal((await probe({...sender,frameId:1})).allowed,false);
  assert.equal((await probe({...sender,url:'https://unlisted.example.test/'})).allowed,false);
  h.grants.delete('https://dispatch.example.test/*');
  assert.equal((await probe(sender)).allowed,false);
});

const contact={id:'contact-one',name:'Dispatch desk',number:'+447700900123',label:'Office',favourite:false};
const pause=()=>new Promise(resolve=>setImmediate(resolve));
const optionsSender={id:'test-extension',url:'chrome-extension://test-extension/options.html',tab:{id:55},frameId:0};
function acknowledge(h,ok=true,reason) {
  const call=h.messages.find(m=>m.message.type==='DIAL');
  assert.ok(call,'expected exactly one routed call');
  h.listeners.message({type:'DIAL_RESULT',reqId:call.message.reqId,ok,reason},{tab:{id:call.id},frameId:2,documentId:`doc-${call.id}`});
}
test('popup and full control centre can save contacts without losing existing settings',async()=>{
  const h=setup({sites:enabled});
  await h.request({type:'AC_CONTACTS_MUTATE',action:'save',contact:{...contact,id:undefined}});
  assert.equal(h.store.agentCardsContactsV1.length,1);
  const listed=await h.request({type:'AC_CONTACTS_LIST'},optionsSender);
  assert.equal(listed.contacts[0].number,contact.number);
  assert.deepEqual(h.store.sites,enabled);
});
test('website, other-extension, non-UI extension and iframe senders cannot read, change or dial contacts',async()=>{
  const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
  for(const source of [sender,{...sender,id:'test-extension'}, {...optionsSender,id:'other'}, {...optionsSender,url:'chrome-extension://test-extension/demo.html'}, {...optionsSender,frameId:3}]) {
    for(const msg of [{type:'AC_CONTACTS_LIST'},{type:'AC_CONTACTS_MUTATE',action:'delete',id:contact.id},{type:'AC_CONTACT_DIAL',id:contact.id}]) {
      const result=await h.request(msg,source);assert.equal(result.ok,false);assert.equal(result.contacts,undefined);
    }
  }
  assert.equal(h.store.agentCardsContactsV1.length,1);assert.equal(h.messages.length,0);
});
test('concurrent saves from two extension pages retain both contacts',async()=>{
  const h=setup();
  const results=await Promise.all([
    h.request({type:'AC_CONTACTS_MUTATE',action:'save',contact:{...contact,id:undefined}}),
    h.request({type:'AC_CONTACTS_MUTATE',action:'save',contact:{...contact,id:undefined,name:'Second',number:'07700900124'}},optionsSender)
  ]);
  assert.ok(results.every(r=>r.ok));assert.equal(h.store.agentCardsContactsV1.length,2);
});
test('favourite, edit and delete preserve unrelated contacts and preferences',async()=>{
  const other={...contact,id:'second',number:'+447700900124'};
  const h=setup({sites:enabled,contacts:[contact,other]});
  await h.request({type:'AC_CONTACTS_MUTATE',action:'favourite',id:contact.id,value:true});
  assert.equal(h.store.agentCardsContactsV1[0].favourite,true);
  await h.request({type:'AC_CONTACTS_MUTATE',action:'save',contact:{...contact,name:'Updated'}});
  await h.request({type:'AC_CONTACTS_MUTATE',action:'delete',id:contact.id});
  assert.deepEqual(JSON.parse(JSON.stringify(h.store.agentCardsContactsV1)),[other]);assert.deepEqual(h.store.sites,enabled);
});
test('a rejected save cannot poison the contact write queue',async()=>{
  const h=setup();
  assert.equal((await h.request({type:'AC_CONTACTS_MUTATE',action:'save',contact:{name:''}})).ok,false);
  assert.equal((await h.request({type:'AC_CONTACTS_MUTATE',action:'save',contact:{...contact,id:undefined}})).ok,true);
});
test('contact call uses the saved number and waits for the chosen Genesys document',async()=>{
  const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
  const request=h.request({type:'AC_CONTACT_DIAL',id:contact.id,number:'09123456789'});
  await pause();assert.equal(h.messages.length,1);
  const call=h.messages[0];assert.equal(call.message.number,contact.number);assert.equal(call.options.documentId,'doc-20');
  assert.equal((await h.request({type:'AC_CONTACTS_LIST'})).callState.state,'pending');
  h.listeners.message({type:'DIAL_RESULT',reqId:call.message.reqId,ok:true},{tab:{id:20},frameId:3,documentId:'other-20'});
  assert.equal((await h.request({type:'AC_CONTACTS_LIST'})).callState.state,'pending');
  acknowledge(h);assert.equal((await request).ok,true);
  assert.equal((await h.request({type:'AC_CONTACTS_LIST'})).callState.state,'sent');
  assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
});
test('options-page contact calling works while the active tab is Genesys',async()=>{
  const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20,active:true}]});
  const request=h.request({type:'AC_CONTACT_DIAL',id:contact.id},optionsSender);
  await pause();acknowledge(h);assert.equal((await request).ok,true);
});
test('missing, deleted and invalid stored contacts never reach the dialler',async()=>{
  for(const contacts of [[],[{...contact,number:'+449123456789'}]]){
    const h=setup({sites:enabled,permitted:enabled,contacts,tabs:[{id:20}]});
    assert.equal((await h.request({type:'AC_CONTACT_DIAL',id:contact.id})).reason,'missing-contact');
    assert.equal(h.messages.length,0);
  }
});
test('contact calls still require enabled sites, browser grants and a visible dialler',async()=>{
  for(const config of [{sites:[],permitted:enabled},{sites:enabled,permitted:[]},{sites:enabled,permitted:enabled,dialerTabs:[]}]){
    const h=setup({...config,contacts:[contact],tabs:[{id:20}]});
    const result=await h.request({type:'AC_CONTACT_DIAL',id:contact.id});
    assert.equal(result.ok,false);assert.ok(['no-tab','no-dialer'].includes(result.reason));assert.equal(h.messages.length,0);
  }
});
test('double clicks and simultaneous popup/options calls send only one request',async()=>{
  const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
  const first=h.request({type:'AC_CONTACT_DIAL',id:contact.id});
  const second=await h.request({type:'AC_CONTACT_DIAL',id:contact.id},optionsSender);
  assert.equal(second.reason,'busy');await pause();acknowledge(h);await first;
  assert.equal((await h.request({type:'AC_CONTACT_DIAL',id:contact.id})).reason,'busy');
  assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
});
test('contact and dispatch calls cannot overlap on the same Genesys tab',async()=>{
  const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
  const contactRequest=h.request({type:'AC_CONTACT_DIAL',id:contact.id});await pause();
  await h.context.handleDial({number:'07700900124'},sender);
  assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
  assert.equal(h.messages.find(m=>m.message.type==='DIAL_STATUS').message.reason,'busy');
  acknowledge(h);await contactRequest;
});
test('no outbound line is surfaced to the contact caller as a failure',async()=>{
  const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
  const request=h.request({type:'AC_CONTACT_DIAL',id:contact.id});await pause();acknowledge(h,false,'no-line');
  assert.equal((await request).reason,'no-line');
  assert.equal((await h.request({type:'AC_CONTACTS_LIST'})).callState.state,'failed');
});
test('contact call timeout reports uncertainty without redialling',async()=>{
  const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
  const request=h.request({type:'AC_CONTACT_DIAL',id:contact.id});await pause();
  [...h.timers.values()][0]();assert.equal((await request).reason,'timeout');
  assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
});

test('selected-number parser accepts UK formatting and refuses mixed selections',()=>{
 const h=setup();
 for(const value of ['03306784002','07700 900123','+44 (0)7700 900123','0044 7700 900123'])assert.ok(h.context.selectedPhone(value),value);
 for(const value of ['','Phone: 07700900123','07700900123\n07700900124','07700900123 07700900124','09123456789','+12025550123','999','12345678901',{},null])assert.equal(h.context.selectedPhone(value),null,String(value));
});
test('selection menu is registered once and only appears for selected text',()=>{
 const h=setup();h.context.createSelectionMenu();h.context.createSelectionMenu();
 assert.equal(h.menuItems.length,1);assert.equal(h.menuItems[0].title,'Call through Genesys');assert.deepEqual(Array.from(h.menuItems[0].contexts),['selection']);
});
test('right-click selection routes once from an unrelated page without enabling dispatch there',async()=>{
 const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});
 h.listeners.menu({menuItemId:'agent-cards-call-selection',selectionText:'07700 900123',pageUrl:'https://other.example.test'}, {id:70});
 await pause();assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);assert.equal(h.messages[0].message.number,'+447700900123');
 acknowledge(h);await pause();assert.equal(h.badges.at(-1).text,'✓');assert.deepEqual(h.store.sites,enabled);
});
test('invalid selection never reaches Genesys and shows an error badge',async()=>{
 const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});
 h.listeners.menu({menuItemId:'agent-cards-call-selection',selectionText:'Phone: 07700900123'},{id:70});await pause();
 assert.equal(h.messages.length,0);assert.equal(h.badges.at(-1).text,'!');
});
test('selection and contact clicks share the same in-flight call lock',async()=>{
 const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}],contacts:[contact]});
 const request=h.context.callSelection('07700900124');await pause();
 assert.equal((await h.request({type:'AC_CONTACT_DIAL',id:contact.id})).reason,'busy');
 assert.equal((await h.context.callSelection('07700900124')).reason,'busy');
 acknowledge(h);assert.equal((await request).ok,true);assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
});
test('selected-number calls still require permitted Genesys sites',async()=>{
 const h=setup({sites:enabled,permitted:[],tabs:[{id:20}]});
 assert.equal((await h.context.callSelection('07700900123')).reason,'no-tab');assert.equal(h.messages.length,0);
});
test('drawer data access is limited to top-level allowed pages and real browser grants',async()=>{
 const h=setup({sites:enabled,permitted:[...enabled,'www.google.com'],contacts:[contact]});
 const source={id:'test-extension',url:'https://www.google.com/search?q=test',frameId:0,tab:{id:42}};
 assert.equal((await h.request({type:'AC_CONTACTS_LIST',fromDrawer:true},source)).ok,true);
 for(const bad of [{...source,frameId:1},{...source,id:'other'},{...source,url:'https://other.example.test'},{...source,url:'chrome://newtab'}])assert.equal((await h.request({type:'AC_NOTES_LIST',fromDrawer:true},bad)).ok,false);
 h.grants.delete('https://www.google.com/*');assert.equal((await h.request({type:'AC_NOTES_LIST',fromDrawer:true},source)).ok,false);
});
test('hidden drawer cannot access contacts through a page sender',async()=>{
 const h=setup({sites:enabled,permitted:enabled,edgeHidden:true});
 assert.equal((await h.request({type:'AC_NOTES_LIST',fromDrawer:true},{...sender,id:'test-extension'})).ok,false);
 assert.equal((await h.request({type:'AC_NOTES_LIST'})).ok,true);
});
test('simultaneous note creation and edits preserve both notes and unrelated data',async()=>{
 const h=setup({sites:enabled,contacts:[contact]});
 await Promise.all([h.request({type:'AC_NOTES_MUTATE',action:'add'}),h.request({type:'AC_NOTES_MUTATE',action:'add'},optionsSender)]);
 const ids=h.store.agentCardsNotesV1.map(n=>n.id);
 await Promise.all([h.request({type:'AC_NOTES_MUTATE',action:'patch',id:ids[0],patch:{text:'First note'}}),h.request({type:'AC_NOTES_MUTATE',action:'patch',id:ids[1],patch:{text:'Second note'}})]);
 assert.equal(h.store.agentCardsNotesV1.length,2);assert.equal(h.store.agentCardsNotesV1[0].text,'First note');assert.equal(h.store.agentCardsNotesV1[1].text,'Second note');
 assert.equal(h.store.agentCardsContactsV1[0].name,contact.name);assert.deepEqual(h.store.sites,enabled);
});
test('note input writes in order and a new worker can reload the final saved text',async()=>{
 const h=setup();await h.request({type:'AC_NOTES_MUTATE',action:'add'});const id=h.store.agentCardsNotesV1[0].id;
 await Promise.all(['R','Ri','Ring driver'].map(text=>h.request({type:'AC_NOTES_MUTATE',action:'patch',id,patch:{text}})));
 const reopened=setup({notes:h.store.agentCardsNotesV1,notesRevision:h.store.agentCardsNotesRevisionV1}),loaded=await reopened.request({type:'AC_NOTES_LIST'});
 assert.equal(loaded.notes[0].text,'Ring driver');assert.equal(loaded.revision,4);
 const edited=await reopened.request({type:'AC_NOTES_MUTATE',action:'patch',id,patch:{handover:true}});assert.equal(edited.revision,5);
});
test('existing notes migrate without loss and rejected mutations do not advance their revision',async()=>{
 const existing={id:'old-note',text:'Keep this note',done:false,handover:true,createdAt:100,updatedAt:100},h=setup({notes:[existing]});
 const before=await h.request({type:'AC_NOTES_LIST'});assert.equal(before.revision,0);assert.equal(before.notes[0].text,existing.text);
 const edited=await h.request({type:'AC_NOTES_MUTATE',action:'patch',id:existing.id,patch:{done:true}});
 assert.equal(edited.revision,1);assert.equal(h.store.agentCardsNotesRevisionV1,1);assert.equal(edited.notes[0].text,existing.text);
 const rejected=await h.request({type:'AC_NOTES_MUTATE',action:'patch',id:'missing',patch:{text:'Bad edit'}});
 assert.equal(rejected.ok,false);assert.equal(h.store.agentCardsNotesRevisionV1,1);
});
test('existing contacts retain their data and revision order across worker restarts',async()=>{
 const h=setup({contacts:[contact]}),before=await h.request({type:'AC_CONTACTS_LIST'});
 assert.equal(before.revision,0);assert.equal(before.contacts[0].number,contact.number);
 const edited=await h.request({type:'AC_CONTACTS_MUTATE',action:'favourite',id:contact.id,value:true});
 assert.equal(edited.revision,1);assert.equal(edited.contacts[0].name,contact.name);assert.equal(edited.contacts[0].number,contact.number);
 const reopened=setup({contacts:h.store.agentCardsContactsV1,contactsRevision:h.store.agentCardsContactsRevisionV1});
 const loaded=await reopened.request({type:'AC_CONTACTS_LIST'});assert.equal(loaded.revision,1);assert.equal(loaded.contacts[0].favourite,true);
 const saved=await reopened.request({type:'AC_CONTACTS_MUTATE',action:'save',contact:{...loaded.contacts[0],label:'Updated label'}});
 assert.equal(saved.revision,2);assert.equal(reopened.store.agentCardsContactsRevisionV1,2);
});
test('a failed contact write does not advance the revision or block the next save',async()=>{
 const h=setup({contacts:[contact]}),save=h.context.chrome.storage.local.set;
 h.context.chrome.storage.local.set=async()=>{throw new Error('Storage temporarily unavailable');};
 const failed=await h.request({type:'AC_CONTACTS_MUTATE',action:'favourite',id:contact.id,value:true});
 assert.equal(failed.ok,false);assert.equal(h.store.agentCardsContactsV1[0].favourite,false);
 assert.equal((await h.request({type:'AC_CONTACTS_LIST'})).revision,0);
 h.context.chrome.storage.local.set=save;
 const saved=await h.request({type:'AC_CONTACTS_MUTATE',action:'favourite',id:contact.id,value:true});
 assert.equal(saved.revision,1);assert.equal(h.store.agentCardsContactsV1[0].favourite,true);
});
test('deleting a note while another window edits cannot resurrect it',async()=>{
 const h=setup();await h.request({type:'AC_NOTES_MUTATE',action:'add'});const id=h.store.agentCardsNotesV1[0].id;
 await h.request({type:'AC_NOTES_MUTATE',action:'delete',id});
 const result=await h.request({type:'AC_NOTES_MUTATE',action:'patch',id,patch:{text:'stale'}});assert.equal(result.ok,false);assert.equal(h.store.agentCardsNotesV1.length,0);
});
test('broad drawer registration requires opt-in and grants, never changes enabled calling sites',async()=>{
 const h=setup({sites:enabled,permitted:enabled,edgeEverywhere:true});await h.context.syncEdgeRegistration();assert.equal(h.scripts.size,0);
 h.grants.add('https://*/*');h.grants.add('http://*/*');await h.context.syncEdgeRegistration();assert.ok(h.scripts.has('agent-cards-edge-everywhere'));assert.deepEqual(h.store.sites,enabled);
 h.store.edgeEverywhere=false;await h.context.syncEdgeRegistration();assert.equal(h.scripts.size,0);
});
test('a stalled dialler lookup times out and cannot send after the late probe returns',async()=>{
 const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});let finishProbe;
 h.context.chrome.scripting.executeScript=()=>new Promise(resolve=>finishProbe=resolve);
 const request=h.request({type:'AC_CONTACT_DIAL',id:contact.id});await pause();
 assert.ok(h.timers.size>0,'the call deadline must start before looking up the dialler');
 [...h.timers.values()][0]();assert.equal((await request).reason,'timeout');
 finishProbe([{frameId:2,documentId:'doc-20',result:true}]);await pause();
 assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,0);
 assert.equal((await h.request({type:'AC_CONTACTS_LIST'})).callState.state,'failed');
});
test('routed call messages have an absolute expiry checked by the receiver',async()=>{
 const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]}),started=Date.now();
 await h.context.handleDial({number:'07700900123'},sender);
 const call=h.messages.find(m=>m.message.type==='DIAL');assert.ok(Number.isFinite(call.message.expiresAt));
 assert.ok(call.message.expiresAt>=started&&call.message.expiresAt<=Date.now()+14000);
});
test('a completed contact request still blocks an immediate dispatch call to the same dialler',async()=>{
 const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
 const request=h.request({type:'AC_CONTACT_DIAL',id:contact.id});await pause();acknowledge(h);await request;
 await h.context.handleDial({number:'07700900124'},sender);
 assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);assert.equal(h.messages.at(-1).message.reason,'busy');
});
test('a delivery-channel failure reports an unknown outcome rather than assuring the dialler is absent',async()=>{
 const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
 h.context.chrome.tabs.sendMessage=async(id,message,options)=>{h.messages.push({id,message,options});if(message.type==='DIAL')throw new Error('Channel closed');};
 const result=await h.request({type:'AC_CONTACT_DIAL',id:contact.id});assert.equal(result.reason,'unavailable');assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,1);
});
test('dispatch outcomes return to the original document and carry its request ID',async()=>{
 const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});
 await h.context.handleDial({number:'07700900123',clientRequestId:'dispatch-request'},{...sender,documentId:'dispatch-document'});acknowledge(h);
 const status=h.messages.find(m=>m.message.type==='DIAL_STATUS');assert.equal(status.options.documentId,'dispatch-document');assert.equal(status.message.clientRequestId,'dispatch-request');
});
test('an expired contact click cannot become a fresh call after reaching the worker late',async()=>{
 const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});
 const result=await h.request({type:'AC_CONTACT_DIAL',id:contact.id,expiresAt:Date.now()-1});assert.equal(result.reason,'expired');assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,0);
});
test('a stalled contact lookup times out and a late storage result cannot initiate a call',async()=>{
 const h=setup({sites:enabled,permitted:enabled,contacts:[contact],tabs:[{id:20}]});let finishRead;
 const originalGet=h.context.chrome.storage.local.get;
 h.context.chrome.storage.local.get=()=>new Promise(resolve=>finishRead=resolve);
 const request=h.request({type:'AC_CONTACT_DIAL',id:contact.id});await pause();assert.equal(h.timers.size,1);
 [...h.timers.values()][0]();assert.equal((await request).reason,'timeout');
 h.context.chrome.storage.local.get=originalGet;finishRead({...h.store});await pause();
 assert.equal(h.messages.filter(m=>m.message.type==='DIAL').length,0);
 assert.equal((await h.request({type:'AC_CONTACTS_LIST'})).callState.state,'failed');
});
test('dialler discovery requires the current receiver and ignores hidden old openers',async()=>{
 const h=setup();let protocol;
 const hidden={getClientRects:()=>[]},visible={getClientRects:()=>[{}]};
 h.context.chrome.scripting.executeScript=async({func})=>{
  const result=vm.runInNewContext(`(${func.toString()})()`,{__agentCardsDialProtocol:protocol,document:{querySelectorAll:()=>[hidden,visible]},getComputedStyle:()=>({visibility:'visible'})});
  return [{frameId:0,documentId:'doc-20',result}];
 };
 assert.equal((await h.context.findDialers({id:20})).length,0);
 protocol=2;assert.equal((await h.context.findDialers({id:20})).length,1);
});
test('an expired dispatch click is rejected before tab lookup and keeps its response identity',async()=>{
 const h=setup({sites:enabled,permitted:enabled,tabs:[{id:20}]});let queried=false;
 h.context.chrome.tabs.query=async()=>{queried=true;return [{id:20}];};
 await h.context.handleDial({number:'07700900123',expiresAt:Date.now()-1,clientRequestId:'late-click'},{...sender,documentId:'dispatch-document'});
 assert.equal(queried,false);assert.equal(h.messages[0].message.reason,'expired');assert.equal(h.messages[0].message.clientRequestId,'late-click');
 assert.equal(h.messages[0].options.documentId,'dispatch-document');
});
