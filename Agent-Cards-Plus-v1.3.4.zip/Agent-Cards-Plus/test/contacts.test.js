const {test}=require('node:test');
const assert=require('node:assert/strict');
require('../security.js');
const C=require('../contacts.js');
const example={name:' Dispatch desk ',number:'07700 900123',label:' Night shift ',favourite:true};
const makeId=require('node:crypto').randomUUID;

test('contacts save normalised numbers, trimmed names and optional labels',()=>{
  assert.deepEqual(C.validate(example),{name:'Dispatch desk',number:'+447700900123',label:'Night shift',favourite:true});
  assert.equal(C.displayNumber('+441482000000'),'01482 000000');
});
test('contacts reject empty names, malformed numbers, extensions and blocked ranges',()=>{
  for(const patch of [{name:''},{name:' '.repeat(5)},{name:'x'.repeat(81)},{number:'07700900123 ext 9'},{number:'+12025550123'},{number:'09123456789'},{number:'08451234567'},{number:'<img>07700900123'},{number:123},{number:'999'},{label:'a'.repeat(61)}]) {
    assert.throws(()=>C.validate({...example,...patch}));
  }
});
test('same number cannot be saved twice with different formatting',()=>{
  const list=C.upsert([],example,makeId);
  assert.throws(()=>C.upsert(list,{...example,number:'+447700900123'},makeId),/already saved/);
  assert.equal(list.length,1);
});
test('editing preserves ID, updates fields and does not mutate the original contact',()=>{
  const list=C.upsert([],example,makeId), id=list[0].id;
  const next=C.upsert(list,{...list[0],name:'Evening desk',favourite:false},makeId);
  assert.equal(next[0].id,id);assert.equal(next[0].name,'Evening desk');assert.equal(next[0].favourite,false);
  assert.equal(list[0].name,'Dispatch desk');
  assert.throws(()=>C.upsert([],{...example,id},makeId),/removed/);
});
test('stored malformed and duplicate contacts are safely discarded',()=>{
  const list=C.upsert([],example,makeId);
  assert.deepEqual(C.read([null,{},...list,{...list[0],name:'Duplicate'},{...list[0],id:'other'},{...list[0],id:'bad',number:'abc'}]),list);
});
test('contact backups merge by normalised number without overwriting existing details',()=>{
  const list=C.upsert([],example,makeId);
  const result=C.merge(list,{format:'agent-cards-contacts',version:1,contacts:[{...example,name:'Changed'}, {...example,name:'Second',number:'07700900124'}]},makeId);
  assert.equal(result.added,1);assert.equal(result.skipped,1);assert.equal(result.contacts[0].name,'Dispatch desk');
  assert.equal(result.contacts[1].number,'+447700900124');assert.equal(list.length,1);
});
test('invalid imports fail completely before changing existing contacts',()=>{
  const list=C.upsert([],example,makeId);
  for(const backup of [{format:'agent-cards-settings',version:1,contacts:[]},{format:'agent-cards-contacts',version:2,contacts:[]},{format:'agent-cards-contacts',version:1,contacts:[example,{...example,number:'invalid'}]}])assert.throws(()=>C.merge(list,backup,makeId));
  assert.equal(list.length,1);
});
test('contact limits apply to both saving and merged backups',()=>{
  const list=Array.from({length:C.LIMIT},(_,i)=>({id:`c${i}`,name:`Contact ${i}`,number:`+447700${String(i).padStart(6,'0')}`,label:'',favourite:false}));
  assert.throws(()=>C.upsert(list,example,makeId),/500/);
  assert.throws(()=>C.merge(list,{format:'agent-cards-contacts',version:1,contacts:[example]},makeId),/500/);
});
