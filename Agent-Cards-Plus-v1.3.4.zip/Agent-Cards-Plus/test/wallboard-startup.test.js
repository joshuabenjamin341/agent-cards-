/* Startup ordering with simulated browser APIs, not a rendering test. */
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {dom}=require('../test-support/desk-dom');
const root=path.resolve(__dirname,'..'),flush=()=>new Promise(resolve=>setImmediate(resolve));
function fixture(){
 const d=dom();let finishSettings,changed;
 const context=vm.createContext({...d,location:{protocol:'https:',hostname:'genesys.example.test'},
  chrome:{storage:{sync:{get:defaults=>new Promise(resolve=>finishSettings=()=>resolve({...defaults})),async set(){}},local:{async get(){return {};}},onChanged:{addListener:fn=>changed=fn}}},
  performance:{now:()=>0},setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,cancelAnimationFrame(){},addEventListener(){},
  matchMedia:()=>({matches:false,addEventListener(){}}),AC_FIT:{create:()=>({update(){}})}
 });
 for(const name of ['defaults.js','cards.js'])vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),context,{filename:name});
 return {...d,finishSettings:()=>finishSettings(),change:changes=>changed(changes,'sync')};
}
test('an initial wallboard read cannot undo preferences received while it was loading',async()=>{
 const f=fixture();
 f.change({textScale:{newValue:1.8},autoFit:{newValue:true},theme:{newValue:'paper'}});
 f.finishSettings();await flush();
 assert.equal(f.document.documentElement.style['--agent-cards-text-scale'],1.8);
 assert.equal(f.document.documentElement.classList.contains('agent-cards-auto-fit'),true);
 assert.equal(f.document.documentElement.dataset.acTheme,'paper');
});
