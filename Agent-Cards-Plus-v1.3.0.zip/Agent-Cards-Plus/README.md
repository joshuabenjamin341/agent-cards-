# Agent Cards Plus for Genesys

Version 1.3.0. An upgrade of the supplied 0.8.0 extension.

A redesigned control centre, clearer agent cards and useful live wallboard controls, with the existing confirmed dispatch-to-Genesys calling integration.

## Brighter pulses, Auto fit and text sizing in 1.3.0

### Set up the large wallboard

Open **Appearance > One-click setups > Big screen**. This switches on the
full-width agent band, Auto fit, call glow, breathing glow and auto-scroll.
You can also switch on **Appearance > Card layout > Auto fit**, or use the
**Auto fit** button in the live widget toolbar without choosing a preset.

- Auto fit chooses columns and whole-card scale separately for each Agent
  Status widget, using its available space and visible, loaded agent count.
- It responds to widget/window resizing, full-screen changes, filters,
  changing agent counts and expanded/collapsed controls.
- Large displays can use up to 12 columns and 300% whole-card scale. It keeps
  a 75% minimum, with scrolling when all cards cannot fit comfortably.
- In full-width band mode, it allocates the agent band from the available
  dashboard height and reserves space for the other visible widget rows.
  Native Genesys widgets retain their own content layout and scrolling.
- A label in the controls shows the chosen columns and card scale. Overflow
  is marked “scroll to see more”. Automatic scrolling follows its existing
  setting; you can always scroll manually when it is off.
- Manual column count, card scale and band height remain saved. Switch Auto
  fit off to use them again. Existing installations start in their previous
  manual sizing mode until you enable Auto fit or choose Big screen.

### Make just the writing bigger

Use **Appearance > Card layout > Text size only**, from **75% to 200%**.
This changes agent names, status labels and timers while keeping card padding
at the selected whole-card scale. Names and statuses can wrap, cards grow in
height and the column count reduces when needed. The setting works with both
manual and automatic card sizing and is saved independently.

Auto fit chooses a baseline card scale at normal text size, then honours your
text adjustment at that scale. Larger text therefore stays larger instead of
being cancelled by a smaller automatic zoom. If it needs more space, the
cards scroll. Other widget labels, browser controls and the extension's own
settings text keep their usual sizes.

### A more visible call pulse

Active calls now have a vivid blue wash across the whole card, a bright
outline and a stronger, smooth 2.6-second pulse. The text remains above the
highlight. Midnight, Graphite and Paper each retain readable foregrounds.
Turn **Breathing glow** off for a steady highlight, or **Call glow** off to
remove it. Reduced motion, including the system preference, stops animation.
The Control centre preview uses the same stronger treatment.

This update adds no permissions and preserves contacts, notes, the sliding
desk, right-click calling and the previous call-popup fixes.

## Sliding desk, shift notes and selection calling in 1.2.0

### The edge tab

Look for the small **DESK** tab on the right edge of Google Search or an
enabled work site. Click it to slide out Contacts and Shift notes. Close it
with the side tab, the close button or Escape. The page remains usable while
the panel is open, and collapsing the panel keeps its editors mounted.

The drawer follows your existing theme, accent and reduced-motion setting.
Its connection button checks for a visible Genesys dialler; it does not
claim a line is ready or a call is connected.

By default the tab appears on `google.com`, `www.google.com`, `google.co.uk`,
`www.google.co.uk` over HTTPS and your enabled work sites. For other normal
websites, open **Sites > Side tab settings > Show side tab on all websites**
and accept the browser site-access prompt. This enables only the drawer;
dispatch calling still requires its separately enabled exact site.

Chrome/Edge New Tab pages, browser settings, other extensions and protected
pages do not receive the injected edge tab. The normal toolbar popup and
Control centre remain available. The extension does not replace your New
Tab page or change your search engine. Site tab settings can hide the drawer
or limit it back to Google and work sites. Refresh open tabs after changing
scope. Limiting the drawer's scope does not revoke the browser's existing
host grants; those can be managed in the browser's extension settings.

### Shift notes

- Add a note and type. Each input sends its save to the background worker.
- Tick a note when it is done. Outstanding hides completed notes; All notes
  keeps them available.
- Mark notes **For handover**. **Copy handover** copies only marked,
  outstanding notes, with their creation times. It never sends them anywhere.
- Export all notes to a plain-text file. Delete uses an inline confirmation.
- Up to 200 notes of 4,000 characters each are stored on this browser profile.
- Notes are shared between the drawer, popup and Control centre. They persist
  through reloads and browser restarts, but uninstalling clears extension data.
- Simultaneous edits to different notes merge. If the same note text is edited
  in two windows, the most recent accepted text wins. Failed saves remain in
  the editor with an error; copy any unsaved text before refreshing.

### Highlight a number and call

Select one complete UK phone number, right-click and choose **Call through
Genesys**. This click starts a call request immediately, without another
confirmation dialog. It does not require saving a contact or enabling the
source page as a dispatch site. Keep Genesys Agent Workspace open, its exact
site enabled and its outbound line selected.

Selections containing names, extra text, multiple numbers, short codes or
blocked number ranges are rejected. A status message reports the request
outcome. If a page cannot display a message, the extension's toolbar badge
and tooltip provide feedback. A successful request does not confirm an
answered call. After a timeout, check Genesys before trying again.

The contact and selection routes share the same duplicate-call lock and
single-document relay. Existing dispatch confirmations and their dismissal
fix remain in place. The empty phone-field message is now explicit about
which box needs a number.

### Added access

This version adds the browser's `contextMenus` permission and default drawer
content-script access to the four Google hostnames above. All-other-website
drawer access is optional and requested only by its settings button. Existing
Genesys and dispatch permissions are preserved. No server, account or cloud
notes service is added.

## Saved contacts and speed dial in 1.1.0

Open **Contacts** in the toolbar popup or Control centre, then **Add contact**.
Save a name and UK number, optionally adding a label and pinning it as a
favourite. Click the contact's name/number or **Call** area to send the call
straight to Genesys. There is no second confirmation for saved-contact calls.
The star and pencil are separate controls and never start a call.

- Save up to 500 contacts; search by name, label or number.
- Favourites appear first, followed by names in alphabetical order.
- Edit through the pencil button. Delete requires an inline confirmation.
- Contacts stay in this browser profile between sessions and extension reloads.
- Use **Back up & move contacts** to export or import a JSON contacts backup.
  Imports add new numbers and retain existing entries for duplicate numbers.
  Invalid backups are rejected without partially importing entries.
- Contact backups are separate from preference backups and contain names,
  numbers and labels. Uninstalling the extension removes its browser data.

Keep Genesys Agent Workspace open and its exact site enabled. The current
Genesys outbound line or queue is used. No dispatch tab is needed to call a
saved contact. Contact calling uses the existing permitted-site checks,
UK number rules, single-document routing and overlapping-call protection.
Only the extension's popup and Control centre can request contact operations;
the worker resolves the number from the saved contact ID.

The popup reports **Call request sent to Genesys** after Genesys acknowledges
the request. This does not mean the recipient answered. If a response times
out, check Genesys before trying again. Closing the toolbar popup does not
cancel a request already submitted to Genesys.

Existing dispatch confirmation, immediate popup dismissal and duplicate-popup
fixes are retained. Version 1.1.0 added no permissions; see above for the
new 1.2.0 drawer and context-menu access.

## Call-button dismissal fix in 1.0.2

The Call and Cancel buttons now immediately detach the entire confirmation
surface, including its backdrop. Call submission and status notifications run
after that dismissal. Restoring focus to the dispatch page happens separately,
so a page focus error cannot interrupt the confirmed request. Button events
are contained within the extension UI and repeated clicks settle only once.

Six new simulated interaction checks cover the Call and Cancel buttons,
delayed and failed call responses, focus errors, repeated clicks and synthetic
click rejection. The reported workplace behaviour has not been reproduced
against a live Genesys session. If a different popup remains after this update,
a screenshot will help identify whether it belongs to the extension or the
dispatch application.

## Duplicate call-prompt fix in 1.0.1

- Check the live extension worker and enabled-site access before opening a prompt.
- Share one prompt owner across guarded copies running in separate extension contexts.
- Remove an existing guarded prompt when a replacement instance takes over.
- Stop stale listeners and cancel the prompt if the extension context is invalidated.
- Preserve the single confirmation, trusted user interaction, timeout and UK number checks.

An older unpatched extension does not participate in the new guard. If the old
white call prompt still appears behind the new prompt, disable the separately
installed older copy and refresh both work tabs. Updating or disabling an
extension alone does not replace every script already loaded in an open page.

## Updating your existing installation

1. Extract the ZIP.
2. Copy the contents of **Agent-Cards-Plus** into the folder your existing extension is loaded from. Replace the old files, keeping `manifest.json` in the same location.
3. Open `chrome://extensions` or `edge://extensions` and click **Reload** on the extension. It now appears as **Agent Cards Plus for Genesys**.
4. Refresh your Genesys and dispatch tabs.
5. Open the toolbar popup. Select **Control centre** for the full settings screen, or **Demo** to try the new wallboard.

Updating the files in the same installed folder retains the extension identity, site access and preferences. Existing preference keys migrate automatically. If you load a different folder as a new extension, disable the old copy first and enable your sites again.

## New installation

1. Extract the ZIP into a permanent folder.
2. Open `chrome://extensions` or `edge://extensions`.
3. Turn on **Developer mode**, choose **Load unpacked**, and select the **Agent-Cards-Plus** folder containing `manifest.json`.
4. Pin the extension to the toolbar.
5. Open Genesys, click the extension, choose **Sites**, then **Enable this site**. Accept the browser permission prompt.
6. Repeat for your dispatch site, then refresh both tabs.
7. Keep Genesys Agent Workspace open when using click-to-dial.

Chromium 119 or newer is required. The extension uses Manifest V3 and has no build step or external packages at runtime. Browser or workplace installation restrictions still apply. The supplied extension's lack of an internal IT host-approval lock is preserved.

## What's new

### Appearance

- New toolbar popup and a full-size control centre.
- Midnight, Graphite and Paper themes.
- Mint, Violet, Blue, Amber, Rose and Cyan accents.
- Refreshed icons, cards, typography, status colours and focus states.
- Desk, Big screen and Compact presets.
- Card and compact layouts, manual controls plus per-widget Auto fit.
- Manual card scale from 75% to 175%, automatic scale up to 300%, and separate 75% to 200% text size.
- Active-call glow, optional pulse and call-timer prioritisation.
- Reduced-motion setting and respect for the operating system's motion preference.
- Theme changes apply to the Agent Status widget. Other Genesys widgets keep their existing appearance.

### Live wallboard controls

- Loaded-agent, ready, interacting and attention totals. Click a total to filter.
- Search by name and filter by status.
- Sort by original order, name, status or longest duration.
- Pin agents with the star to keep them above other rows. Pins are saved on this device, separately for each hostname.
- Show pinned agents only, clear filters, or hide offline agents.
- A clock with seconds, in 12-hour or 24-hour format.
- Full-screen view of a single Agent Status widget.
- Collapse the controls when working with a narrow widget.
- Configurable duration limits for calls, breaks/meals, away/meetings and after-call work.
- An amber outline and **OVER LIMIT** label when a supported displayed timer reaches its limit.

Counts and alerts apply only to rows currently loaded in each widget. They are not organisation-wide totals, queue statistics, utilisation or SLA measurements. Searches and status filters are temporary for that widget. Hiding the toolbar clears their visual effect. Pinned agents stay at the top even when the star controls are hidden.

**Ready** means idle or on queue, excluding a recognised active-call, after-call-work or not-responding state. **Available** is a separate status and does not imply that an agent is taking queue calls. Unknown status labels stay under **Other**. Timers that cannot be parsed do not trigger duration alerts.

### Scrolling and display

- Adjustable auto-scroll speed and pauses at each end.
- Optional hover pause.
- A 12-second pause after wheel, touch, pointer or keyboard interaction.
- Scrolling pauses while a control inside the scroller has focus. Click outside the widget to let it resume.
- Scrolling and refresh work pause when the tab is hidden.
- Reduced motion stops scrolling and animation.
- Full-width agent-band mode and adjustable height.

Manual large-card columns adapt down in narrow widgets. Manual compact rows use one column normally and the chosen column count in full-width band mode. Auto fit can use multiple columns in either style. Adjusting text size also reduces columns when needed.

### Calling improvements

- Checks permitted open tabs for a visible Genesys dialler before sending a request.
- Prefers an active matching tab, then the most recently accessed matching tab.
- Targets one specific document, including when Agent Workspace is inside a frame.
- Checks the responding tab, document and frame before accepting its result.
- Blocks overlapping relay requests and repeated request IDs.
- Independently validates the number in the worker and receiver.
- Removes the old Enter-key fallback for a disabled call button.
- Says **Call request sent to Genesys** only after clicking an enabled call button. This does not verify that a call connected or was answered.
- Adjustable confirmation timeout and a connection-check button.

The existing `.init-call` driver link and customer “Connecting to” popup hooks are retained. Dispatch calls still require a real confirmation click or Enter key. Escape cancels. Saved contacts use a direct click on their call area instead. Existing UK number conversion and blocked number ranges remain in place. Select your outbound line or queue in Genesys as usual.

A timeout means the extension did not receive an acknowledgement. Check Genesys before trying again, to avoid repeating a request that it may already have received.

### Settings and demo

- Automatic saving, with settings shared between the popup, control centre and open wallboards.
- Export/import validated JSON preference backups.
- Reset appearance and behaviour settings without removing sites or pins.
- Interactive demo using fictional agents, simulated timers and the real card code.
- The small settings preview is illustrative. The full demo provides actual search, filtering, pins, timers and sorting.
- Demo setting changes also apply to enabled live wallboards.

## Data and permissions

Appearance and behaviour preferences use `chrome.storage.sync`, which may synchronise through your browser account. Enabled hostnames, pinned agent identifiers, saved contacts and shift notes use `chrome.storage.local`. Contacts and notes do not automatically synchronise between desks. Preference backups, contact backups and note exports are separate.

The extension reads agent names, statuses and timers from the already-loaded page. It stores the contacts and notes you choose to save and does not record agent or call history or use an external analytics service. Calling uses your existing signed-in Genesys session. A temporary in-memory contact-call result lets a reopened popup show a request still being processed. Highlighted phone numbers are used for the requested call and not added to contacts automatically.

Site access is granted per exact HTTPS hostname. Removing a site unregisters the scripts and attempts to revoke browser access. Refresh any open tabs on that site to clear scripts and styling already loaded.

## Troubleshooting

**Two call prompts:** Open `chrome://extensions` or `edge://extensions`. Keep
only the current **Agent Cards Plus for Genesys** copy enabled. Disable older
**Genesys Wallboard Agent Cards** or **No IT Lock** copies, then refresh the
dispatch and Genesys tabs. You do not need to uninstall an older copy to test
this. This fix cannot suppress another extension's unpatched prompt or remove
a confirmation built into your dispatch application.


**No cards or controls:** Enable the Genesys site, refresh the page, and open a dashboard containing the Agent Status widget. This extension targets the supplied `.widget-type-AGENT_STATUS gux-table` markup. A changed Genesys layout may need a selector update.

**No call reaches Genesys:** Enable both exact hostnames, refresh both tabs and open Agent Workspace. Run **Calling > Check workspace connection**. If Workspace is in a different-host frame, its hostname may also need to be enabled. Outbound line or queue selection remains a Genesys setting.

**Cards seem missing:** Clear search/status/pinned filters and check **Hide offline agents**. Only the rows Genesys has loaded can be displayed.

**Auto-scroll is stationary:** It only runs when the widget overflows. Check automatic scrolling, reduce motion, the hover pause, focus and the manual pause button.

**All columns look squeezed:** Enable Auto fit or choose Big screen. Use Text size only to increase writing independently. Dense agent lists may need scrolling. Other native Genesys widgets retain their own layouts.

## Validation

Version 1.3.0 was checked with simulated geometry, documents and browser APIs.
New checks cover 1080p/4K dimensions, small widgets, independent widget fits,
resizing, filtering, scrolling, full screen, manual-setting restoration,
separate text sizing, observer cleanup, stable repeated layout, measurement
caching, preset behaviour and control enable/disable states.
The current pulse and fitting layout have not been rendered in Chromium or
checked on a live Genesys wallboard in this environment. Please check the
appearance on the target display after updating. No real phone call was made.


Run `node --test` with Node 18 or newer. The package includes 134 dependency-free regression tests covering notes and concurrent edits, handover, the drawer lifecycle, selection calling, contact storage, backup merging, search, favourites, trusted extension senders, settings migration, timers and statuses, permissions, number rules, routing, duplicate suppression, document validation and timeout outcomes.

Version 1.2.0 was checked using simulated documents and mocked extension APIs.
Checks cover drawer open/close/reinjection/cleanup, input saving, handover,
note reloads, selection validation, browser menu routing and call overlap.
JavaScript syntax, HTML/script references and ZIP integrity were also checked.
The drawer animation and layout have not been rendered in a real browser in
this environment. No live Genesys account or workplace phone call was used.

Version 1.1.0 contact interactions were checked using simulated documents and
mocked extension/Genesys responses, including delayed responses, lost responses,
rapid clicks and reopening saved contacts. A headless browser binary was not
available in this environment, so the new Contacts layout has not been visually
verified in Chromium. No live workplace call was made.

The original 1.0.0 UI was exercised in headless Chromium with simulated Genesys rows and mocked extension APIs. Checks covered layouts, saved preferences, filters, pins, sorting, alerts, DOM rerenders, scrolling, confirmation and call-button behaviour. Screenshots of the control centre and demo are included in `previews`.

The 1.0.1 fix was checked with simulated documents, isolated extension contexts and mocked browser APIs. Its tests cover reinjection, duplicate guarded copies, open-dialog replacement, invalidated contexts, declined worker probes, synthetic events and confirmation timeout.

The test environment could not load a real unpacked extension. No live Genesys account or workplace call was used, so real site integration and browser permission prompts remain to be checked after installation.

The original MIT licence is retained in `LICENSE`.

API references used for this update:
- https://developer.chrome.com/docs/extensions/reference/api/contextMenus
- https://developer.chrome.com/docs/extensions/reference/api/permissions

Sizing API reference: https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver
