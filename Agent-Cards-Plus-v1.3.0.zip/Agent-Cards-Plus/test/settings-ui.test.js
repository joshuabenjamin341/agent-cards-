/* Settings interactions against the shipped HTML; no real browser account. */
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {dom}=require('../test-support/desk-dom');
const root=path.resolve(__dirname,'..'),flush=()=>new Promise(r=>setImmediate(r));
function fixture(initial={},file='popup.html') {
  const d=dom(),timers=new Map(),writes=[];let sequence=0,listener;
  d.document.documentElement.innerHTML=fs.readFileSync(path.join(root,file),'utf8');
  d.document.body=d.document.querySelector('body');
  const saved={...initial};
  const chrome={storage:{sync:{async get(defaults){return {...defaults,...saved};},async set(patch){writes.push({...patch});Object.assign(saved,patch);listener?.(Object.fromEntries(Object.entries(patch).map(([k,newValue])=>[k,{newValue}])),'sync');}},local:{async get(){return {};},async set(){}},onChanged:{addListener:fn=>listener=fn}},runtime:{openOptionsPage(){},getURL:s=>s},tabs:{create(){}}};
  const context=vm.createContext({...d,chrome,confirm:()=>true,setTimeout:fn=>{timers.set(++sequence,fn);return sequence;},clearTimeout:id=>timers.delete(id)});
  for(const name of ['defaults.js','popup.js'])vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),context,{filename:name});
  return {...d,saved,writes,$:id=>d.document.getElementById(id)};
}
test('Auto fit disables manual dimensions while keeping the text-only slider active',async()=>{
  const f=fixture({columns:5,fontScale:1.4,wallboardHeight:75,wallboard:true});await flush();
  f.$('autoFit').checked=true;await f.$('autoFit').emit('input');await f.$('autoFit').emit('change');
  assert.equal(f.$('columns').disabled,true);assert.equal(f.$('fontScale').disabled,true);assert.equal(f.$('wallboardHeight').disabled,true);assert.equal(f.$('textScale').disabled,false);
  assert.equal(f.saved.columns,5);assert.equal(f.saved.fontScale,1.4);assert.equal(f.saved.wallboardHeight,75);
  f.$('autoFit').checked=false;await f.$('autoFit').emit('input');await f.$('autoFit').emit('change');
  assert.equal(f.$('columns').disabled,false);assert.equal(f.$('fontScale').disabled,false);assert.equal(f.$('wallboardHeight').disabled,false);assert.equal(f.$('columns').value,5);
});
test('text-only slider saves its own value and updates preview without altering manual card scale',async()=>{
  const f=fixture({autoFit:true,fontScale:1.25});await flush();
  f.$('textScale').value='1.5';await f.$('textScale').emit('input');await f.$('textScale').emit('change');
  assert.equal(f.saved.textScale,1.5);assert.equal(f.saved.fontScale,1.25);assert.equal(f.saved.autoFit,true);
  assert.equal(f.$('layoutPreview').style['--preview-text'],1.5);
  assert.ok(f.writes.every(w=>!('fontScale' in w)));
});
test('Big screen preset enables fitting and vivid pulses from the full control centre',async()=>{
  const f=fixture({callGlow:false,glowPulse:false,textScale:1.5},'options.html');await flush();
  await f.document.querySelectorAll('[data-preset]').find(b=>b.dataset.preset==='tv').click();await flush();
  assert.equal(f.saved.autoFit,true);assert.equal(f.saved.wallboard,true);assert.equal(f.saved.callGlow,true);assert.equal(f.saved.glowPulse,true);assert.equal(f.saved.textScale,1.5);
  assert.equal(f.$('openOptions').hidden,true);
});
