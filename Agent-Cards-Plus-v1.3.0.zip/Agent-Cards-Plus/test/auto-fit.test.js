const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const {grid,bandHeight}=require('../auto-fit.js');
const {defaults,sanitize,presets}=require('../defaults.js');

test('1080p and 4K wallboard geometry fits all cards and uses more room on the larger screen',()=>{
  const desk=grid({width:1880,height:700,count:20});
  const tv=grid({width:3750,height:1400,count:40});
  assert.equal(desk.overflow,false);assert.equal(tv.overflow,false);
  assert.ok(desk.columns>2);assert.ok(tv.scale>desk.scale);
  assert.ok(tv.contentHeight<=1400);assert.ok(tv.columns*204*tv.scale+(tv.columns-1)*12<=3750);
});
test('dense narrow widgets retain readable text and signal scroll instead of shrinking indefinitely',()=>{
  const fit=grid({width:280,height:180,count:80});
  assert.equal(fit.columns,1);assert.equal(fit.scale,.75);assert.equal(fit.overflow,true);
});
test('filtering to a smaller agent set allows larger cards',()=>{
  const before=grid({width:1100,height:500,count:24});
  const after=grid({width:1100,height:500,count:4});
  assert.ok(after.scale>before.scale);assert.equal(after.overflow,false);
});
test('compact cards use their different width and measured height',()=>{
  const fit=grid({width:1200,height:400,count:12,cardWidth:300,cardHeight:66});
  assert.equal(fit.overflow,false);assert.ok(fit.contentHeight<=400);
  assert.ok(fit.columns*300*fit.scale+(fit.columns-1)*12<=1200);
});
test('fixed scale honours text sizing even when all cards can no longer fit',()=>{
  const normal=grid({width:1100,height:450,count:12});
  const larger=grid({width:1100,height:450,count:12,cardWidth:408,cardHeight:220,minScale:normal.scale,maxScale:normal.scale});
  assert.equal(larger.scale,normal.scale);assert.ok(larger.columns<normal.columns);assert.equal(larger.overflow,true);
});
test('empty, hidden and invalid geometry is safe and tiny widgets remain bounded',()=>{
  for(const args of [{width:0,height:100,count:4},{width:100,height:0,count:4},{width:100,height:100,count:0},{width:NaN,height:Infinity,count:Infinity}])assert.equal(grid(args),null);
  const tiny=grid({width:40,height:40,count:2});assert.equal(tiny.columns,1);assert.equal(tiny.scale,.75);assert.equal(tiny.overflow,true);
});
test('automatic band allocation reserves increasing room for native widget rows',()=>{
  const solo=bandHeight({height:900,otherRows:0});
  const one=bandHeight({height:900,otherRows:1});
  const three=bandHeight({height:900,otherRows:3});
  assert.equal(solo,900);assert.ok(one<solo);assert.ok(three<one);assert.ok(three>=900*.3);
  assert.equal(bandHeight({height:NaN}),0);
});
test('existing manual values migrate and survive toggling Auto fit and text size',()=>{
  const saved=sanitize({columns:5,fontScale:1.4,wallboardHeight:75});
  assert.equal(saved.autoFit,false);assert.equal(saved.textScale,1);
  const on=sanitize({...saved,autoFit:true,textScale:1.5});
  const off=sanitize({...on,autoFit:false});
  assert.equal(off.columns,5);assert.equal(off.fontScale,1.4);assert.equal(off.wallboardHeight,75);assert.equal(off.textScale,1.5);
  assert.equal(presets.tv.autoFit,true);assert.equal(sanitize({textScale:Infinity}).textScale,1);assert.equal(sanitize({textScale:99}).textScale,2);
});

// Geometry simulation, deliberately not represented as a browser render test.
function fixture() {
  const root={clientHeight:1200,clientWidth:2400,scrollTop:0}, document={documentElement:root,fullscreenElement:null};
  const observers=[];
  class Observer {constructor(fn){this.fn=fn;this.nodes=new Set();observers.push(this);}observe(n){this.nodes.add(n);}unobserve(n){this.nodes.delete(n);}disconnect(){this.nodes.clear();}}
  function node({width=1200,height=700,top=0,parent=null,overflow='visible',padding=0}={}) {
    const properties=new Map();
    return {parentElement:parent,clientWidth:width,clientHeight:height,clientTop:0,scrollTop:0,top,children:[],dataset:{},
      computed:{overflowY:overflow,paddingLeft:String(padding),paddingRight:String(padding),paddingTop:String(padding),paddingBottom:String(padding),rowGap:'12'},
      style:{getPropertyValue:k=>properties.get(k)||'',setProperty:(k,v)=>properties.set(k,String(v)),removeProperty:k=>properties.delete(k)},
      getBoundingClientRect(){return {top:this.top,width:this.clientWidth,height:this.clientHeight};},
      querySelector(){return null;},querySelectorAll(){return [];},closest(){return null;}};
  }
  const context=vm.createContext({document,ResizeObserver:Observer,getComputedStyle:n=>n.computed});
  vm.runInContext(fs.readFileSync(require.resolve('../auto-fit.js'),'utf8'),context);
  function board(width=1200,height=700,count=12,top=0) {
    const widget=node({width,height,top,parent:root}),host=node({width,height:180,top,parent:widget});
    const scroller=node({width,height,top,parent:widget,overflow:'auto'});
    const table=node({width,height:500,top:top+180,parent:scroller});
    table.getBoundingClientRect=function(){return {top:this.top-scroller.scrollTop-root.scrollTop,width:this.clientWidth,height:this.clientHeight};};
    const tbody=node({padding:10});table.querySelector=q=>q==='tbody'?tbody:null;
    const visibleRows=Array.from({length:count},()=>({getBoundingClientRect(){
      const text=Number(table.style.getPropertyValue('--ac-measure-text')||1);
      return {height:44+88*text,width:204*text};
    }}));
    return {widget,host,scroller,table,tbody,visibleRows};
  }
  return {api:context.AC_FIT,document,root,node,board,observers};
}
const auto={...defaults,autoFit:true};

test('each widget receives its own fit, while native dimensions and saved settings stay untouched',()=>{
  const f=fixture(),wide=f.board(1600,900,16),narrow=f.board(300,700,12),settings={...auto};
  const fitter=f.api.create();fitter.update([wide,narrow],settings);
  assert.ok(wide.fit.columns>narrow.fit.columns);assert.equal(narrow.fit.columns,1);
  assert.equal(wide.widget.clientWidth,1600);assert.equal(narrow.widget.clientHeight,700);
  assert.deepEqual(settings,auto);assert.equal(wide.table.dataset.acFit,'true');
  assert.equal(wide.table.dataset.acMeasure,undefined);assert.equal(wide.table.style.getPropertyValue('--ac-measure-text'),'');
});
test('font-only adjustment grows text without Auto fit cancelling it through smaller card scale',()=>{
  const f=fixture(),b=f.board(),fitter=f.api.create();fitter.update([b],auto);
  const before={...b.fit};fitter.update([b],{...auto,textScale:1.5});
  assert.equal(b.fit.scale,before.scale);assert.ok(b.fit.columns<before.columns);assert.equal(b.fit.overflow,true);
});
test('font-only adjustment also reduces crowded columns in manual mode without changing card zoom',()=>{
  const f=fixture(),b=f.board(800,700,12),fitter=f.api.create();
  fitter.update([b],{...defaults,textScale:2,columns:4,fontScale:1.2});
  assert.equal(b.fit.columns,1);assert.equal(b.fit.scale,1.2);assert.equal(b.table.dataset.acFit,undefined);
  fitter.update([b],defaults);assert.equal(b.widget.style.getPropertyValue('--agent-cards-cols'),'');assert.equal(b.widget.style.getPropertyValue('--agent-cards-scale'),'');
});
test('resizing and changed row counts recalculate fit, with one observer per controller',()=>{
  const f=fixture(),b=f.board(),fitter=f.api.create(()=>resizes++);let resizes=0;
  fitter.update([b],auto);const old=b.fit.columns;
  b.widget.clientWidth=b.scroller.clientWidth=b.table.clientWidth=320;
  f.observers[0].fn();assert.equal(resizes,1);fitter.update([b],auto);assert.ok(b.fit.columns<old);
  b.visibleRows=b.visibleRows.slice(0,1);fitter.update([b],auto);assert.equal(b.fit.overflow,false);
  assert.equal(f.observers.length,1);assert.ok(f.observers[0].nodes.has(b.widget));
});
test('scroll position does not feed back into calculated dimensions',()=>{
  const f=fixture(),b=f.board();const first=f.api.space(b.table,b.widget);
  b.scroller.scrollTop=300;assert.deepEqual(f.api.space(b.table,b.widget),first);
  // Real ancestor bounds move with document scrolling as well.
  f.root.scrollTop=100;b.widget.top-=100;b.scroller.top-=100;
  assert.deepEqual(f.api.space(b.table,b.widget),first);
});
test('repeated sizing is stable and empty or hidden widgets discard obsolete fit properties',()=>{
  const f=fixture(),b=f.board(),fitter=f.api.create();fitter.update([b],auto);
  const initial={...b.fit};for(let i=0;i<12;i++)fitter.update([b],auto);assert.deepEqual({...b.fit},initial);
  b.visibleRows=[];fitter.update([b],auto);assert.equal(b.fit,null);assert.equal(b.table.dataset.acFit,undefined);
  b.visibleRows=f.board().visibleRows;b.table.clientWidth=0;fitter.update([b],auto);assert.equal(b.fit,null);
});
test('switching to manual and replacing widgets clears fitted properties and observers',()=>{
  const f=fixture(),old=f.board(),next=f.board(900,700,8),fitter=f.api.create();fitter.update([old],auto);
  fitter.update([next],auto);assert.equal(old.table.dataset.acFit,undefined);assert.equal(f.observers[0].nodes.has(old.widget),false);
  fitter.update([next],defaults);assert.equal(next.table.dataset.acFit,undefined);assert.equal(next.widget.style.getPropertyValue('--agent-cards-scale'),'');assert.equal(f.observers[0].nodes.size,0);
});
test('full-width mode reserves main-widget rows and restores the manual band on exit',()=>{
  const f=fixture(),b=f.board(),parent=f.node({height:1000,parent:f.root}),main=f.node({parent});
  main.children=[f.node({height:160,top:500}),f.node({height:160,top:500}),f.node({height:160,top:680})];
  parent.querySelector=()=>main;b.widget.closest=s=>s==='.flow-layout-parent'?parent:s==='.flow-layout-sidebar'?b.widget:null;
  const fitter=f.api.create();fitter.update([b],{...auto,wallboard:true});
  assert.equal(parent.style.getPropertyValue('--agent-cards-wallboard-h'),'656px');assert.equal(main.style.getPropertyValue('height'),'');
  fitter.update([b],{...auto,wallboard:false});assert.equal(parent.style.getPropertyValue('--agent-cards-wallboard-h'),'');
});
test('full screen ignores clipping from the old dashboard ancestors',()=>{
  const f=fixture(),b=f.board(1800,1100,20),old=f.node({width:300,height:200,parent:f.root,overflow:'hidden'});
  b.widget.parentElement=old;f.document.fullscreenElement=b.widget;
  const available=f.api.space(b.table,b.widget);assert.equal(available.width,1800);assert.equal(available.height,920);
});
test('controller teardown restores all presentation overrides',()=>{
  const f=fixture(),b=f.board(),fitter=f.api.create();fitter.update([b],auto);fitter.destroy();
  assert.equal(b.table.dataset.acFit,undefined);assert.equal(b.widget.style.getPropertyValue('--agent-cards-cols'),'');assert.equal(f.observers[0].nodes.size,0);
});
test('ordinary timer ticks reuse measurements; longer text and resizing trigger a fresh measure',()=>{
  const f=fixture(),b=f.board(1200,700,1),fitter=f.api.create();let measures=0;
  b.visibleRows=[{textContent:'Alex Ready 03:12',getBoundingClientRect(){measures++;return {height:132};}}];
  fitter.update([b],auto);const first=measures;
  b.visibleRows[0].textContent='Alex Ready 03:13';fitter.update([b],auto);assert.equal(measures,first);
  b.visibleRows[0].textContent='Alex Ready 100:00:00';fitter.update([b],auto);assert.ok(measures>first);
  const beforeResize=measures;f.observers[0].fn();fitter.update([b],auto);assert.ok(measures>beforeResize);
});
