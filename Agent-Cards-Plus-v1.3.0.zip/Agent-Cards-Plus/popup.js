/* One settings controller shared by the toolbar popup and full control centre. */
(() => {
  let settings={...AC.defaults}, dirty={}, timer, feedbackTimer, restoring=false;
  const ui=id=>document.getElementById(id);
  const fields=[...document.querySelectorAll('[data-setting]')];
  function feedback(text,error=false){ui('saved').textContent=text;ui('saved').classList.toggle('error',error);clearTimeout(feedbackTimer);if(!error)feedbackTimer=setTimeout(()=>ui('saved').textContent='All saved',2200);}
  function render(){
    document.documentElement.dataset.theme=settings.theme;
    document.documentElement.classList.toggle('reduce-motion',settings.reduceMotion);
    document.documentElement.style.setProperty('--accent',AC.accents[settings.accent]);
    for(const field of fields){if(field.type==='checkbox')field.checked=settings[field.dataset.setting];else field.value=settings[field.dataset.setting];}
    for(const button of document.querySelectorAll('[data-theme-choice]'))button.setAttribute('aria-pressed',String(button.dataset.themeChoice===settings.theme));
    for(const button of document.querySelectorAll('[data-accent]'))button.setAttribute('aria-pressed',String(button.dataset.accent===settings.accent));
    for(const o of document.querySelectorAll('[data-output]'))o.textContent=settings.autoFit&&['fontScale','wallboardHeight'].includes(o.dataset.output)?'Auto':(['fontScale','textScale'].includes(o.dataset.output)?Math.round(settings[o.dataset.output]*100):settings[o.dataset.output])+o.dataset.suffix;
    for(const [key,on] of Object.entries({columns:!settings.autoFit,fontScale:!settings.autoFit,glowPulse:settings.callGlow&&!settings.reduceMotion,wallboardHeight:settings.wallboard&&!settings.autoFit,scrollSpeed:settings.autoScroll&&!settings.reduceMotion,edgePause:settings.autoScroll&&!settings.reduceMotion,pauseOnHover:settings.autoScroll,callThreshold:settings.alerts,breakThreshold:settings.alerts,awayThreshold:settings.alerts,wrapThreshold:settings.alerts,clock24:settings.showClock})){ui(key).disabled=!on;ui(key).closest('label').classList.toggle('disabled',!on);}
    ui('fitModeHint').textContent=settings.autoFit?'Auto fit is on. Each Agent Status widget uses its available space and visible agent count. Your manual sizes are saved.':'Manual sizing is on. Auto fit keeps your manual sizes saved for later.';
    const preview=ui('layoutPreview');preview.classList.toggle('compact',settings.style==='compact');preview.classList.toggle('large-text',settings.textScale>1.2);preview.classList.toggle('glow',settings.callGlow);preview.classList.toggle('pulse',settings.glowPulse&&!settings.reduceMotion);preview.style.setProperty('--preview-scale',settings.autoFit?1:Math.min(settings.fontScale,1.3));preview.style.setProperty('--preview-text',settings.textScale);
  }
  // Serialise writes so an older slider update cannot overwrite a newer one.
  let saving=Promise.resolve();
  function flush(){clearTimeout(timer);const patch=dirty;dirty={};if(!Object.keys(patch).length)return saving;saving=saving.catch(()=>{}).then(()=>chrome.storage.sync.set(patch)).then(()=>feedback('Saved')).catch(()=>{dirty={...patch,...dirty};feedback('Could not save',true);});return saving;}
  function update(patch,immediate=false){settings=AC.sanitize({...settings,...patch});for(const k of Object.keys(patch))dirty[k]=settings[k];render();feedback('Saving…');clearTimeout(timer);if(immediate)flush();else timer=setTimeout(flush,160);}
  for(const field of fields){field.addEventListener(field.type==='number'?'change':'input',()=>update({[field.dataset.setting]:field.type==='checkbox'?field.checked:field.type==='range'||field.type==='number'||field.id==='columns'?Number(field.value):field.value},field.type==='number'));field.addEventListener('change',flush);}
  document.addEventListener('visibilitychange',()=>{if(document.hidden)flush();});
  for(const b of document.querySelectorAll('[data-theme-choice]'))b.addEventListener('click',()=>update({theme:b.dataset.themeChoice},true));
  for(const b of document.querySelectorAll('[data-accent]'))b.addEventListener('click',()=>update({accent:b.dataset.accent},true));
  for(const b of document.querySelectorAll('[data-preset]'))b.addEventListener('click',()=>update(AC.presets[b.dataset.preset],true));
  function chooseTab(name,persist=true){if(!['contacts','notes','appearance','wallboard','calling','sites'].includes(name))name='contacts';for(const b of document.querySelectorAll('[data-tab]')){const on=b.dataset.tab===name;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;ui(`panel-${b.dataset.tab}`).hidden=!on;}document.querySelector('main').scrollTop=0;if(persist){restoring=true;chrome.storage.local.set({popupTab:name});}}
  const tabs=[...document.querySelectorAll('[data-tab]')];
  for(const b of tabs){b.addEventListener('click',()=>chooseTab(b.dataset.tab));b.addEventListener('keydown',e=>{let index=tabs.indexOf(b);if(e.key==='ArrowRight')index=(index+1)%tabs.length;else if(e.key==='ArrowLeft')index=(index+tabs.length-1)%tabs.length;else if(e.key==='Home')index=0;else if(e.key==='End')index=tabs.length-1;else return;e.preventDefault();chooseTab(tabs[index].dataset.tab);tabs[index].focus();});}
  chrome.storage.sync.get(AC.defaults).then(s=>{settings=AC.sanitize({...s,...dirty});render();feedback('All saved');}).catch(()=>feedback('Could not load preferences',true));
  chrome.storage.local.get('popupTab').then(s=>{if(!restoring)chooseTab(s.popupTab,false);});
  chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='sync')return;const next={...settings};for(const [k,v] of Object.entries(changes))if(k in AC.defaults&&!Object.hasOwn(dirty,k))next[k]=v.newValue;settings=AC.sanitize(next);render();});
  ui('reset').addEventListener('click',()=>{if(confirm('Reset appearance and behaviour preferences? Contacts, enabled sites and pinned agents will be kept.'))update(AC.defaults,true);});
  ui('export').addEventListener('click',()=>{const blob=new Blob([JSON.stringify({format:'agent-cards-settings',version:1,settings:AC.sanitize(settings)},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='Agent-Cards-Settings.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),30000);feedback('Settings exported');});
  ui('import').addEventListener('click',()=>ui('importFile').click());
  ui('importFile').addEventListener('change',async()=>{const file=ui('importFile').files[0];if(!file)return;try{if(file.size>64000)throw new Error('Backup is too large.');const imported=AC.importSettings(JSON.parse(await file.text()));update(imported,true);}catch(e){feedback(e.message||'Invalid backup',true);}ui('importFile').value='';});
  for(const b of document.querySelectorAll('[data-open-demo]'))b.addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('demo.html')}));
  ui('openOptions').addEventListener('click',()=>chrome.runtime.openOptionsPage());
  if(document.body.classList.contains('options'))ui('openOptions').hidden=true;
  ui('diagnose').addEventListener('click',async()=>{ui('diagnose').disabled=true;ui('diagnostic').textContent='Checking enabled workspaces…';try{const result=await chrome.runtime.sendMessage({type:'AC_CHECK_CONNECTION'});if(!result)throw new Error('Reload the extension and try again.');ui('diagnostic').textContent=`${result.sites} enabled site(s)\n${result.tabs} permitted open tab(s)\n${result.dialers} visible Genesys dialler(s) found\n\n${result.dialers?'Ready to accept a confirmed dispatch call.':'Open Agent Workspace, enable its exact site and refresh it.'}`;}catch(e){ui('diagnostic').textContent=e.message;}finally{ui('diagnose').disabled=false;}});
})();
